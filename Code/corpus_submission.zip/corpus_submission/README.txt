--- REQUIREMENTS FOR CODE TO RUN ---

To execute project you have to use Python file provided in the project called 'r2p.py'. 
To run the project, you must have Python and R on your computer.
To check whenever they are set up properly run those commands:

python -c 'print("Hi")'    	for Python
Rscript -e "1+1"		for R


In addition, Python will require you to download some packages:
numpy
pandas
rpy2

matplotlib
scikit-learn
pybullet
scipy

To install them, type in terminal:

pip install numpy pandas rpy2 matplotlib, scikit-learn pybullet scipy


Now, with that out of the way, r2p.py itself will require your calibration. 
You may (surely) need to change path to your working directory within the code, lines 113-114. In addition, you may have to delete section 1. Environment Setup, lines 81-92 (it is specific config to my PC). 
Program may require additional calibrations, especially section -loading the data-.


--- DESCRIPTION OF FILES ---

- Scripts -

- mainEM_3d_size_shape.r:
Essential part of the code. This is size and shape regression model implemented by professor Alfred Kume and his colleagues from paper: 'Regression Modeling for Size-and-Shape Data Based on a Gaussian Model for Landmarks'. It is unchanged version of the model, used all around the project being an essential part of it.

- Prototype starter.r:
This is simple code in R to execute regression model from main_3d_size_shape.r. Used for educational and testing purposes only.

- PyBullet.py:
Essential part of the code. PyBullet have been used for creating artificial landmarks and robotic simulations. Most of the data have been create using this file.

- r2p.py
The main part of the code, and purpose of the dissertation. r2p.py contain most of the work done for this project. Large part of the code used for prototyping, testing and research have been done there and commented out for future reference.
This code contain function called size_shape_regression_length_constrained, the main artifact of this dissertation project, that consist of:
-Size&Shape regression model adapter, that imports size and shape regression model from main_3d_size_shape.r to the Python environment to perform regression
-Polynomial regression model function, that smooths out the data and can create a continuous model for trajectory planning and predictions
-Length-Constrained Alignment function responsible for anchoring and aligning landmarks with original ones and creating length constrains on those data, using supplied data, essential part for preparing data for the robotic simulation
Additionally, there is implemented Pybullet_simulation function that:
- Using supplied landmarks (preferably the one supplied by regression model) can create simulation in PyBullet using landmarks as a guidebook to move artificial limb from one place to another.
Additionally, document includes many parts that have been used for prototyping, like initial experiments for implementing regression function using rpy2 package, experiments involving different robots, failed implementation of the simplified size & shape regression model and more.

- simplified_3d_size_shape.py:
Simplified version of the size & shape regression model. Unfortunately, this prototype have failed over and over again, never bringing any useful contributions.

- sanity.py:
Initial document that have been created for testing purposes. This script have helped me verifying issues with R language on my computer and create custom configuration that I use in r2p.py

- Tutorial.py
Initial document that I used for testing PyBullet simulations using robot 'kuka_experimental'.

- Starterprototype.py:
Initial attempt of using rpy2 package for running size & shape regression model from mainEM_3d_size_shape.r.


- trajectories -

Within trajectories folder there are many landmarks files that have been created for educational and testing purposes. Notable mentions are:

- my_3d_array.csv:
Initial set of landamarks used by professor Alfred Kume to demonstrate potential of Size & Shape Regression model in mainEM_3d_size_shape.r, later used for testing.

- realistic_hand_landmarks.csv:
Latest set of landmarks used in r2p.py for testing performance of the regression model. Created using robot from twenty_one_landmark_hand.urdf file, used as a main set of landmarks for demonstrating performance of the regression model.

- aligned_landmarks.csv, aligned_trajectory.csv, simple_trajectory.csv:
Experimental landmarks create using simple 3 degree of freedom robot from simple3dof.urdf. Test using those landmarks have been essential, proving that Size and Shape Regression model does not handle well simple landmarks data like 3DoF artificial limbs.

- demonstration_landmarks.npy:
Simple landmarks implemented in npy file as a test to improve contactability of the landmarks files. Failed experiment.


- urdf -
Folder that contain all the .urdf file (configuration files for the robots used in robot simulations). Notable mentions are:

- dummy_hand.urdf, twenty_one_landmark_hand.urdf:
Simple artificial hands, dummy hand contain 16 landamrks while twenty_one_landmark_hand contain 21 landmarks. Used in PyBullet to capture the landmarks and in r2p.py for the successful landmarks regression of the hand-like landmarks and simulation.

- simple3dof.urdf, (simple_3dof_robot.urdf 0-2):
Different versions of simple 3 Degree of Freedom artificial limb. It have been part of the failed test with size and shape regression model, that suggested inability of model to deal with simple limbs like 3 DoF robots.



--- MAIN CONTRIBUTIONS ---

- r2p.py
- PyBullet.py
- trajectories/realistic_hand_landmarks.csv
- urdf/twenty_one_landmark_hand.urdf

- mainEM_3d_size_shape: NOT A CONTRIBUTION, but essential part of the code. Script created by Alfred Kume and other professors that contributed to 'Regression Modeling for Size-and-Shape Data Based on a Gaussian Model for Landmarks'.



Honorable mentions:
- Ioanna Giorgi: Supervisor of the project
- Alfred Kume and others professors that contributed to 'Regression Modeling for Size-and-Shape Data Based on a Gaussian Model for Landmarks': Alfred helped me with understanding Regression model and shared with me his work