# -----------------------
# Example of using PyBullet to create a simple 3-DOF robot and record end-effector positions
# -----------------------

# import pybullet as p
# import pybullet_data
# import time
# import numpy as np
#
# p.connect(p.GUI)
# p.setGravity(0, 0, -9.81)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.loadURDF('plane.urdf')
# robot_id = p.loadURDF('simple_3dof_robot.urdf', [0, 0, 0.1], useFixedBase=True)
# end_effector_index = 2  # link3
#
# # Create sliders for manual control
# joint_sliders = []
# for i in range(3):
#     joint_sliders.append(p.addUserDebugParameter(f'joint_{i+1}', -3.14, 3.14, 0))
#
# landmarks = []
#
# for _ in range(9000):  # Adjust for desired demo length
#     # During demonstration recording
#     joint_positions = [p.readUserDebugParameter(slider) for slider in joint_sliders]
#     for i, pos in enumerate(joint_positions):
#         p.setJointMotorControl2(robot_id, i, p.POSITION_CONTROL, targetPosition=pos, force=5)
#     p.stepSimulation()
#     time.sleep(1. / 240.)
#
#     state = p.getLinkState(robot_id, end_effector_index, computeForwardKinematics=True)
#     ee_pos = state[0]
#     ee_orn = state[1]
#     landmarks.append((joint_positions, ee_pos, ee_orn))
#
# # Save landmarks for future use
# np.save('demonstration_landmarks.npy', np.array(landmarks, dtype=object))


# -----------------------
# Example of using the recorded landmarks to control the robot
# -----------------------
# import numpy as np
# import pybullet as p
# import pybullet_data
# import time
#
# # Load landmarks
# landmarks = np.load('demonstration_landmarks.npy', allow_pickle=True)
#
# print("Loaded landmarks:", landmarks[1], landmarks[4500], landmarks[-1])
#
# p.connect(p.GUI)
# p.setGravity(0, 0, -9.81)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.loadURDF('plane.urdf')
# robot_id = p.loadURDF('simple_3dof_robot.urdf', [0, 0, 0.1], useFixedBase=True)
# end_effector_index = 2
#
# for joint_positions, ee_pos, ee_orn in landmarks:
#     joint_angles = p.calculateInverseKinematics(robot_id, end_effector_index, ee_pos, ee_orn)
#     for i in range(3):
#         p.setJointMotorControl2(robot_id, i, p.POSITION_CONTROL, targetPosition=joint_angles[i], force=5)
#     p.stepSimulation()
#     time.sleep(1. / 240.)

# # -------------------------
# # Alternative example using a simple 3-DoF robot to save landmarks
# # -------------------------
# import pybullet as p
# import pybullet_data
# import numpy as np
# import csv
# import time
# import sys
#
# try:
#     import msvcrt  # For Windows keypress
# except ImportError:
#     msvcrt = None
#
# URDF_PATH = "simple_3dof_robot.urdf"
# NUM_LANDMARKS = 4
# LANDMARK_LINK_INDICES = [0, 1, 2, 3]  # Update as needed
# CSV_FILE = "robot_landmarks.csv"
#
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# robot_id = p.loadURDF(URDF_PATH, useFixedBase=True)
#
# header = [f'V{i+1}' for i in range(NUM_LANDMARKS * 3)]
# all_landmarks = []
# num_joints = p.getNumJoints(robot_id)
#
# # Initial joint positions
# joint_angles = [0.0] * num_joints
# recording = True
# print("Use arrow keys (or WASD) to control joints. Press 'q' to quit and save.")
#
# while recording:
#     p.stepSimulation()
#     # Simple keyboard logic (WASD for 3 joints)
#     if msvcrt and msvcrt.kbhit():
#         key = msvcrt.getch().decode('utf-8').lower()
#         if key == 'w':
#             joint_angles[0] += 0.05
#         elif key == 's':
#             joint_angles[0] -= 0.05
#         elif key == 'a':
#             joint_angles[1] += 0.05
#         elif key == 'd':
#             joint_angles[1] -= 0.05
#         elif key == 'e':
#             joint_angles[2] += 0.05
#         elif key == 'r':
#             joint_angles[2] -= 0.05
#         elif key == 'q':
#             recording = False
#             break
#     # Set joint positions
#     for i in range(num_joints):
#         p.setJointMotorControl2(robot_id, i, p.POSITION_CONTROL, joint_angles[i])
#     # Record current landmark positions
#     frame_landmarks = []
#     for link in LANDMARK_LINK_INDICES:
#         pos, _ = p.getLinkState(robot_id, link)[:2]
#         frame_landmarks.extend(list(pos))
#     all_landmarks.append(frame_landmarks)
#     time.sleep(0.05)
#
# # Save CSV
# with open(CSV_FILE, 'w', newline='') as f:
#     writer = csv.writer(f)
#     writer.writerow(header)
#     writer.writerows(all_landmarks)
#
# print(f"Saved {len(all_landmarks)} frames to {CSV_FILE}")
# p.disconnect()
#

# # -------------------------
# # Align data with procrustes_align
# # -------------------------
# import pandas as pd
#
# def procrustes_align(X_ref, X, scaling=True):
#     """
#     Procrustes alignment: aligns X to X_ref.
#     If scaling=True, includes scaling (full Procrustes); otherwise, only rigid body (Helmert).
#     Both X_ref and X are (n_landmarks, 3) arrays, with first landmark assumed to be at origin.
#     Returns: X_aligned (n_landmarks, 3)
#     """
#
#     # Center both sets to first landmark at origin
#     X_ref_c = X_ref - X_ref[0]
#     X_c = X - X[0]
#
#     # Remove translation (already done above)
#     # Optionally, scale both shapes to unit size for full Procrustes
#     if scaling:
#         norm_ref = np.linalg.norm(X_ref_c)
#         norm_X = np.linalg.norm(X_c)
#         X_ref_c /= norm_ref
#         X_c /= norm_X
#
#     # Optimal rotation via SVD (Kabsch algorithm)
#     U, S, Vt = np.linalg.svd(X_c.T @ X_ref_c)
#     R = U @ Vt
#     # Ensure right-handedness (determinant +1)
#     if np.linalg.det(R) < 0:
#         Vt[-1, :] *= -1
#         R = U @ Vt
#
#     X_aligned = (X_c @ R.T)
#     if scaling:
#         X_aligned *= norm_ref
#     # Add back the reference origin (first landmark)
#     X_aligned += X_ref[0]
#
#     return X_aligned
#
# # --- Load your data ---
# csv_path = 'D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/physically_plausible_trajectory_urdf_axes.csv'
# df = pd.read_csv(csv_path)
# n_frames = df.shape[0]
# n_landmarks = 4  # Change if needed
# coords_per_landmark = 3
#
# # Reshape to (n_frames, n_landmarks, 3)
# data = df.to_numpy().reshape(n_frames, n_landmarks, coords_per_landmark)
#
# # Reference frame (first frame)
# X_ref = data[0]
#
# # Align all frames to first frame (with first landmark as "zero")
# aligned_data = np.empty_like(data)
# for i in range(n_frames):
#     aligned_data[i] = procrustes_align(X_ref, data[i], scaling=False)  # Use scaling=True for full Procrustes
#
# # Save aligned data
# out_df = pd.DataFrame(aligned_data.reshape(n_frames, n_landmarks * coords_per_landmark),
#                       columns=[f'V{i+1}{ax}' for i in range(n_landmarks) for ax in ['x', 'y', 'z']])
# out_df.to_csv('aligned_trajectory.csv', index=False)
# print("✅ Procrustes alignment complete. Saved as 'aligned_trajectory.csv'.")







# # -------------------------
# # Hardcoded example of using a simple 3-DoF robot to save landmarks
# # -------------------------
# import numpy as np
# import csv
#
# def rotz(theta):
#     c, s = np.cos(theta), np.sin(theta)
#     return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
#
# def roty(theta):
#     c, s = np.cos(theta), np.sin(theta)
#     return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]])
#
# def rotx(theta):
#     c, s = np.cos(theta), np.sin(theta)
#     return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]])
#
# def trans(x, y, z):
#     T = np.eye(4)
#     T[:3, 3] = [x, y, z]
#     return T
#
# # -- Robot link lengths (edit as per your URDF)
# L1 = 0.2
# L2 = 0.2
# L3 = 0.2
#
# NUM_FRAMES = 50
# NUM_LANDMARKS = 4
# header = [f'V{i+1}' for i in range(NUM_LANDMARKS * 3)]
# all_landmarks = []
#
# for frame in range(NUM_FRAMES):
#     t = frame / (NUM_FRAMES - 1)
#     # Example: joint angles sweeping smoothly
#     theta1 = 2 * np.pi * t  # Joint1 rotates full 360°
#     theta2 = np.pi/4 * np.sin(2 * np.pi * t)  # Joint2 swings +/- 45°
#     theta3 = np.pi/4 * np.cos(2 * np.pi * t)  # Joint3 swings +/- 45°
#
#     # Forward kinematics
#     T = np.eye(4)
#     base = T[:3, 3].copy()
#     T = T @ rotz(theta1)
#     T = T @ trans(0, 0, L1)
#     link1 = T[:3, 3].copy()
#     T = T @ roty(theta2)
#     T = T @ trans(0, 0, L2)
#     link2 = T[:3, 3].copy()
#     T = T @ rotx(theta3)
#     T = T @ trans(0, 0, L3)
#     tip = T[:3, 3].copy()
#
#     frame_landmarks = list(base) + list(link1) + list(link2) + list(tip)
#     all_landmarks.append(frame_landmarks)
#
# with open('physically_plausible_trajectory_urdf_axes.csv', 'w', newline='') as f:
#     writer = csv.writer(f)
#     writer.writerow(header)
#     writer.writerows(all_landmarks)
#
# print("Saved URDF-matching trajectory to physically_plausible_trajectory_urdf_axes.csv")


# # -------------------------
# # Example of loading a URDF hand model in PyBullet and printing joint information
# # -------------------------
# import pybullet as p
# import pybullet_data
# import time
#
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.loadURDF("plane.urdf")
# hand_id = p.loadURDF("twenty_one_landmark_hand.urdf", [0, 0, 0], useFixedBase=True)
#
# num_joints = p.getNumJoints(hand_id)
# for joint in range(num_joints):
#     info = p.getJointInfo(hand_id, joint)
#     print(joint, info[1].decode('utf-8'))
#
# while True:
#     p.stepSimulation()
#     time.sleep(1./240.)







# # -------------------------
# # Generate and save landmarks of artificial hand robot (simple hand)
# # -------------------------
# import pybullet as p
# import pybullet_data
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.animation import FuncAnimation
#
# # --- PyBullet Setup ---
# p.connect(p.DIRECT)
# p.setGravity(0, 0, -9.81)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# hand = p.loadURDF("twenty_one_landmark_hand.urdf", [0,0,0], useFixedBase=True)
#
# # --- Get joint and link indices ---
# joint_names = [p.getJointInfo(hand, i)[1].decode("utf-8") for i in range(p.getNumJoints(hand))]
# thumb_joints = [joint_names.index(j) for j in ["thumb_joint1", "thumb_joint2", "thumb_joint3"]]
# index_joints = [joint_names.index(j) for j in ["index_joint1", "index_joint2", "index_joint3"]]
# middle_joints = [joint_names.index(j) for j in ["middle_joint1", "middle_joint2", "middle_joint3"]]
# ring_joints = [joint_names.index(j) for j in ["ring_joint1", "ring_joint2", "ring_joint3"]]
# little_joints = [joint_names.index(j) for j in ["little_joint1", "little_joint2", "little_joint3"]]
#
# # --- Landmarks: palm (-1), then all segments (0-19), last is little_link3 ---
# landmark_link_indices = [
#     -1,  # palm
#     0, 1, 2, 3,      # thumb: thumb_link1,2,3,tip
#     4, 5, 6, 7,      # index: index_link1,2,3,tip
#     8, 9, 10, 11,    # middle: middle_link1,2,3,tip
#     12, 13, 14, 15,  # ring: ring_link1,2,3,tip
#     16, 17, 18, 19   # little: little_link1,2,3 (tip is little_link3)
# ]
#
# # --- Joint order for all fingers ---
# all_joints = thumb_joints + index_joints + middle_joints + ring_joints + little_joints
#
# # --- Restrict thumb joints to realistic limits (e.g. max 1.0 rad ≈ 57°) ---
# thumb_upper_limits = np.array([1.0, 1.0, 1.0])  # thumb_joint1,2,3
# other_upper_limits = np.array([
#     1.5, 1.2, 1.0,      # index
#     1.5, 1.2, 1.0,      # middle
#     1.5, 1.2, 1.0,      # ring
#     1.5, 1.2, 1.0       # little
# ])
# joint_upper_limits = np.concatenate([thumb_upper_limits, other_upper_limits])
# open_angles = np.zeros(15)
# thumb_upper_limits = np.array([0.7, 1.0, 1.0])  # restrict base to 0.7 rad
# grasp_angles = np.array([
#     0.7, 1.0, 1.0,      # thumb (more restricted)
#     0.2, 1.2, 1.0,      # index
#     0.0, 1.3, 1.0,      # middle
#     0.0, 1.2, 1.0,      # ring
#     0.0, 1.1, 0.9       # little
# ])
#
# num_frames = 15
# poses = []
#
# for alpha in np.linspace(0, 1, num_frames):
#     frame_angles = (1-alpha) * open_angles + alpha * grasp_angles
#     frame_angles = np.clip(frame_angles, 0.0, joint_upper_limits)
#     # Explicitly clip thumb again for safety
#     frame_angles[:3] = np.clip(frame_angles[:3], 0.0, thumb_upper_limits)
#     for ji, angle in zip(all_joints, frame_angles):
#         p.resetJointState(hand, ji, angle)
#     p.stepSimulation()
#     pose = []
#     for idx in landmark_link_indices:
#         if idx == -1:
#             pos, _ = p.getBasePositionAndOrientation(hand)
#         else:
#             state = p.getLinkState(hand, idx)
#             pos = state[0] if state and state[0] is not None else (0.0, 0.0, 0.0)
#         pose.extend(pos)
#     poses.append(pose)
#
# poses = np.array(poses)  # (num_frames, 63)
# np.savetxt("realistic_hand_landmarks.csv", poses, delimiter=",")
# print(f"Saved {num_frames} frames of robust hand landmarks with restricted thumb to realistic_hand_landmarks.csv")
# # ----------------------------------
# # --- Animation using matplotlib ---
# # ----------------------------------
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# colors = ['r', 'b', 'g', 'y', 'm']  # thumb, index, middle, ring, little
#
# def update(frame):
#     ax.clear()
#     pose = poses[frame]
#     xs = pose[0::3]
#     ys = pose[1::3]
#     zs = pose[2::3]
#     # Plot palm
#     ax.scatter(xs[0], ys[0], zs[0], color='gray', s=60)
#     # Plot fingers
#     for f in range(5):
#         idxs = [1 + f*4, 2 + f*4, 3 + f*4, 4 + f*4]
#         ax.plot(xs[idxs], ys[idxs], zs[idxs], color=colors[f], marker='o', markersize=8)
#         ax.scatter(xs[idxs], ys[idxs], zs[idxs], color=colors[f], s=30)
#         # Connect palm to base of each finger for visual clarity
#         ax.plot([xs[0], xs[idxs[0]]], [ys[0], ys[idxs[0]]], [zs[0], zs[idxs[0]]], color='k', linewidth=1, alpha=0.5)
#     ax.set_xlim(-0.08, 0.18)
#     ax.set_ylim(-0.08, 0.18)
#     ax.set_zlim(-0.05, 0.22)
#     ax.set_xlabel("X")
#     ax.set_ylabel("Y")
#     ax.set_zlabel("Z")
#     ax.set_title(f"Hand Pose Frame {frame+1}/{num_frames}")
#
# ani = FuncAnimation(fig, update, frames=num_frames, interval=300, repeat=True)
# plt.show()






# --------------------------
# Running simulation with landmarks (simple hand)
# --------------------------
import pybullet as p
import pybullet_data
import numpy as np
import pandas as pd
import time
from scipy.optimize import minimize

# --- CONFIGURATION ---
CSV_PATH = "realistic_hand_landmarks.csv"   # <-- Your landmark CSV path
URDF_PATH = "twenty_one_landmark_hand.urdf" # <-- Your URDF file path
VISUALIZE_ERROR = True                      # Show error in GUI
ERROR_SPHERE_RADIUS = 0.01                  # Spheres for error visualization
SLEEP_TIME = 0.04                           # Pause between frames

# --- LOAD LANDMARKS ---
n_landmarks = 21
n_coords = 3
df = pd.read_csv(CSV_PATH, header=None)
data = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
n_frames = data.shape[0]
landmarks = data.reshape(n_frames, n_landmarks, n_coords)

# --- PYBULLET SETUP ---
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
hand = p.loadURDF(URDF_PATH, [0,0,0], useFixedBase=True)

# --- GET LINK AND JOINT INDICES AUTOMATICALLY ---
def get_all_joint_info(body_id):
    n_joints = p.getNumJoints(body_id)
    joints = []
    links = []
    for i in range(n_joints):
        info = p.getJointInfo(body_id, i)
        joints.append(info[1].decode("utf-8"))
        links.append(info[12].decode("utf-8"))
    return joints, links

joint_names, link_names = get_all_joint_info(hand)

# Map landmark names to link indices (palm is -1 in PyBullet)
landmark_link_names = [
    "palm",
    "thumb_link1", "thumb_link2", "thumb_link3", "thumb_tip",
    "index_link1", "index_link2", "index_link3", "index_tip",
    "middle_link1", "middle_link2", "middle_link3", "middle_tip",
    "ring_link1", "ring_link2", "ring_link3", "ring_tip",
    "little_link1", "little_link2", "little_link3", "little_tip"
]
landmark_link_indices = []
for name in landmark_link_names:
    if name == "palm":
        landmark_link_indices.append(-1)
    else:
        try:
            idx = link_names.index(name)
            landmark_link_indices.append(idx)
        except ValueError:
            print(f"WARNING: Link name {name} not found!")
            landmark_link_indices.append(None)

# Get all joint indices (15 joints: 3 x 5 fingers)
finger_joint_names = [
    "thumb_joint1", "thumb_joint2", "thumb_joint3",
    "index_joint1", "index_joint2", "index_joint3",
    "middle_joint1", "middle_joint2", "middle_joint3",
    "ring_joint1", "ring_joint2", "ring_joint3",
    "little_joint1", "little_joint2", "little_joint3"
]
joint_indices = []
for name in finger_joint_names:
    try:
        joint_indices.append(joint_names.index(name))
    except ValueError:
        print(f"WARNING: Joint name {name} not found!")

# --- FK UTILITY: GET ALL LANDMARK POSITIONS FOR GIVEN JOINT ANGLES ---
def get_hand_landmark_positions(hand, joint_angles):
    # Set joint angles
    for ji, angle in zip(joint_indices, joint_angles):
        p.resetJointState(hand, ji, angle)
    p.stepSimulation()
    # Get all landmark positions
    positions = []
    for idx in landmark_link_indices:
        if idx == -1:
            pos, _ = p.getBasePositionAndOrientation(hand)
        elif idx is None:
            pos = (np.nan, np.nan, np.nan)
        else:
            state = p.getLinkState(hand, idx)
            pos = state[0] if state else (np.nan, np.nan, np.nan)
        positions.append(np.array(pos))
    return np.array(positions)

# --- LOSS FUNCTION: SUM SQUARED DISTANCES ---
def pose_loss(joint_angles, hand, target_landmarks):
    predicted = get_hand_landmark_positions(hand, joint_angles)
    return np.sum((predicted - target_landmarks)**2)

# --- JOINT LIMITS ---
lower = [0.0] * len(joint_indices)
upper = [1.5] * len(joint_indices)
joint_bounds = [(l, u) for l, u in zip(lower, upper)]

# --- ERROR VISUALIZATION ---
def draw_error_spheres(targets, actuals, color=[1,0,0,0.6], radius=ERROR_SPHERE_RADIUS):
    sphere_ids = []
    for t, a in zip(targets, actuals):
        err = np.linalg.norm(t - a)
        # Color: green if error < 0.01, red otherwise
        c = [0,1,0,0.6] if err < 0.01 else color
        s_id = p.createVisualShape(p.GEOM_SPHERE, rgbaColor=c, radius=radius)
        sphere_ids.append(p.createMultiBody(baseMass=0, baseVisualShapeIndex=s_id, basePosition=t))
    return sphere_ids

def remove_error_spheres(sphere_ids):
    for sid in sphere_ids:
        p.removeBody(sid)

# --- OPTIMIZATION AND ANIMATION LOOP ---
prev_angles = np.zeros(len(joint_indices))
for frame in range(n_frames):
    print(f"Frame {frame+1}/{n_frames}")
    target_landmarks = landmarks[frame]
    # Optimize joint angles to minimize loss
    result = minimize(
        pose_loss, prev_angles,
        args=(hand, target_landmarks),
        method="L-BFGS-B",
        bounds=joint_bounds,
        options={'maxiter': 200}
    )
    optimal_angles = result.x
    # Apply angles to hand
    for ji, angle in zip(joint_indices, optimal_angles):
        p.resetJointState(hand, ji, angle)
    p.stepSimulation()
    # Get achieved positions
    achieved_landmarks = get_hand_landmark_positions(hand, optimal_angles)
    # Visualize error
    sphere_ids = []
    if VISUALIZE_ERROR:
        sphere_ids = draw_error_spheres(target_landmarks, achieved_landmarks)
    # Print mean error for the frame
    mean_error = np.mean(np.linalg.norm(achieved_landmarks - target_landmarks, axis=1))
    print(f"Mean landmark error: {mean_error:.4f} meters")
    time.sleep(SLEEP_TIME)
    if VISUALIZE_ERROR:
        remove_error_spheres(sphere_ids)
    prev_angles = optimal_angles.copy()

p.disconnect()








# # ---------------------------
# # Animate with matplot lib
# # ---------------------------
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib import animation
#
#
# def animate_skeleton(data, interval=200, name="Skeleton Animation"):
#     assert data.ndim == 3, f"Expected data with 3 dimensions (landmarks, 3, frames), got {data.shape}"
#     assert data.shape[1] == 3, f"Expected 3D coordinates in second dimension, got {data.shape[1]}"
#
#     n_landmarks, _, n_frames = data.shape
#     fig = plt.figure(figsize=(10, 8))
#     ax = fig.add_subplot(111, projection='3d')
#     scat = ax.scatter([], [], [], color='crimson', s=60)
#     lines = []
#
#     # Define landmark connections safely (only include if within bounds)
#     raw_connections = [
#         (0, 1), (1, 2), (2, 3), (3, 4),
#         (0, 5), (5, 6), (6, 7), (7, 8),
#         (0, 9), (9, 10), (10, 11), (11, 12),
#         (0, 13), (13, 14), (14, 15), (15, 16),
#         (0, 17), (17, 18), (18, 19), (19, 20)
#     ]
#     connections = [(i, j) for i, j in raw_connections if i < n_landmarks and j < n_landmarks]
#
#     # Create empty lines for connections
#     for _ in connections:
#         lines.append(ax.plot([], [], [], color='gray', linewidth=2)[0])
#
#     def init():
#         ax.set_xlim(np.min(data[:, 0, :]), np.max(data[:, 0, :]))
#         ax.set_ylim(np.min(data[:, 1, :]), np.max(data[:, 1, :]))
#         ax.set_zlim(np.min(data[:, 2, :]), np.max(data[:, 2, :]))
#         ax.set_xlabel('X')
#         ax.set_ylabel('Y')
#         ax.set_zlabel('Z')
#         ax.set_title(name)
#         return [scat] + lines
#
#     def update(frame):
#         landmarks = data[:, :, frame]  # shape (n_landmarks, 3)
#         scat._offsets3d = (landmarks[:, 0], landmarks[:, 1], landmarks[:, 2])
#         for idx, (i, j) in enumerate(connections):
#             try:
#                 xs = [landmarks[i, 0], landmarks[j, 0]]
#                 ys = [landmarks[i, 1], landmarks[j, 1]]
#                 zs = [landmarks[i, 2], landmarks[j, 2]]
#                 lines[idx].set_data(xs, ys)
#                 lines[idx].set_3d_properties(zs)
#             except IndexError:
#                 print(f"Invalid index at frame {frame}: {i}, {j}")
#         return [scat] + lines
#
#     ani = animation.FuncAnimation(fig, update, frames=n_frames, init_func=init,
#                                   blit=False, interval=interval, repeat=True)
#     plt.show()


# ---------------------------
# 12. PyBullet animate with direct angles
# ---------------------------
# --- METHOD TO LOAD THIS DATA ---
# import pandas as pd
# n_landmarks, n_coords, n_frames = 21, 3, 15
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/realistic_hand_landmarks.csv', header=None) #Directory to the CSV file
# data_flat = df.to_numpy()
# # print("First row:", data_flat[0])
# # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# data_3d = data_flat.reshape((n_frames, n_landmarks, n_coords))
# print(data_3d.shape)
# data_3d = data_3d.transpose(1, 2, 0)
# animate_skeleton(data_3d, name="Original landmarks")
# --- METHOD TO LOAD THIS DATA ---


# # ---------------------------
# # Example of using PyBullet to load a hand model and compute forward kinematics
# # ---------------------------
# import pybullet as p
# import pybullet_data
# import numpy as np
# import pandas as pd
# import time
# from scipy.optimize import minimize
#
# # --- CONFIGURATION ---
# CSV_PATH = "realistic_hand_landmarks.csv"   # <-- Your landmark CSV path
# URDF_PATH = "twenty_one_landmark_hand.urdf" # <-- Your URDF file path
# VISUALIZE_ERROR = True                      # Show error in GUI
# ERROR_SPHERE_RADIUS = 0.01                  # Spheres for error visualization
# SLEEP_TIME = 0.04                           # Pause between frames
#
# # --- LOAD LANDMARKS ---
# n_landmarks = 21
# n_coords = 3
# df = pd.read_csv(CSV_PATH, header=None)
# data = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
# n_frames = data.shape[0]
# landmarks = data.reshape(n_frames, n_landmarks, n_coords)
#
# # --- PYBULLET SETUP ---
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# hand = p.loadURDF(URDF_PATH, [0,0,0], useFixedBase=True)
#
# # --- GET LINK AND JOINT INDICES AUTOMATICALLY ---
# def get_all_joint_info(body_id):
#     n_joints = p.getNumJoints(body_id)
#     joints = []
#     links = []
#     for i in range(n_joints):
#         info = p.getJointInfo(body_id, i)
#         joints.append(info[1].decode("utf-8"))
#         links.append(info[12].decode("utf-8"))
#     return joints, links
#
# joint_names, link_names = get_all_joint_info(hand)
#
# # Map landmark names to link indices (palm is -1 in PyBullet)
# landmark_link_names = [
#     "palm",
#     "thumb_link1", "thumb_link2", "thumb_link3", "thumb_tip",
#     "index_link1", "index_link2", "index_link3", "index_tip",
#     "middle_link1", "middle_link2", "middle_link3", "middle_tip",
#     "ring_link1", "ring_link2", "ring_link3", "ring_tip",
#     "little_link1", "little_link2", "little_link3", "little_tip"
# ]
# landmark_link_indices = []
# for name in landmark_link_names:
#     if name == "palm":
#         landmark_link_indices.append(-1)
#     else:
#         try:
#             idx = link_names.index(name)
#             landmark_link_indices.append(idx)
#         except ValueError:
#             print(f"WARNING: Link name {name} not found!")
#             landmark_link_indices.append(None)
#
# # Get all joint indices (15 joints: 3 x 5 fingers)
# finger_joint_names = [
#     "thumb_joint1", "thumb_joint2", "thumb_joint3",
#     "index_joint1", "index_joint2", "index_joint3",
#     "middle_joint1", "middle_joint2", "middle_joint3",
#     "ring_joint1", "ring_joint2", "ring_joint3",
#     "little_joint1", "little_joint2", "little_joint3"
# ]
# joint_indices = []
# for name in finger_joint_names:
#     try:
#         joint_indices.append(joint_names.index(name))
#     except ValueError:
#         print(f"WARNING: Joint name {name} not found!")
#
# # --- FK UTILITY: GET ALL LANDMARK POSITIONS FOR GIVEN JOINT ANGLES ---
# def get_hand_landmark_positions(hand, joint_angles):
#     # Set joint angles
#     for ji, angle in zip(joint_indices, joint_angles):
#         p.resetJointState(hand, ji, angle)
#     p.stepSimulation()
#     # Get all landmark positions
#     positions = []
#     for idx in landmark_link_indices:
#         if idx == -1:
#             pos, _ = p.getBasePositionAndOrientation(hand)
#         elif idx is None:
#             pos = (np.nan, np.nan, np.nan)
#         else:
#             state = p.getLinkState(hand, idx)
#             pos = state[0] if state else (np.nan, np.nan, np.nan)
#         positions.append(np.array(pos))
#     return np.array(positions)
#
# # --- LOSS FUNCTION: SUM SQUARED DISTANCES ---
# def pose_loss(joint_angles, hand, target_landmarks):
#     predicted = get_hand_landmark_positions(hand, joint_angles)
#     return np.sum((predicted - target_landmarks)**2)
#
# # --- JOINT LIMITS ---
# lower = [0.0] * len(joint_indices)
# upper = [1.5] * len(joint_indices)
# joint_bounds = [(l, u) for l, u in zip(lower, upper)]
#
# # --- ERROR VISUALIZATION ---
# def draw_error_spheres(targets, actuals, color=[1,0,0,0.6], radius=ERROR_SPHERE_RADIUS):
#     sphere_ids = []
#     for t, a in zip(targets, actuals):
#         err = np.linalg.norm(t - a)
#         # Color: green if error < 0.01, red otherwise
#         c = [0,1,0,0.6] if err < 0.01 else color
#         s_id = p.createVisualShape(p.GEOM_SPHERE, rgbaColor=c, radius=radius)
#         sphere_ids.append(p.createMultiBody(baseMass=0, baseVisualShapeIndex=s_id, basePosition=t))
#     return sphere_ids
#
# def remove_error_spheres(sphere_ids):
#     for sid in sphere_ids:
#         p.removeBody(sid)
#
# # --- OPTIMIZATION AND ANIMATION LOOP ---
# prev_angles = np.zeros(len(joint_indices))
# for frame in range(n_frames):
#     print(f"Frame {frame+1}/{n_frames}")
#     target_landmarks = landmarks[frame]
#     # Optimize joint angles to minimize loss
#     result = minimize(
#         pose_loss, prev_angles,
#         args=(hand, target_landmarks),
#         method="L-BFGS-B",
#         bounds=joint_bounds,
#         options={'maxiter': 200}
#     )
#     optimal_angles = result.x
#     # Apply angles to hand
#     for ji, angle in zip(joint_indices, optimal_angles):
#         p.resetJointState(hand, ji, angle)
#     p.stepSimulation()
#     # Get achieved positions
#     achieved_landmarks = get_hand_landmark_positions(hand, optimal_angles)
#     # Visualize error
#     sphere_ids = []
#     if VISUALIZE_ERROR:
#         sphere_ids = draw_error_spheres(target_landmarks, achieved_landmarks)
#     # Print mean error for the frame
#     mean_error = np.mean(np.linalg.norm(achieved_landmarks - target_landmarks, axis=1))
#     print(f"Mean landmark error: {mean_error:.4f} meters")
#     time.sleep(SLEEP_TIME)
#     if VISUALIZE_ERROR:
#         remove_error_spheres(sphere_ids)
#     prev_angles = optimal_angles.copy()
#
# p.disconnect()






# # UNCODE LATER
# # -------------------------
# # Hardcoded example of using a simple 3-DoF robot to save landmarks Updated.
# # -------------------------
#
# import numpy as np
# import csv
#
# def roty(theta):
#     c, s = np.cos(theta), np.sin(theta)
#     return np.array([[c, 0, s, 0],
#                      [0, 1, 0, 0],
#                      [-s, 0, c, 0],
#                      [0, 0, 0, 1]])
#
# def trans(x, y, z):
#     T = np.eye(4)
#     T[:3, 3] = [x, y, z]
#     return T
#
# # Link lengths (edit as per your URDF)
# L1 = 0.2
# L2 = 0.2
# L3 = 0.2
#
# NUM_FRAMES = 50
# NUM_LANDMARKS = 4
# header = [f'V{i+1}{ax}' for i in range(NUM_LANDMARKS) for ax in ['x', 'y', 'z']]
# all_landmarks = []
#
# for frame in range(NUM_FRAMES):
#     t = frame / (NUM_FRAMES - 1)
#     # Base joint1: fixed
#     theta1 = 0
#
#     # Joint2 and Joint3: sweep to simulate "pick up near ground → swing over → put down near ground"
#     # Example: joint2 sweeps from -90° (down) to +90° (up), joint3 bends to keep tip low
#     theta2 = -np.pi/2 + np.pi * t   # joint2: from down to up
#     theta3 = -np.pi/2 + np.pi * t   # joint3: from bent to extended
#
#     # 1. Base landmark
#     base = np.array([0, 0, 0])
#
#     # 2. Landmark after link1: always at (0, 0, L1)
#     link1 = np.array([0, 0, L1])
#
#     # 3. Landmark after link2: apply joint2 rotation about Y, then translate along Z by L2
#     T = trans(0, 0, L1) @ roty(theta2) @ trans(0, 0, L2)
#     link2 = T[:3, 3]
#
#     # 4. Tip landmark: apply joint3 rotation about Y, then translate along Z by L3
#     T_tip = T @ roty(theta3) @ trans(0, 0, L3)
#     tip = T_tip[:3, 3]
#
#     frame_landmarks = list(base) + list(link1) + list(link2) + list(tip)
#     all_landmarks.append(frame_landmarks)
#
# with open('physically_plausible_trajectory_urdf_axes.csv', 'w', newline='') as f:
#     writer = csv.writer(f)
#     writer.writerow(header)
#     writer.writerows(all_landmarks)
#
# print("✅ Corrected vertical arm trajectory saved to physically_plausible_trajectory_urdf_axes.csv")
#
# # -------------------------
# # Aligning landmarks to remove translation and rotation
# # -------------------------
#
# import numpy as np
# import pandas as pd
#
# def align_landmarks(data):
#     """
#     Aligns robot landmark data by removing translation (base to origin)
#     and rotation (aligns link1 to Z axis).
#     Args:
#         data: shape (n_frames, n_landmarks, 3)
#     Returns:
#         aligned_data: shape (n_frames, n_landmarks, 3)
#     """
#     n_frames, n_landmarks, _ = data.shape
#     aligned = np.zeros_like(data)
#     # Reference direction: always align link1 (landmark 2 - landmark 1) to Z axis
#     ref_axis = np.array([0, 0, 1])
#
#     for i in range(n_frames):
#         frame = data[i]
#
#         # Remove translation: base at origin
#         base = frame[0]
#         frame_t = frame - base
#
#         # Remove rotation: align (link1 - base) with ref_axis (Z)
#         v = frame_t[1]  # vector from base to link1
#         if np.linalg.norm(v) == 0:
#             R = np.eye(3)
#         else:
#             # Find rotation matrix that maps v to ref_axis
#             v_norm = v / np.linalg.norm(v)
#             axis = np.cross(v_norm, ref_axis)
#             angle = np.arccos(np.clip(np.dot(v_norm, ref_axis), -1, 1))
#             if np.linalg.norm(axis) < 1e-8 or angle == 0:
#                 R = np.eye(3)
#             else:
#                 axis = axis / np.linalg.norm(axis)
#                 K = np.array([[0, -axis[2], axis[1]],
#                               [axis[2], 0, -axis[0]],
#                               [-axis[1], axis[0], 0]])
#                 R = np.eye(3) + np.sin(angle)*K + (1-np.cos(angle))*(K@K)
#         # Apply rotation
#         frame_aligned = (R @ frame_t.T).T
#         aligned[i] = frame_aligned
#
#     return aligned
#
# # Usage:
# n_frames = 50
# n_landmarks = 4
# data = np.loadtxt('physically_plausible_trajectory_urdf_axes.csv', delimiter=',', skiprows=1).reshape(n_frames, n_landmarks, 3)
# aligned_data = align_landmarks(data)
#
# # Save aligned data to CSV
# def save_aligned_landmarks(aligned_data, filename='aligned_landmarks.csv'):
#     """
#     Save aligned landmarks (n_frames, n_landmarks, 3) to a CSV file.
#     Columns: V1x, V1y, V1z, V2x, V2y, V2z, ..., V4x, V4y, V4z
#     """
#     n_frames, n_landmarks, _ = aligned_data.shape
#     columns = [f'V{i+1}{ax}' for i in range(n_landmarks) for ax in ['x', 'y', 'z']]
#     flat_data = aligned_data.reshape(n_frames, n_landmarks * 3)
#     df = pd.DataFrame(flat_data, columns=columns)
#     df.to_csv(filename, index=False)
#     print(f"✅ Saved aligned landmarks to {filename}")
#
# # Example usage:
# save_aligned_landmarks(aligned_data, 'aligned_landmarks.csv')

# -------------------------
# Save aligned landmarks in the format expected by R regression model
# -------------------------

# def save_landmarks_for_r_regression(aligned_data, filename='aligned_landmarks.csv'):
#     """
#     Save aligned landmarks to CSV in the format (landmarks, coords, frames) as expected by the R regression model.
#     Each column: V1x, V1y, V1z, V2x, ... for each frame (matches R expectation).
#     """
#     # aligned_data: (num_frames, num_landmarks, 3)
#     num_frames, num_landmarks, num_coords = aligned_data.shape
#
#     # Reorder to (num_landmarks, num_coords, num_frames) in Fortran order
#     data_for_r = aligned_data.transpose(1, 2, 0)  # (landmarks, coords, frames)
#
#     # Flatten as columns: for each frame, all landmarks & coords
#     # This matches the way you loaded CSV originally: data_flat = df.to_numpy()
#     data_flat = data_for_r.reshape(num_landmarks * num_coords, num_frames, order='F').T
#
#     # Build column headers to match your regression model's expectation
#     columns = []
#     for v in range(num_landmarks):
#         for ax in ['x', 'y', 'z']:
#             columns.append(f'V{v+1}{ax}')
#     df = pd.DataFrame(data_flat, columns=columns)
#     df.to_csv(filename, index=False)
#     print(f"✅ Saved landmarks for R regression model to {filename}")
#
# # Example usage:
# save_landmarks_for_r_regression(aligned_data, 'aligned_landmarks.csv')

# -------------------------
# Example of plotting the saved trajectory using matplotlib
# -------------------------
#
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D  # Needed for 3D plots
#
# def plot_landmarks_3d(landmarks, frame=None, show_links=True, ax=None):
#     """
#     Plot a single frame of landmarks in 3D.
#     landmarks: (num_frames, num_landmarks, 3) or (num_landmarks, 3)
#     frame: int or None. If None, plot all frames as a trajectory.
#     show_links: connect landmarks in order.
#     ax: Matplotlib 3D axis (optional).
#     """
#     points = landmarks[frame]
#     fig = plt.figure()
#     ax = fig.add_subplot(111, projection='3d')
#     colors = ['red', 'green', 'blue', 'yellow']
#     for i, (x, y, z) in enumerate(points):
#         ax.scatter(x, y, z, color=colors[i % len(colors)], s=60)
#         ax.text(x, y, z, f"L{i + 1}", fontsize=10)
#     if show_links:
#         ax.plot(points[:, 0], points[:, 1], points[:, 2], color='gray', linewidth=2, marker='o')
#     ax.set_xlabel('X')
#     ax.set_ylabel('Y')
#     ax.set_zlabel('Z')
#     ax.set_title(f"Landmarks (Frame {frame})")
#     plt.tight_layout()
#     plt.show()
#
# def animate_landmarks(landmarks, interval=100):
#     """
#     Animate the landmarks over all frames.
#     landmarks: (num_frames, num_landmarks, 3)
#     """
#     from matplotlib import animation
#
#     num_frames = landmarks.shape[0]
#     fig = plt.figure()
#     ax = fig.add_subplot(111, projection='3d')
#
#     def update(frame):
#         ax.cla()
#         plot_landmarks_3d(landmarks, frame=frame, ax=ax)
#         ax.set_title(f"Frame {frame+1}/{num_frames}")
#
#     ani = animation.FuncAnimation(fig, update, frames=num_frames, interval=interval, repeat=True)
#     plt.show()
#     # Optionally, save animation:
#     # ani.save("landmarks_animation.gif", writer="imagemagick")
#
# # ======= Example usage ========
#
# # Load aligned landmarks from CSV
# import pandas as pd
# def load_landmarks_from_r_save(filename):
#     """
#     Loads the CSV saved for R (landmarks, coords, frames) and reshapes to (num_frames, num_landmarks, 3)
#     """
#     data = pd.read_csv(filename).to_numpy()
#     # data shape: (num_frames, num_landmarks*3)
#     num_frames = data.shape[0]
#     num_landmarks = data.shape[1] // 3
#     # For each frame, the data is: V1x, V1y, V1z, V2x, V2y, V2z, ...
#     # This is correct for reshaping to (num_frames, num_landmarks, 3)
#     landmarks = data.reshape(num_frames, num_landmarks, 3)
#     return landmarks
# data = load_landmarks_from_r_save('aligned_landmarks.csv')
# num_frames = data.shape[0]
# num_landmarks = data.shape[1] // 3
# landmarks = data.reshape(num_frames, num_landmarks, 3)
#
# # Plot a single frame (e.g., frame 0)
# plot_landmarks_3d(landmarks, frame=0)
# plt.show()
#
# # Animate all frames
# animate_landmarks(landmarks, interval=150)


# # UNCODE LATER
# # -------------------------
# # Example of plotting the saved trajectory using matplotlib - in animation style
# # -------------------------
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
# from matplotlib.animation import FuncAnimation
#
# # --- CONFIGURATION ---
# csv_filename = "aligned_landmarks.csv"
# num_landmarks = 4  # Change if using more/less
# interval = 100     # Delay between frames in ms (adjust speed)
# colors = ["r", "g", "b", "y", "c", "m", "k"]
# # ---------------------
#
# # Load data, skipping header
# data = np.loadtxt(csv_filename, delimiter=",", skiprows=1)
# # data = aligned_data
# num_frames = data.shape[0]
# coords = data.reshape(num_frames, num_landmarks, 3)
# # print("First row:", coords[0])
# # print("Expected format:  [[x1,y1,z1][x2,y2,z2][x3,y3,z3][x4,y4,z4]]")
#
# # Set up figure and axis
# fig = plt.figure()
# ax = fig.add_subplot(111, projection="3d")
#
# # Set plot limits based on data
# all_x = coords[:, :, 0].flatten()
# all_y = coords[:, :, 1].flatten()
# all_z = coords[:, :, 2].flatten()
# ax.set_xlim([np.min(all_x)-0.05, np.max(all_x)+0.05])
# ax.set_ylim([np.min(all_y)-0.05, np.max(all_y)+0.05])
# ax.set_zlim([np.min(all_z)-0.05, np.max(all_z)+0.05])
#
# # For scatter, we need to re-create the scatter objects each time
# scatters = []
# for i in range(num_landmarks):
#     scatter = ax.scatter([], [], [], color=colors[i % len(colors)], label=f"Landmark {i+1}")
#     scatters.append(scatter)
# # Create a line object for the arm links
# [line] = ax.plot([], [], [], 'k-', linewidth=2, alpha=0.4)
#
# ax.set_xlabel('X')
# ax.set_ylabel('Y')
# ax.set_zlabel('Z')
# ax.legend()
# ax.set_title("Robot Landmarks Animation")
#
# def init():
#     for scatter in scatters:
#         scatter._offsets3d = ([], [], [])
#     line.set_data([], [])
#     line.set_3d_properties([])
#     return scatters + [line]
#
# def update(frame):
#     # Update the scatter for each landmark
#     for i, scatter in enumerate(scatters):
#         x = [coords[frame, i, 0]]
#         y = [coords[frame, i, 1]]
#         z = [coords[frame, i, 2]]
#         scatter._offsets3d = (x, y, z)
#     # Update the line that connects the landmarks in order
#     line.set_data(coords[frame, :, 0], coords[frame, :, 1])
#     line.set_3d_properties(coords[frame, :, 2])
#     ax.set_title(f"Robot Landmarks Animation - Frame {frame+1}/{num_frames}")
#     return scatters + [line]
#
# ani = FuncAnimation(fig, update, frames=num_frames, init_func=init, blit=False, interval=interval, repeat=True)
# plt.show()