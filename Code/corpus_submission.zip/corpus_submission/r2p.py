# -----------------------------
# 0. Plot the output in matplotlib (Change of shape in animation)
# -----------------------------
# Optional next: animate skeleton using matplotlib.animation
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import animation


def animate_skeleton(data, interval=200, name="Skeleton Animation"):
    assert data.ndim == 3, f"Expected data with 3 dimensions (landmarks, 3, frames), got {data.shape}"
    assert data.shape[1] == 3, f"Expected 3D coordinates in second dimension, got {data.shape[1]}"

    n_landmarks, _, n_frames = data.shape
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    scat = ax.scatter([], [], [], color='crimson', s=60)
    lines = []

    # Define landmark connections safely (only include if within bounds)
    raw_connections = [
        (0, 1), (1, 2), (2, 3), (3, 4),
        (0, 5), (5, 6), (6, 7), (7, 8),
        (0, 9), (9, 10), (10, 11), (11, 12),
        (0, 13), (13, 14), (14, 15), (15, 16),
        (0, 17), (17, 18), (18, 19), (19, 20)
    ]
    connections = [(i, j) for i, j in raw_connections if i < n_landmarks and j < n_landmarks]

    # Create empty lines for connections
    for _ in connections:
        lines.append(ax.plot([], [], [], color='gray', linewidth=2)[0])

    def init():
        ax.set_xlim(np.min(data[:, 0, :]), np.max(data[:, 0, :]))
        ax.set_ylim(np.min(data[:, 1, :]), np.max(data[:, 1, :]))
        ax.set_zlim(np.min(data[:, 2, :]), np.max(data[:, 2, :]))
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title(name)
        return [scat] + lines

    def update(frame):
        landmarks = data[:, :, frame]  # shape (n_landmarks, 3)
        scat._offsets3d = (landmarks[:, 0], landmarks[:, 1], landmarks[:, 2])
        for idx, (i, j) in enumerate(connections):
            try:
                xs = [landmarks[i, 0], landmarks[j, 0]]
                ys = [landmarks[i, 1], landmarks[j, 1]]
                zs = [landmarks[i, 2], landmarks[j, 2]]
                lines[idx].set_data(xs, ys)
                lines[idx].set_3d_properties(zs)
            except IndexError:
                print(f"Invalid index at frame {frame}: {i}, {j}")
        return [scat] + lines

    ani = animation.FuncAnimation(fig, update, frames=n_frames, init_func=init,
                                  blit=False, interval=interval, repeat=True)
    plt.show()




# ----------------------
# --- FINAL FUNCTION ---
# ----------------------

def size_shape_regression_length_constrained(data_3d, connections, lengths, anchor_indices, poly_model=True, poly_smoothing=True):

    # ------------------------------------------------
    # SIZE AND SHAPE REGRESSION WITH LENGTH CONSTRAINED
    # ------------------------------------------------
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression
    # --- Regression model from R ---
    import os
    import numpy as np

    # -----------------------------
    # 1. Environment Setup
    # -----------------------------
    #                                               IMPORTANT
    #                               THIS SETUP WILL VARY DEPENDING ON YOUR COMPUTER
    #                               THIS PART OF THE CODE MUST BE CHANGE BEFORE USING ON YOUR SETUP
    os.environ["R_HOME"] = "D:/inne/R-4.5.1"
    os.environ["HOME"] = "D:/inne/RWork"
    os.environ["R_USER"] = "D:/inne/RWork"
    os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
    os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
    os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility

    # -----------------------------
    # 2. rpy2 Imports and Conversions
    # -----------------------------
    from rpy2 import robjects
    from rpy2.robjects import r, pandas2ri, default_converter
    from rpy2.robjects.conversion import localconverter
    from rpy2.rinterface import FloatSexpVector
    from rpy2.robjects.vectors import IntVector

    # Optional: suppress warnings
    import warnings
    warnings.filterwarnings("ignore", category=UserWarning) #Still triggers most of the errors

    # -----------------------------
    # 3. Set R Working Directory
    # -----------------------------
    #                                               IMPORTANT
    #                               THIS SETUP WILL VARY DEPENDING ON YOUR COMPUTER
    #                               THIS PART OF THE CODE MUST BE CHANGE BEFORE USING ON YOUR SETUP
    r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/corpus_submission")')  # R script directory
    r('source("mainEM_3d_size_shape.r")')  # directory to the R script
    print("✅ R working directory set to:", r('getwd()')[0])

    # --------------------------------------
    # 3. Load CSV and prepare 3D NumPy array
    # --------------------------------------
    # No need as data are loaded now with the def function
    print("Plotting original landmarks...")
    animate_skeleton(data_3d, name="Original Landmarks")

    # -----------------------------
    # 4. Convert NumPy array to R array
    # -----------------------------
    data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
    data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
    robjects.globalenv["data"] = data_r_array

    # -----------------------------
    # 5. Permute in R and run EM polynomial regression
    # -----------------------------
    print("Running Size & Shape Regression...")
    r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
    r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')

    # -----------------------------
    # 6. Extract R outputs back to NumPy
    # -----------------------------
    with localconverter(default_converter + pandas2ri.converter):
        reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
        reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)

    print("Raw shape of reg_f_np:", reg_f_np.shape)
    print("Raw shape of reg_r_np:", reg_r_np.shape)

    # -----------------------------
    # 7. Transpose to standard Python shape: (21, 3, 10, N)
    # -----------------------------
    reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
    print("reg_f_np reshaped to:", reg_f_np.shape)

    if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
        reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
        print("reg_r_np reshaped to:", reg_r_np.shape)
    elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
        reg_r_np = reg_r_np.transpose(1, 0, 2)
        print("reg_r_np reshaped to:", reg_r_np.shape)
    else:
        print("⚠️ Unexpected reg_r_np shape — no transpose applied.")

    # -----------------------------
    # 8. Optionally remove last dim if N == 1
    # -----------------------------
    if reg_f_np.shape[-1] == 1:
        reg_f_np = reg_f_np[..., 0]
    if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
        reg_r_np = reg_r_np[..., 0]

    # -----------------------------
    # 9. Final Output
    # -----------------------------
    print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
    print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
    print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1]) #Usually it is 0.0 and 0.0
    reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
    reg_r_np = reg_r_np[..., 0]
    print("Size & Shape Regression Success")
    print("Plotting Size & Shape Regression landmarks...")
    animate_skeleton(reg_f_np, name="Size & Shape Regression")

    # # -------------------------------
    # # Polynomial Regression - regular
    # # -------------------------------
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.linear_model import LinearRegression
    import numpy as np

    def polynomial_regression_with_models(data, degree=3):
        """
        Fits polynomial regression for each landmark and coordinate.
        Returns:
          - predicted_landmarks: shape (landmarks, coords, frames)
          - models: models[landmark][coord] = LinearRegression object
          - poly: PolynomialFeatures object
        """
        num_landmarks, num_dims, num_frames = data.shape
        time = np.arange(num_frames).reshape(-1, 1)
        poly = PolynomialFeatures(degree)
        X_time = poly.fit_transform(time)
        predicted = np.zeros_like(data)
        models = [[None for _ in range(num_dims)] for _ in range(num_landmarks)]
        for l in range(num_landmarks):
            for d in range(num_dims):
                y = data[l, d, :]
                model = LinearRegression().fit(X_time, y)
                predicted[l, d, :] = model.predict(X_time)
                models[l][d] = model
        return predicted, models, poly

    if poly_smoothing:
        print("Running Polynomial Regression...")
        predicted, models, poly = polynomial_regression_with_models(reg_f_np, degree=3)
        print("Polynomial Regression Success")
        print("Plotting Polynomial Regression landmarks...")  # Should be (4, 3, n_frames)
        animate_skeleton(predicted, name="Polynomial Regression")
    else:
        print("Polynomial Regression omitted due function config.")
        predicted = reg_f_np


    # ------------------------------
    # Polynomial Regression - Models
    # ------------------------------
    import matplotlib.pyplot as plt
    from matplotlib.widgets import Slider

    # --- Assume you have fitted models and poly object ---
    # models, poly = fit_poly_models(data_3d, degree=3)
    # data_3d: shape (landmarks, coords, frames)

    def predict_landmarks(models, poly, t):
        X_query = poly.transform(np.array([[t]]))
        n_landmarks = len(models)
        n_coords = len(models[0])
        pred = np.zeros((n_landmarks, n_coords))
        for l in range(n_landmarks):
            for c in range(n_coords):
                pred[l, c] = models[l][c].predict(X_query)[0]
        return pred

    def plot_hand_landmarks(ax, landmarks, color='blue'):
        ax.clear()
        x, y, z = landmarks[:, 0], landmarks[:, 1], landmarks[:, 2]
        ax.scatter(x, y, z, color=color, s=50)
        # Connect landmarks as skeleton (optional: add your connections)
        connections = [(0, 1), (1, 2), (2, 3), (3, 4),
                       (0, 5), (5, 6), (6, 7), (7, 8),
                       (0, 9), (9, 10), (10, 11), (11, 12),
                       (0, 13), (13, 14), (14, 15), (15, 16),
                       (0, 17), (17, 18), (18, 19), (19, 20)]
        for i, j in connections:
            ax.plot([x[i], x[j]], [y[i], y[j]], [z[i], z[j]], color='gray')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('Hand Landmarks')
        ax.set_box_aspect([1, 1, 1])
        ax.figure.canvas.draw_idle()

    def interactive_hand_matplotlib(models, poly, n_frames):
        # Initial figure setup
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        plt.subplots_adjust(bottom=0.25)
        t0 = 0
        landmarks = predict_landmarks(models, poly, t0)
        plot_hand_landmarks(ax, landmarks)

        # Slider setup
        ax_slider = plt.axes([0.15, 0.1, 0.7, 0.03])
        slider = Slider(ax_slider, 'Frame (t)', 0, n_frames - 1, valinit=t0, valstep=0.1)

        def update(val):
            t = slider.val
            lm = predict_landmarks(models, poly, t)
            plot_hand_landmarks(ax, lm)

        slider.on_changed(update)
        plt.show()

    if poly_model & poly_smoothing:
        print("Plotting Interactive Polynomial Regression Model...")  # Should be (4, 3, n_frames)
        # models, poly = fit_poly_models(reg_f_np, degree=3)
        interactive_hand_matplotlib(models, poly, n_frames=reg_f_np.shape[2])
    elif poly_model == True & poly_smoothing == False:
        print("Plotting Interactive Polynomial Regression Model...")
        p, models, poly = polynomial_regression_with_models(reg_f_np, degree=3)
        interactive_hand_matplotlib(models, poly, n_frames=reg_f_np.shape[2])


    # ----------------------------
    # Length constrained alignment
    # ----------------------------
    import numpy as np
    from scipy.optimize import minimize

    def length_constrained_alignment(predicted, reference, connections, lengths, anchor_indices=[0], max_iter=200):
        """
        Aligns predicted to reference using nonlinear optimization:
        - Anchors specified indices exactly
        - Preserves segment lengths given by 'connections' and 'lengths'
        - Attempts to match reference pose as closely as possible

        Parameters:
        - predicted: np.ndarray of shape (21, 3)
        - reference: np.ndarray of shape (21, 3)
        - connections: list of (i,j) pairs (landmark indices)
        - lengths: list of floats, desired segment lengths
        - anchor_indices: indices to anchor exactly to reference
        - max_iter: maximum optimization iterations (default 200)

        Returns:
        - aligned: np.ndarray of shape (21, 3)
        """
        n_landmarks = predicted.shape[0]

        def loss(x):
            # x is flattened (21 * 3)
            x = x.reshape((n_landmarks, 3))
            # 1. Anchors: penalize deviation from reference
            anchor_loss = np.sum((x[anchor_indices] - reference[anchor_indices]) ** 2)
            # 2. Lengths: penalize deviation from desired lengths
            length_loss = 0
            for (idx, (i, j)) in enumerate(connections):
                seg_length = np.linalg.norm(x[i] - x[j])
                length_loss += (seg_length - lengths[idx]) ** 2
            # 3. Global RMSD: encourage closeness to reference
            rmsd_loss = np.sum((x - reference) ** 2)
            # Blend weights (adjust for your use-case)
            total_loss = anchor_loss * 100 + length_loss * 100 + rmsd_loss * 1
            return total_loss

        x0 = predicted.flatten()
        res = minimize(loss, x0, method='L-BFGS-B', options={'maxiter': max_iter})
        aligned = res.x.reshape((n_landmarks, 3))
        return aligned

    # Example frame-loop usage
    def batch_length_constrained_alignment(predicted_array, reference_array, connections, lengths, anchor_indices=[0],
                                           max_iter=200):
        """
        Aligns all frames in arrays of shape (21, 3, n_frames)
        Returns aligned_array of same shape.
        """
        n_landmarks, n_coords, n_frames = predicted_array.shape
        aligned_array = np.zeros_like(predicted_array)
        for t in range(n_frames):
            aligned = length_constrained_alignment(
                predicted_array[:, :, t],
                reference_array[:, :, t],
                connections,
                lengths,
                anchor_indices=anchor_indices,
                max_iter=max_iter
            )
            aligned_array[:, :, t] = aligned
        return aligned_array

    # Usage example:
    print("Running Length Constrained Alignment...")
    aligned = batch_length_constrained_alignment(predicted, data_3d, connections, lengths, anchor_indices)
    print("Length Constrained Alignment Success")
    print("Plotting Length Constrained Alignment...")
    animate_skeleton(aligned, name="Length-Constrained Alignment")

    return aligned


# --------------------------
# Running simulation with landmarks (simple hand)
# --------------------------
# expected shape: (landmarks, coords, frames)
def Pybullet_simulation(data, URDF_PATH="D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/corpus_submission/urdf/twenty_one_landmark_hand.urdf", SLEEP_TIME=0.05):
    import pybullet as p
    import pybullet_data
    import numpy as np
    import pandas as pd
    import time
    from scipy.optimize import minimize

    # --- CONFIGURATION ---
    VISUALIZE_ERROR = True  # Show error in GUI
    ERROR_SPHERE_RADIUS = 0.01  # Spheres for error visualization

    # --- LOAD LANDMARKS ---
    print("Simulation landmarks shape: ", data.shape) #expected shape: (landmarks, coords, frames)
    landmarks = data.transpose(2, 0, 1)  # Transpose to (frames, landmarks, 3)
    n_frames = landmarks.shape[0]
    print("After tanspose: ", landmarks.shape, "Frames: ", n_frames)

    # --- PYBULLET SETUP ---
    p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    hand = p.loadURDF(URDF_PATH, [0, 0, 0], useFixedBase=True)

    # --- GET LINK AND JOINT INDICES AUTOMATICALLY ---
    def get_all_joint_info(body_id):
        n_joints = p.getNumJoints(body_id)
        joints = []
        links = []
        for i in range(n_joints):
            info = p.getJointInfo(body_id, i)
            joints.append(info[1].decode("utf-8"))
            links.append(info[12].decode("utf-8"))
        return joints, links

    joint_names, link_names = get_all_joint_info(hand)

    # Map landmark names to link indices (palm is -1 in PyBullet)
    landmark_link_names = [
        "palm",
        "thumb_link1", "thumb_link2", "thumb_link3", "thumb_tip",
        "index_link1", "index_link2", "index_link3", "index_tip",
        "middle_link1", "middle_link2", "middle_link3", "middle_tip",
        "ring_link1", "ring_link2", "ring_link3", "ring_tip",
        "little_link1", "little_link2", "little_link3", "little_tip"
    ]
    landmark_link_indices = []
    for name in landmark_link_names:
        if name == "palm":
            landmark_link_indices.append(-1)
        else:
            try:
                idx = link_names.index(name)
                landmark_link_indices.append(idx)
            except ValueError:
                print(f"WARNING: Link name {name} not found!")
                landmark_link_indices.append(None)

    # Get all joint indices (15 joints: 3 x 5 fingers)
    finger_joint_names = [
        "thumb_joint1", "thumb_joint2", "thumb_joint3",
        "index_joint1", "index_joint2", "index_joint3",
        "middle_joint1", "middle_joint2", "middle_joint3",
        "ring_joint1", "ring_joint2", "ring_joint3",
        "little_joint1", "little_joint2", "little_joint3"
    ]
    joint_indices = []
    for name in finger_joint_names:
        try:
            joint_indices.append(joint_names.index(name))
        except ValueError:
            print(f"WARNING: Joint name {name} not found!")

    # --- FK UTILITY: GET ALL LANDMARK POSITIONS FOR GIVEN JOINT ANGLES ---
    def get_hand_landmark_positions(hand, joint_angles):
        # Set joint angles
        for ji, angle in zip(joint_indices, joint_angles):
            p.resetJointState(hand, ji, angle)
        p.stepSimulation()
        # Get all landmark positions
        positions = []
        for idx in landmark_link_indices:
            if idx == -1:
                pos, _ = p.getBasePositionAndOrientation(hand)
            elif idx is None:
                pos = (np.nan, np.nan, np.nan)
            else:
                state = p.getLinkState(hand, idx)
                pos = state[0] if state else (np.nan, np.nan, np.nan)
            positions.append(np.array(pos))
        return np.array(positions)

    # --- LOSS FUNCTION: SUM SQUARED DISTANCES ---
    def pose_loss(joint_angles, hand, target_landmarks):
        predicted = get_hand_landmark_positions(hand, joint_angles)
        return np.sum((predicted - target_landmarks) ** 2)

    # --- JOINT LIMITS ---
    lower = [0.0] * len(joint_indices)
    upper = [1.5] * len(joint_indices)
    joint_bounds = [(l, u) for l, u in zip(lower, upper)]

    # --- ERROR VISUALIZATION ---
    def draw_error_spheres(targets, actuals, color=[1, 0, 0, 0.6], radius=ERROR_SPHERE_RADIUS):
        sphere_ids = []
        for t, a in zip(targets, actuals):
            err = np.linalg.norm(t - a)
            # Color: green if error < 0.01, red otherwise
            c = [0, 1, 0, 0.6] if err < 0.01 else color
            s_id = p.createVisualShape(p.GEOM_SPHERE, rgbaColor=c, radius=radius)
            sphere_ids.append(p.createMultiBody(baseMass=0, baseVisualShapeIndex=s_id, basePosition=t))
        return sphere_ids

    def remove_error_spheres(sphere_ids):
        for sid in sphere_ids:
            p.removeBody(sid)

    # --- OPTIMIZATION AND ANIMATION LOOP ---
    prev_angles = np.zeros(len(joint_indices))
    time.sleep(SLEEP_TIME * 5)
    for frame in range(n_frames):
        print(f"Frame {frame + 1}/{n_frames}")
        target_landmarks = landmarks[frame]
        # Optimize joint angles to minimize loss
        result = minimize(
            pose_loss, prev_angles,
            args=(hand, target_landmarks),
            method="L-BFGS-B",
            bounds=joint_bounds,
            options={'maxiter': 200}
        )
        optimal_angles = result.x
        # Apply angles to hand
        for ji, angle in zip(joint_indices, optimal_angles):
            p.resetJointState(hand, ji, angle)
        p.stepSimulation()
        # Get achieved positions
        achieved_landmarks = get_hand_landmark_positions(hand, optimal_angles)
        # Visualize error
        sphere_ids = []
        if VISUALIZE_ERROR:
            sphere_ids = draw_error_spheres(target_landmarks, achieved_landmarks)
        # Print mean error for the frame
        mean_error = np.mean(np.linalg.norm(achieved_landmarks - target_landmarks, axis=1))
        print(f"Mean landmark error: {mean_error:.4f} meters")
        time.sleep(SLEEP_TIME)
        if VISUALIZE_ERROR:
            remove_error_spheres(sphere_ids)
        prev_angles = optimal_angles.copy()

    p.disconnect()



# ------------------------
# --- Loading the data ---
# ------------------------

import pandas as pd

# --- landmarks of dummy hand ---
n_landmarks = 21
n_coords = 3
df = pd.read_csv('./trajectories/realistic_hand_landmarks.csv',  header=None) #Directory to the CSV file
data_flat = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
n_frames = data_flat.shape[0]
data_3d = data_flat.reshape(n_frames, n_landmarks, n_coords)  # (15 frmaes, 21 landmarks, 3D)
print("Shape of initial data: ", data_3d.shape)
data_3d = data_3d.transpose(1, 2, 0)  # Transpose to (landmarks, 3, frames)

# # --- landmarks of professor's hand ---
# df = pd.read_csv('./corpus_submission/trajectories/my_3d_array.csv')  # Directory to the CSV file
# data_flat = df.to_numpy()
# # print("First row:", data_flat[0])
# # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# data_3d = data_flat.T.reshape((21, 3, 10), order='F')  # (21 landmarks, 3D, 10 samples)

connections = [(0, 1), (1, 2), (2, 3), (3, 4),  # Thumb
               (0, 5), (5, 6), (6, 7), (7, 8),  # Index
               (0, 9), (9, 10), (10, 11), (11, 12),  # Middle
               (0, 13), (13, 14), (14, 15), (15, 16),  # Ring
               (0, 17), (17, 18), (18, 19), (19, 20)]  # Little        # index pairs

# lengths = [0.040, 0.033, 0.028, 0.024,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015]  # measured from professor's hand

lengths = [0.054, 0.05, 0.044, 0.044,
           0.066, 0.058, 0.05, 0.05,
           0.07, 0.062, 0.054, 0.054,
           0.066, 0.058, 0.05, 0.05,
           0.056, 0.046, 0.04, 0.04] #measured from dummy hand

# --------------------------
# --- RUN THE SIMULATION ---
# --------------------------

# Expected input:
#   - 'data_3d' (set of landmarks, which follows pattern: [landmarks, coords, frames]),
#   - 'connections' (list of paired connections in robot)
#   - 'lengths' (list in size of connections' length determining length of each connection)
#   - 'anchor_indices' (optional argument which anchor chosen point/s in the location of the original robot. Real expectation in robot regression/simulation)
#   - 'poly_gate' (optional argument that runs polynomial regression model, smoothens out the data, sometimes improving the Pybullet simulation)
# Expected output:
#   - 'regressed_landmarks' (set of size&shape regressed landmarks fitting for Pybullet simulation, plotting or other purposes)
result = size_shape_regression_length_constrained(data_3d=data_3d, connections=connections, lengths=lengths, anchor_indices=[0, 1, 5, 9, 13, 17], poly_model=True, poly_smoothing=True)
# result = size_shape_regression_length_constrained(data_3d=data_3d, connections=connections, lengths=lengths, anchor_indices=[0], poly_model=True, poly_smoothing=True) #use for professor's hand
#Expected input:
#   - 'data' (set of landmarks, which follows pattern: [landmarks, coords, frames])
#   - 'URDF_PATH' (path to your robot, that simulation will be run by, use robot that you used for capturing the landmarks)
#   - 'SLEEP_TIME' (Defines speed between the frames in the simulation)
#Expected output:
#   - Pybullet simulation (NOT THE ACTUAL PARAMETER)
Pybullet_simulation(result, URDF_PATH="./urdf/twenty_one_landmark_hand.urdf", SLEEP_TIME=0.05) #Works only for dummy hand, we don't have robot for professor's hand








# # --- Regression model from R ---
#
# import os
# import numpy as np
# import pandas as pd
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# # -----------------------------
# # 2. rpy2 Imports and Conversions
# # -----------------------------
# from rpy2 import robjects
# from rpy2.robjects import r, pandas2ri, default_converter
# from rpy2.robjects.conversion import localconverter
# from rpy2.rinterface import FloatSexpVector
# from rpy2.robjects.vectors import IntVector
#
# # Optional: suppress warnings
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning)
#
# # -----------------------------
# # 3. Set R Working Directory
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  #R script directory
# r('source("mainEM_3d_size_shape.r")')   #directory to the R script
# print("✅ R working directory set to:", r('getwd()')[0])
#
# # -----------------------------
# # 3. Load CSV and prepare 3D NumPy array
# # -----------------------------
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv') #Directory to the CSV file
# data_flat = df.to_numpy()
# # print("First row:", data_flat[0])
# # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# data_3d = data_flat.T.reshape((21, 3, 10), order='F')  # (21 landmarks, 3D, 10 samples)
#
# animate_skeleton(data_3d, name="Original landmarks (when correctly loaded)")
# # -----------------------------
# # 4. Convert NumPy array to R array
# # -----------------------------
# data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
# data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
# robjects.globalenv["data"] = data_r_array
#
# # -----------------------------
# # 5. Permute in R and run EM polynomial regression
# # -----------------------------
# r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
# r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
# # -----------------------------
# # 6. Extract R outputs back to NumPy
# # -----------------------------
# with localconverter(default_converter + pandas2ri.converter):
#     reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
#     reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)
#
# print("Raw shape of reg_f_np:", reg_f_np.shape)
# print("Raw shape of reg_r_np:", reg_r_np.shape)
#
# # -----------------------------
# # 7. Transpose to standard Python shape: (21, 3, 10, N)
# # -----------------------------
# reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
# print("reg_f_np reshaped to:", reg_f_np.shape)
#
# if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# else:
#     print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
# # -----------------------------
# # 8. Optionally remove last dim if N == 1
# # -----------------------------
# if reg_f_np.shape[-1] == 1:
#     reg_f_np = reg_f_np[..., 0]
# if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#     reg_r_np = reg_r_np[..., 0]
#
#
# # -----------------------------
# # 9. Final Output
# # -----------------------------
# print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
# print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
# print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1])
# reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
# reg_r_np = reg_r_np[..., 0]
#
# animate_skeleton(reg_f_np, name="Size&Shape Regression")

# # --- Regression model from R ---
#
# import os
# import numpy as np
# import pandas as pd
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# # -----------------------------
# # 2. rpy2 Imports and Conversions
# # -----------------------------
# from rpy2 import robjects
# from rpy2.robjects import r, pandas2ri, default_converter
# from rpy2.robjects.conversion import localconverter
# from rpy2.rinterface import FloatSexpVector
# from rpy2.robjects.vectors import IntVector
#
# # Optional: suppress warnings
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning)
#
# # -----------------------------
# # 3. Set R Working Directory
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  #R script directory
# r('source("mainEM_3d_size_shape.r")')   #directory to the R script
# print("✅ R working directory set to:", r('getwd()')[0])
#
# # -----------------------------
# # 3. Load CSV and prepare 3D NumPy array
# # -----------------------------
# n_landmarks = 21
# n_coords = 3
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/realistic_hand_landmarks.csv',  header=None) #Directory to the CSV file
# data_flat = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
# n_frames = data_flat.shape[0]
# data_3d = data_flat.reshape(n_frames, n_landmarks, n_coords)  # (15 frmaes, 21 landmarks, 3D)
# print(data_3d.shape)
# data_3d = data_3d.transpose(1, 2, 0)  # Transpose to (landmarks, 3, frames)
#
# animate_skeleton(data_3d, name="Original landmarks (when correctly loaded)")
# # -----------------------------
# # 4. Convert NumPy array to R array
# # -----------------------------
# data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
# data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
# robjects.globalenv["data"] = data_r_array
#
# # -----------------------------
# # 5. Permute in R and run EM polynomial regression
# # -----------------------------
# r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
# r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
# # -----------------------------
# # 6. Extract R outputs back to NumPy
# # -----------------------------
# with localconverter(default_converter + pandas2ri.converter):
#     reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
#     reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)
#
# print("Raw shape of reg_f_np:", reg_f_np.shape)
# print("Raw shape of reg_r_np:", reg_r_np.shape)
#
# # -----------------------------
# # 7. Transpose to standard Python shape: (21, 3, 10, N)
# # -----------------------------
# reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
# print("reg_f_np reshaped to:", reg_f_np.shape)
#
# if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# else:
#     print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
# # -----------------------------
# # 8. Optionally remove last dim if N == 1
# # -----------------------------
# if reg_f_np.shape[-1] == 1:
#     reg_f_np = reg_f_np[..., 0]
# if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#     reg_r_np = reg_r_np[..., 0]
#
#
# # -----------------------------
# # 9. Final Output
# # -----------------------------
# print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
# print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
# print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1])
# reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
# reg_r_np = reg_r_np[..., 0]
#
# animate_skeleton(reg_f_np, name="Size&Shape Regression")

# # -----------------------------
# # 10. Plot the output in matplotlib (By change in time)(outdated)
# # -----------------------------
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib import cm
# import numpy as np
#
# # def plot_trajectories(data, title="Landmark Trajectories"):
# #     """
# #     Plot landmark trajectories in 3D with time-based coloring.
# #
# #     Parameters:
# #         data: np.ndarray of shape (landmarks, 3, frames)
# #     """
# #     if data.ndim != 3 or data.shape[1] != 3:
# #         raise ValueError(f"Unexpected data shape {data.shape}, expected (landmarks, 3, frames)")
# #
# #     n_landmarks, _, n_frames = data.shape
# #     fig = plt.figure(figsize=(10, 7))
# #     ax = fig.add_subplot(111, projection='3d')
# #     cmap = cm.get_cmap('viridis', n_frames)
# #
# #     for i in range(n_landmarks):
# #         x, y, z = data[i, 0], data[i, 1], data[i, 2]
# #
# #         # Plot line segments with time-color gradient
# #         for t in range(n_frames - 1):
# #             ax.plot(x[t:t + 2], y[t:t + 2], z[t:t + 2], color=cmap(t), linewidth=2)
# #
# #         # Optional: add scatter points to mark frame progression
# #         ax.scatter(x, y, z, c=range(n_frames), cmap=cmap, s=10)
# #
# #     ax.set_title(title)
# #     ax.set_xlabel("X")
# #     ax.set_ylabel("Y")
# #     ax.set_zlabel("Z")
# #     plt.colorbar(cm.ScalarMappable(cmap=cmap), ax=ax, label="Time Frame")
# #     plt.tight_layout()
# #     plt.show()
# #
# # # Example usage:
# # plot_trajectories(reg_f_np, title="Predicted Landmark Trajectories (reg_f_np)")
# # plot_trajectories(reg_r_np, title="Reconstructed Landmark Trajectories (reg_r_np)")

# # -----------------------------
# # 10. Plot the output in matplotlib (Change of shape in animation)
# # -----------------------------
#
# # Optional next: animate skeleton using matplotlib.animation
# from matplotlib import animation
#
# # Optional next: animate skeleton using matplotlib.animation
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib import animation
#
#
# def animate_skeleton(data, interval=200):
#     assert data.ndim == 3, f"Expected data with 3 dimensions (landmarks, 3, frames), got {data.shape}"
#     assert data.shape[1] == 3, f"Expected 3D coordinates in second dimension, got {data.shape[1]}"
#
#     n_landmarks, _, n_frames = data.shape
#     fig = plt.figure(figsize=(10, 8))
#     ax = fig.add_subplot(111, projection='3d')
#     scat = ax.scatter([], [], [], color='crimson', s=60)
#     lines = []
#
#     # Define landmark connections safely (only include if within bounds)
#     raw_connections = [
#         (0, 1), (1, 2), (2, 3), (3, 4),
#         (0, 5), (5, 6), (6, 7), (7, 8),
#         (0, 9), (9, 10), (10, 11), (11, 12),
#         (0, 13), (13, 14), (14, 15), (15, 16),
#         (0, 17), (17, 18), (18, 19), (19, 20)
#     ]
#     connections = [(i, j) for i, j in raw_connections if i < n_landmarks and j < n_landmarks]
#
#     # Create empty lines for connections
#     for _ in connections:
#         lines.append(ax.plot([], [], [], color='gray', linewidth=2)[0])
#
#     def init():
#         ax.set_xlim(np.min(data[:, 0, :]), np.max(data[:, 0, :]))
#         ax.set_ylim(np.min(data[:, 1, :]), np.max(data[:, 1, :]))
#         ax.set_zlim(np.min(data[:, 2, :]), np.max(data[:, 2, :]))
#         ax.set_xlabel('X')
#         ax.set_ylabel('Y')
#         ax.set_zlabel('Z')
#         ax.set_title("Skeleton Animation")
#         return [scat] + lines
#
#     def update(frame):
#         landmarks = data[:, :, frame]  # shape (n_landmarks, 3)
#         scat._offsets3d = (landmarks[:, 0], landmarks[:, 1], landmarks[:, 2])
#         for idx, (i, j) in enumerate(connections):
#             try:
#                 xs = [landmarks[i, 0], landmarks[j, 0]]
#                 ys = [landmarks[i, 1], landmarks[j, 1]]
#                 zs = [landmarks[i, 2], landmarks[j, 2]]
#                 lines[idx].set_data(xs, ys)
#                 lines[idx].set_3d_properties(zs)
#             except IndexError:
#                 print(f"Invalid index at frame {frame}: {i}, {j}")
#         return [scat] + lines
#
#     ani = animation.FuncAnimation(fig, update, frames=n_frames, init_func=init,
#                                   blit=False, interval=interval, repeat=True)
#     plt.show()
#
#
# animate_skeleton(reg_f_np)

# # -----------------------------
# # 10. Visualize in PyBullet (full skeleton)
# # -----------------------------
# import pybullet as p
# import pybullet_data
# import time
#
# # Scale landmarks to improve visibility in simulation
# scale = 5.0
# landmarks = reg_f_np * scale  # shape: (21, 3, frames)
# n_frames = landmarks.shape[2]
#
# # Define connections for a hand skeleton
# hand_connections = [
#     # Thumb
#     (0, 1), (1, 2), (2, 3), (3, 4),
#     # Index
#     (0, 5), (5, 6), (6, 7), (7, 8),
#     # Middle
#     (0, 9), (9, 10), (10, 11), (11, 12),
#     # Ring
#     (0, 13), (13, 14), (14, 15), (15, 16),
#     # Pinky
#     (0, 17), (17, 18), (18, 19), (19, 20)
# ]
#
# # Initialize PyBullet
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.setGravity(0, 0, -9.8)
# p.loadURDF("plane.urdf")
#
# # Create visual spheres for joints
# sphere_radius = 0.02
# joint_ids = []
# for _ in range(21):
#     visual_shape = p.createVisualShape(p.GEOM_SPHERE, radius=sphere_radius, rgbaColor=[0.6, 0.6, 0.6, 1])
#     body_id = p.createMultiBody(baseMass=0, baseVisualShapeIndex=visual_shape, basePosition=[0, 0, 0])
#     joint_ids.append(body_id)
#
# # Run animation
# while True:
#     for frame_idx in range(n_frames):
#         pos = landmarks[:, :, frame_idx]  # shape: (21, 3)
#
#         # Update joint positions
#         for i in range(21):
#             p.resetBasePositionAndOrientation(joint_ids[i], pos[i], [0, 0, 0, 1])
#
#         # Draw skeleton lines
#         for i, j in hand_connections:
#             p.addUserDebugLine(pos[i], pos[j], lineColorRGB=[1, 0, 0], lineWidth=2, lifeTime=0.05)
#
#         time.sleep(1 / 10)  # 30 FPS

#==============================
# 10. Visualize in Pybullet (considering we are using a normal skeleton)
#==============================
# import pybullet as p
# import pybullet_data
# import time
#
# # Connect to GUI
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.loadURDF("plane.urdf")
# p.setGravity(0, 0, -9.81)
#
# scale_factor = 10.0  # Try values like 10 or 50 depending on your data
# reg_f_np_scaled = reg_f_np * scale_factor
#
# # --- Load your trajectory data ---
# n_landmarks, _, n_frames = reg_f_np_scaled.shape
#
# # Define skeleton connections (example: chain connection)
# # Adjust indices based on real robotic arm structure
# skeleton_edges = [(i, i + 1) for i in range(n_landmarks - 1)]
#
# # Load visual markers for joints
# landmark_ids = []
# initial_positions = reg_f_np_scaled[:, :, 0]
# for pos in initial_positions:
#     landmark_ids.append(
#         p.loadURDF("sphere_small.urdf", basePosition=pos.tolist(), useFixedBase=True)
#     )
#
# # Initialize line IDs (we’ll update them per frame)
# line_ids = [None] * len(skeleton_edges)
#
# # Animate
# trajectory = reg_f_np_scaled.transpose(2, 0, 1)  # shape: (frames, landmarks, 3)
# frame_duration = 1.0 / 10
#
# for frame in trajectory:
#     # Move landmarks
#     for i, pos in enumerate(frame):
#         p.resetBasePositionAndOrientation(landmark_ids[i], pos.tolist(), [0, 0, 0, 1])
#
#     # Draw skeleton lines
#     for idx, (i, j) in enumerate(skeleton_edges):
#         start = frame[i]
#         end = frame[j]
#         if line_ids[idx] is not None:
#             p.removeUserDebugItem(line_ids[idx])
#         line_ids[idx] = p.addUserDebugLine(start, end, lineColorRGB=[0, 0, 1], lineWidth=2)
#
#     p.stepSimulation()
#     time.sleep(frame_duration)
#
# input("Press Enter to exit...")
# p.disconnect()

# -----------------------------
# 11. Visualize in PyBullet (using hand landmarks???)
# -----------------------------
# import pybullet as p
# import pybullet_data
# import time
#
# # Load or simulate reg_f_np data
#
# # Expected shape: (landmarks, 3, frames)
# n_landmarks, _, n_frames = 21, 3, 10
# np.random.seed(42)
# reg_f_np = np.cumsum(np.random.randn(n_landmarks, 3, n_frames) * 0.01, axis=2)
#
# # Choose the frame to visualize
# frame_to_show = 9
#
# # Define skeletal connections (example)
# bones = [
#     (0, 1), (1, 2), (2, 3),
#     (3, 4), (4, 5), (5, 6),
#     (6, 7), (7, 8), (8, 9),
#     (9, 10), (10, 11), (11, 12),
#     (12, 13), (13, 14), (14, 15),
#     (15, 16), (16, 17), (17, 18),
#     (18, 19), (19, 20)
# ]
#
# # PyBullet setup
#
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.resetSimulation()
# p.setGravity(0, 0, -9.81)
# p.loadURDF("plane.urdf")
#
# # Create landmark spheres
#
# marker_radius = 0.005
# landmarks = []
# for i in range(n_landmarks):
#     pos = reg_f_np[i, :, frame_to_show]
#     visual_shape = p.createVisualShape(p.GEOM_SPHERE, radius=marker_radius, rgbaColor=[0, 1, 0, 1])
#     body = p.createMultiBody(baseVisualShapeIndex=visual_shape, basePosition=pos.tolist())
#     landmarks.append(body)
#
# # Draw bone lines for skeleton
#
# for a, b in bones:
#     start = reg_f_np[a, :, frame_to_show]
#     end = reg_f_np[b, :, frame_to_show]
#     p.addUserDebugLine(start.tolist(), end.tolist(), lineColorRGB=[0, 0, 1], lineWidth=2.5)
#
# # Keep the simulation running
#
# print(f"Displaying skeleton at frame {frame_to_show}")
# while True:
#     p.stepSimulation()
#     time.sleep(1. / 240.)













# # -----------------------------
# # 0. Visualize in Matplotlib (3D Skeleton Animation)
# # -----------------------------
#
# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib import animation
# # from PyBullet import num_frames, num_landmarks
#
# def animate_skeleton(data, interval=200, landmark_colors=None, show_labels=True):
#     """
#     Animate a 3D skeleton with optional colored landmarks and labels.
#
#     Parameters:
#         data: np.ndarray of shape (n_landmarks, 3, n_frames)
#         interval: ms between frames
#         landmark_colors: optional list of colors for each landmark
#         show_labels: bool, whether to show landmark indices
#     """
#     assert data.ndim == 3, f"Expected data with 3 dimensions (landmarks, 3, frames), got {data.shape}"
#     assert data.shape[1] == 3, f"Expected 3D coordinates in second dimension, got {data.shape[1]}"
#
#     n_landmarks, _, n_frames = data.shape
#     fig = plt.figure(figsize=(8, 6))
#     ax = fig.add_subplot(111, projection='3d')
#
#     # Set up colors
#     if landmark_colors is None:
#         # Default to matplotlib tab colors
#         cmap = plt.get_cmap('tab10')
#         landmark_colors = [cmap(i) for i in range(n_landmarks)]
#
#     # Initial scatter plot
#     scatters = [
#         ax.scatter([], [], [], color=landmark_colors[i], s=60, label=f'L{i+1}')
#         for i in range(n_landmarks)
#     ]
#     lines = []
#
#     # Define landmark connections as per your robot
#     raw_connections = [
#         (0, 1), (1, 2), (2, 3)
#     ]
#     connections = [(i, j) for i, j in raw_connections if i < n_landmarks and j < n_landmarks]
#
#     for _ in connections:
#         lines.append(ax.plot([], [], [], color='gray', linewidth=2)[0])
#
#     # Optionally show labels for landmarks
#     labels = []
#     if show_labels:
#         for i in range(n_landmarks):
#             labels.append(ax.text(0, 0, 0, f"{i+1}", color=landmark_colors[i], fontsize=10))
#
#     def init():
#         # Set axis limits with a small margin
#         margin = 0.03
#         ax.set_xlim(np.min(data[:, 0, :]) - margin, np.max(data[:, 0, :]) + margin)
#         ax.set_ylim(np.min(data[:, 1, :]) - margin, np.max(data[:, 1, :]) + margin)
#         ax.set_zlim(np.min(data[:, 2, :]) - margin, np.max(data[:, 2, :]) + margin)
#         ax.set_xlabel('X')
#         ax.set_ylabel('Y')
#         ax.set_zlabel('Z')
#         ax.set_title("Skeleton Animation")
#         return scatters + lines + labels
#
#     def update(frame):
#         landmarks = data[:, :, frame]
#         # Update each landmark's scatter
#         for i, scat in enumerate(scatters):
#             scat._offsets3d = ([landmarks[i, 0]], [landmarks[i, 1]], [landmarks[i, 2]])
#         # Update bone lines
#         for idx, (i, j) in enumerate(connections):
#             xs = [landmarks[i, 0], landmarks[j, 0]]
#             ys = [landmarks[i, 1], landmarks[j, 1]]
#             zs = [landmarks[i, 2], landmarks[j, 2]]
#             lines[idx].set_data(xs, ys)
#             lines[idx].set_3d_properties(zs)
#         # Move landmark labels
#         if show_labels:
#             for i, label in enumerate(labels):
#                 label.set_position((landmarks[i, 0], landmarks[i, 1]))
#                 label.set_3d_properties(landmarks[i, 2])
#         ax.set_title(f"Skeleton Animation - Frame {frame+1}/{n_frames}")
#         return scatters + lines + labels
#
#     ani = animation.FuncAnimation(fig, update, frames=n_frames, init_func=init,
#                                   blit=False, interval=interval, repeat=True)
#     ax.legend(loc='upper right')
#     plt.tight_layout()
#     plt.show()



# # ---------------------------------
# # Regression model (simplified; new R code)
# # ---------------------------------
# import os
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility

# -----------------------------
# 2. rpy2 Imports and Conversions
# -----------------------------
# import numpy as np
# import pandas as pd
# from rpy2 import robjects as ro
# from rpy2.robjects import numpy2ri
# from rpy2.robjects.conversion import localconverter
#
# # Optional: convenience alias
# r = ro.r
#
# # -----------------------------
# # Load and reshape data
# # -----------------------------
# df = pd.read_csv("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/aligned_landmarks.csv")
# data_flat = df.to_numpy()
# data_reshaped = data_flat.reshape(n_frames, n_landmarks, n_coords)
# data_3d = np.transpose(data_reshaped, (1, 2, 0))  # shape: [landmarks, 3, frames]
#
# # Transpose to [3, landmarks, frames]
# data_input_r = np.transpose(data_3d, (1, 0, 2))
#
# # -----------------------------
# # Set working directory and source R script
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')
# r('source("simplified_3d_size_shape.r")')
#
# # -----------------------------
# # Send data to R using context manager
# # -----------------------------
# with localconverter(ro.default_converter + numpy2ri.converter):
#     ro.globalenv["data_input"] = data_input_r
#
# # -----------------------------
# # Run R functions
# # -----------------------------
# r("reg_result <- simplified_regression(data_input, deg = 2)")
# r("limb_lengths <- c(0.2, 0.2, 0.2, 0.2)")  # Example limb lengths, adjust as needed
# r("reg_result_corrected <- enforce_limb_lengths(reg_result, limb_lengths)")
#
# # -----------------------------
# # Get result back from R
# # -----------------------------
# with localconverter(ro.default_converter + numpy2ri.converter):
#     reg_simple_np = np.array(ro.r("reg_result_corrected"))
#
# # Transpose back to [landmarks, 3, frames]
# reg_simple_np = reg_simple_np.transpose(1, 0, 2)
#
#
# # print(reg_simple_np.shape)
#
# # ✅ Plot both
# animate_skeleton(data_3d)
# animate_skeleton(reg_simple_np)


# -----------------------------
# 11. Enhanced Regression with R (using rpy2)
# -----------------------------
# import numpy as np
# import pandas as pd
# from rpy2 import robjects
# from rpy2.robjects import numpy2ri, r
# from rpy2.robjects.packages import SignatureTranslatedAnonymousPackage
#
# # Enable numpy conversion
# from rpy2.robjects.conversion import localconverter
#
# # Landmarks configs
# n_landmarks = 21
# n_coords = 3
# n_frames = 10
#
# # Load and parse the R script
# with open("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/simplified_3d_size_shape.r", "r") as f:
#     r_script = f.read()
#
# r_funcs = SignatureTranslatedAnonymousPackage(r_script, "rreg")
#
#
# def run_enhanced_regression(data_3d_np, deg=2, use_spline=False, align=False,
#                             connections=None, lengths=None):
#     """
#     data_3d_np: numpy array of shape [landmarks, 3, frames]
#     returns: regressed output in same shape
#     """
#     # Validate shape
#     if data_3d_np.shape[1] != 3:
#         raise ValueError("Expected shape [landmarks, 3, frames]")
#
#     landmarks, coords, frames = data_3d_np.shape
#     data_r = np.transpose(data_3d_np, (1, 0, 2))  # -> [3, landmarks, frames]
#
#     # Default 3-DOF robot
#     if connections is None:
#         connections = [[0, 1], [1, 2], [2, 3]]
#     if lengths is None:
#         lengths = [0.2] * len(connections)
#
#     # Prepare R structures
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         r_data = robjects.conversion.py2rpy(data_r)
#         r_conns = robjects.ListVector({str(i): robjects.IntVector([a, b])
#                                        for i, (a, b) in enumerate(connections)})
#         r_lengths = robjects.FloatVector(lengths)
#
#     # Run regression
#     result = r_funcs.enhanced_regression(r_data,
#                                          deg=deg,
#                                          use_spline=use_spline,
#                                          align=align,
#                                          connections=r_conns,
#                                          lengths=r_lengths)
#
#     # Convert result back
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         result_np = robjects.conversion.rpy2py(result)
#
#     # Convert to original shape [landmarks, 3, frames]
#     result_np = np.transpose(result_np, (1, 0, 2))
#     return result_np
#
# df = pd.read_csv("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv")
# data_flat = df.to_numpy()
# data_reshaped = data_flat.reshape(n_frames, n_landmarks, n_coords)
# data_3d = np.transpose(data_reshaped, (1, 2, 0))  # shape: [landmarks, 3, frames]
# print("Data in shape of: ", data_3d.shape)
# print("Proceeding with regression...")
#
# # Run regression
# regressed = run_enhanced_regression(data_3d,
#                                      deg=2,
#                                      use_spline=True,
#                                      align=True,
#                                      connections=[[0,1], [1,2], [2,3], [3,4],
#                                                   [0,5], [5,6], [6,7], [7,8],
#                                                   [0,9], [9, 10], [10, 11], [11, 12],
#                                                   [0, 13], [13, 14], [14, 15], [15, 16],
#                                                   [0, 17], [17, 18], [18, 19], [19, 20]],
#                                      lengths=[0.2, 0.2, 0.2,0.2, 0.2, 0.2,0.2, 0.2, 0.2,0.2, 0.2, 0.2,0.2, 0.2, 0.2,0.2, 0.2, 0.2,0.2, 0.2, 0.2])
#
# animate_skeleton(data_3d)
# animate_skeleton(regressed)

# # ---------------------------
# # Regression (no helmert)
# # ---------------------------
# import numpy as np
# from rpy2 import robjects
# from rpy2.robjects import numpy2ri
# from rpy2.robjects.packages import SignatureTranslatedAnonymousPackage
# from rpy2.robjects.conversion import localconverter
#
# # Load and parse R script
# with open("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/simplified_3d_size_shape.r", "r") as f:
#     r_script = f.read()
#
# r_funcs = SignatureTranslatedAnonymousPackage(r_script, "rreg")
#
# def run_enhanced_regression(data_3d_np, deg=2, use_spline=False, align=False,
#                             connections=None, lengths=None, enforce_limb_lengths=False):
#     if data_3d_np.shape[1] != 3:
#         raise ValueError("Expected shape [landmarks, 3, frames]")
#
#     landmarks, coords, frames = data_3d_np.shape
#     data_r = np.transpose(data_3d_np, (1, 0, 2))  # [3, landmarks, frames]
#
#     if connections is None:
#         connections = [[0, 1], [1, 2], [2, 3]]
#     if lengths is None:
#         lengths = [0.2] * len(connections)
#
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         r_data = robjects.conversion.py2rpy(data_r)
#         r_conns = robjects.ListVector({
#             str(i): robjects.IntVector([a + 1, b + 1])
#             for i, (a, b) in enumerate(connections)
#         })
#         r_lengths = robjects.ListVector({
#             f"{a + 1}-{b + 1}": l
#             for (a, b), l in zip(connections, lengths)
#         }) if enforce_limb_lengths else robjects.NULL
#
#     # Call the R function
#     result = r_funcs.enhanced_regression(
#         D0=r_data,
#         joint_connections=r_conns,
#         poly_order=deg,
#         use_procrustes=align,
#         use_spline=use_spline,
#         enforce_limb_lengths=enforce_limb_lengths,
#         lengths=r_lengths
#     )
#
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         result_np = robjects.conversion.rpy2py(result)
#
#     return np.transpose(result_np, (1, 0, 2))  # Back to [landmarks, 3, frames]

# # ---------------------------------
# # Regression model (simplified; new R code)
# # ---------------------------------
# import os
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# # ----------------------
# # Regression (helmert added)
# # ----------------------
# import numpy as np
# from rpy2 import robjects
# from rpy2.robjects import numpy2ri
# from rpy2.robjects.packages import SignatureTranslatedAnonymousPackage
# from rpy2.robjects.conversion import localconverter
#
# # Load and parse R script
# with open("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/simplified_3d_size_shape.r", "r") as f:
#     r_script = f.read()
#
# r_funcs = SignatureTranslatedAnonymousPackage(r_script, "rreg")
#
#
# def run_enhanced_regression(
#         data_3d_np,
#         To=None,
#         degree=2,
#         use_spline=False,
#         use_procrustes=False,
#         enforce_limb_lengths=False,
#         joint_connections=None,
#         lengths=None,
#         apply_helmert=False,
#         apply_em=False
# ):
#     """
#     Wrapper to run the R `enhanced_regression` function.
#
#     Parameters:
#         data_3d_np: np.ndarray of shape [landmarks, 3, frames]
#         To: Optional list or array of time points (length = frames)
#         degree: Polynomial degree
#         use_spline: Use spline regression instead of polynomial
#         use_procrustes: Toggle Procrustes alignment
#         enforce_limb_lengths: Enforce limb-length constraints
#         joint_connections: List of [i, j] connections (0-based)
#         lengths: List of desired lengths corresponding to connections
#         apply_helmert: Toggle Helmert projection
#         apply_em: Toggle EM shape estimation
#     """
#
#     if data_3d_np.shape[1] != 3:
#         raise ValueError("Expected input shape [landmarks, 3, frames]")
#
#     landmarks, coords, frames = data_3d_np.shape
#     data_r = np.transpose(data_3d_np, (1, 0, 2))  # [3, landmarks, frames]
#
#     if joint_connections is None:
#         joint_connections = [[0, 1], [1, 2], [2, 3]]
#     if lengths is None:
#         lengths = [0.2] * len(joint_connections)
#
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         r_data = robjects.conversion.py2rpy(data_r)
#
#         # Time vector
#         if To is None:
#             r_To = robjects.NULL
#         else:
#             r_To = robjects.IntVector(list(To))
#
#         # Connections: Convert to 1-based indexing for R
#         r_conns = robjects.ListVector({
#             str(i): robjects.IntVector([a + 1, b + 1])
#             for i, (a, b) in enumerate(joint_connections)
#         })
#
#         # Lengths map
#         r_lengths = robjects.ListVector({
#             f"{a + 1}-{b + 1}": l
#             for (a, b), l in zip(joint_connections, lengths)
#         }) if enforce_limb_lengths else robjects.NULL
#
#     # Call the R function
#     result = r_funcs.enhanced_regression(
#         D0=r_data,
#         To=r_To,
#         degree=degree,
#         use_spline=use_spline,
#         use_procrustes=use_procrustes,
#         enforce_limb_lengths=enforce_limb_lengths,
#         joint_connections=r_conns,
#         lengths=r_lengths,
#         apply_helmert=apply_helmert,
#         # apply_em=apply_em
#     )
#
#     # Convert result back to NumPy and transpose back to [landmarks, 3, frames]
#     with localconverter(robjects.default_converter + numpy2ri.converter):
#         result_np = robjects.conversion.rpy2py(result)
#
#     return np.transpose(result_np, (1, 0, 2))
#
#
# # ----------------------
# # Load your data
# # ----------------------
# import pandas as pd
#
# n_landmarks = 21
# n_coords = 3
# n_frames = 10
#
# # df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv') #Directory to the CSV file
# # data_flat = df.to_numpy()
# # # print("First row:", data_flat[0])
# # # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# # data_3d = data_flat.T.reshape((21, 3, 10), order='F')
#
# df = pd.read_csv("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv")
# data_flat = df.to_numpy()
# data_reshaped = data_flat.T.reshape(n_landmarks, n_coords, n_frames, order='F') #ONLY WAY TO GET THESE LANDMARKS
# animate_skeleton(data_reshaped)
# data_3d = np.transpose(data_reshaped, (0, 1, 2))  # shape: [landmarks, coords, frames] (technically not need in this scenario)
# print("OG Data in shape of: ", data_3d.shape)
# print("Proceeding with regression...")
#
# # ----------------------
# # Regression setup
# # ----------------------
#
# regressed = run_enhanced_regression( #ENSURE DATA IS IN SHAPE [CORDS, LANDMARKS, FRAMES] (apparently not anymore)
#     data_3d_np=data_3d,
#     To=None,
#     degree=2,
#     use_spline=True,
#     use_procrustes=True,
#     enforce_limb_lengths=False,
#     joint_connections=[
#         [0,1], [1,2], [2,3], [3,4],
#         [0,5], [5,6], [6,7], [7,8],
#         [0,9], [9,10], [10,11], [11,12],
#         [0,13], [13,14], [14,15], [15,16],
#         [0,17], [17,18], [18,19], [19,20]
#     ],
#     lengths= [0.2]*20,  # Example lengths, adjust as needed
#     apply_helmert = False,
#     # apply_em = True
# )
# print("Data shape: ", data_3d.shape)
# data_3d = np.transpose(data_3d, (0, 1, 2))
# print("OG Data shape after transpose: ", data_3d.shape)
# animate_skeleton(data_3d)
#
# # ----------------------
# # print("\nOutput shape:")
# # print(len(regressed))  # Should be (3, landmarks, frames)
# landmarks_np = np.array(regressed)
# landmarks_np = np.transpose(landmarks_np, (0, 1, 2))
# print("Regressed landmarks shape (after transpose):", landmarks_np.shape)
# # print("Raw contents preview:", landmarks_np[:20])
#
# animate_skeleton(landmarks_np)
#
# # Visualize or pass to animate_skeleton()


# # -------------------------------
# # Regression model (copied, adapted for regular skeleton)
# # -------------------------------
# import os
# import numpy as np
# import pandas as pd
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# n_landmarks = 4
# n_coords = 3
# n_frames = 50
#
# # -----------------------------
# # 2. rpy2 Imports and Conversions
# # -----------------------------
# from rpy2 import robjects
# from rpy2.robjects import r, pandas2ri, default_converter
# from rpy2.robjects.conversion import localconverter
# from rpy2.rinterface import FloatSexpVector
# from rpy2.robjects.vectors import IntVector
#
# # Optional: suppress warnings
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning)
#
# # -----------------------------
# # 3. Set R Working Directory
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  #R script directory
# r('source("mainEM_3d_size_shape.r")')   #directory to the R script
# print("✅ R working directory set to:", r('getwd()')[0])
#
# # -----------------------------
# # 3. Load CSV and prepare 3D NumPy array
# # -----------------------------
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/aligned_landmarks.csv') #Directory to the CSV file
# data_flat = df.to_numpy()
# # print("First row:", data_flat[0])
# # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# data_3d = data_flat.T.reshape((n_landmarks, n_coords, n_frames), order='F')  # (21 landmarks, 3D, 10 samples)
#
# # -----------------------------
# # 4. Convert NumPy array to R array
# # -----------------------------
# data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
# data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
# robjects.globalenv["data"] = data_r_array
#
# # -----------------------------
# # 5. Permute in R and run EM polynomial regression
# # -----------------------------
# r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
# r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
# # -----------------------------
# # 6. Extract R outputs back to NumPy
# # -----------------------------
# with localconverter(default_converter + pandas2ri.converter):
#     reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
#     reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)
#
# print("Raw shape of reg_f_np:", reg_f_np.shape)
# print("Raw shape of reg_r_np:", reg_r_np.shape)
#
# # -----------------------------
# # 7. Transpose to standard Python shape: (21, 3, 10, N)
# # -----------------------------
# reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
# print("reg_f_np reshaped to:", reg_f_np.shape)
#
# if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# else:
#     print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
# # -----------------------------
# # 8. Optionally remove last dim if N == 1
# # -----------------------------
# print("✅ Regressed shape:", reg_f_np.shape)
# print("Frame 0, joint 0:", reg_f_np[0, :, 0, 0])
# print("Frame 1, joint 0:", reg_f_np[0, :, 1, 0])
#
# if reg_f_np.shape[-1] == 1:
#     reg_f_np = reg_f_np[..., 0]
# if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#     reg_r_np = reg_r_np[..., 0]
#
# # -----------------------------
# # 9. Final Output
# # -----------------------------
# print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
# print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
# print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1])
# reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
# reg_r_np = reg_r_np[..., 0]
#
# animate_skeleton(reg_f_np)

# # -------------------------------
# # 10. align landmarks to reference
# # -------------------------------
# import numpy as np
#
# def align_predicted_to_reference(predicted, reference, allow_translation=True):
#     """
#     Aligns predicted landmarks to reference landmarks using the Kabsch algorithm, frame by frame.
#
#     Parameters:
#     - predicted: np.ndarray of shape (n_landmarks, 3, n_frames)
#     - reference: np.ndarray of shape (n_landmarks, 3, n_frames)
#     - allow_translation: whether to include translation during alignment
#
#     Returns:
#     - aligned_predicted: np.ndarray of same shape, aligned to reference
#     """
#     n_landmarks, n_coords, n_frames = predicted.shape
#     aligned_predicted = np.zeros_like(predicted)
#
#     for t in range(n_frames):
#         P = predicted[:, :, t]  # shape (n_landmarks, 3)
#         Q = reference[:, :, t]  # shape (n_landmarks, 3)
#
#         # Center the data (optional for rotation-only alignment)
#         P_mean = P.mean(axis=0)
#         Q_mean = Q.mean(axis=0)
#
#         P_centered = P - P_mean
#         Q_centered = Q - Q_mean
#
#         # Compute covariance matrix
#         H = P_centered.T @ Q_centered
#
#         # Singular Value Decomposition
#         U, S, Vt = np.linalg.svd(H)
#
#         # Compute optimal rotation matrix
#         R = Vt.T @ U.T
#
#         # Reflection correction (ensure det(R) == +1)
#         if np.linalg.det(R) < 0:
#             Vt[-1, :] *= -1
#             R = Vt.T @ U.T
#
#         # Apply rotation (and optionally translation)
#         P_aligned = (P_centered @ R)
#         if allow_translation:
#             P_aligned += Q_mean  # move aligned data to reference position
#
#         aligned_predicted[:, :, t] = P_aligned
#
#     return aligned_predicted
#
# # -----------------------------
# # animate artifacts
# data_reshaped = data_flat.reshape(n_frames, n_landmarks, n_coords)
# data_3d_plot = np.transpose(data_reshaped, (1, 2, 0))  # shape: (4, 3, n_frames)
#
# reg_f_aligned = align_predicted_to_reference(reg_f_np, data_3d_plot)
#
# animate_skeleton(data_3d_plot)
# animate_skeleton(reg_f_aligned)

# -------------------------------
# Regression model (adapted for regular skeleton, outdated)
# -------------------------------
# import os
# import numpy as np
# import pandas as pd
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# # -----------------------------
# # 2. rpy2 Imports and Conversions
# # -----------------------------
# from rpy2.robjects import r, pandas2ri
# from rpy2.robjects import default_converter
# from rpy2.robjects.conversion import localconverter
# import rpy2.robjects.numpy2ri as numpy2ri
#
# # Optional: suppress warnings
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning)
#
# # -----------------------------
# # 3. Set R Working Directory
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  #R script directory
# r('source("mainEM_3d_size_shape_test.r")')   #directory to the R script
# print("✅ R working directory set to:", r('getwd()')[0])
#
# # -----------------------------
# # 4. Load CSV and prepare 3D NumPy array
# # -----------------------------
#
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/aligned_landmarks.csv') #Directory to the CSV file
#
# # === Step 2: Convert to numpy and reshape ===
# data_flat = df.to_numpy()  # shape: (n_frames, 4*3 = 12)
# num_frames = data_flat.shape[0]
# num_landmarks = 4
# num_coords = 3
#
# # Reshape: (n_frames, 4 landmarks, 3 coords)
# data_reshaped = data_flat.reshape(num_frames, num_landmarks, num_coords)
#
# # Transpose to match R shape: (landmarks, coords, frames)
# data_3d = np.transpose(data_reshaped, (1, 2, 0))  # shape: (4, 3, n_frames)
#
# # === Step 3 (Optional): Swap y and z coordinates ===
# # This makes [x, z, y] => use only if necessary
# # data_3d[:, [1, 2], :] = data_3d[:, [2, 1], :]  # swap y and z
# # data_3d[:, [0, 1], :] = data_3d[:, [1, 0], :]
#
# # === Step 4: Convert to R array ===
# with localconverter(default_converter + numpy2ri.converter):
#     r_data_array = numpy2ri.py2rpy(data_3d)
#
# # Assign to R variable 'data'
# r.assign("data", r_data_array)
#
# # === Step 5: Print for verification ===
# print("Python check:")
# print("X:", data_3d[:, 0, 0])
# print("Y:", data_3d[:, 1, 0])
# print("Z:", data_3d[:, 2, 0])
#
# print("\nR check:")
# print("R X:", r("data[1:4,1,1]"), r("data[1:4,1,15]"))  # x
# print("R Y:", r("data[1:4,2,1]"), r("data[1:4,2,15]"))  # y
# print("R Z:", r("data[1:4,3,1]"), r("data[1:4,3,15]"))  # z
#
# # data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
# # data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
# # robjects.globalenv["data"] = data_r_array
#
# # -----------------------------
# # 6. Permute in R and run EM polynomial regression
# # -----------------------------
# r('data_perm <- aperm(data, c(2, 1, 3))')  # → (coords, landmarks, frames)
# r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
# # -----------------------------
# # 7. Extract R outputs back to NumPy
# # -----------------------------
# with localconverter(default_converter + pandas2ri.converter):
#     reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 4, 50, N)
#     reg_r_np = np.array(r('reg1$r'))  # Could be (3, 4, 50) or (3, 4, 50, N)
#
# print("Raw shape of reg_f_np:", reg_f_np.shape)
# print("Raw shape of reg_r_np:", reg_r_np.shape)
#
# # -----------------------------
# # 8. Transpose to standard Python shape: (4, 3, 50, N)
# # -----------------------------
# reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # (landmarks, coords, frames, N)
# print("reg_f_np reshaped to:", reg_f_np.shape)
#
# if reg_r_np.ndim == 4 and reg_r_np.shape[0] == num_coords:
#     reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == num_coords:
#     reg_r_np = reg_r_np.transpose(1, 0, 2)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# else:
#     print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
# # -----------------------------
# # 9. Optionally remove last dim if N == 1
# # -----------------------------
# if reg_f_np.shape[-1] == 1:
#     reg_f_np = reg_f_np[..., 0]
# if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#     reg_r_np = reg_r_np[..., 0]
#
#
# # -----------------------------
# # 10. Final Output
# # -----------------------------
# print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
# print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
# print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1])
# reg_f_np = reg_f_np[..., 0]  # shape becomes (4, 3, 50)
# reg_r_np = reg_r_np[..., 0]

# -----------------------------
# 1-10 Regression model (Python-only; simplified)
# -----------------------------
# from sklearn.preprocessing import PolynomialFeatures
# from sklearn.linear_model import LinearRegression
# import pandas as pd

# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/aligned_landmarks.csv') #Directory to the CSV file
#
# # === Step 2: Convert to numpy and reshape ===
# data_flat = df.to_numpy()  # shape: (n_frames, 4*3 = 12)
# num_frames = data_flat.shape[0]
# num_landmarks = 4
# num_coords = 3
#
# # Reshape: (n_frames, 4 landmarks, 3 coords)
# data_reshaped = data_flat.reshape(num_frames, num_landmarks, num_coords)
#
# # Transpose to match R shape: (landmarks, coords, frames)
# data_3d = np.transpose(data_reshaped, (1, 2, 0))  # shape: (4, 3, n_frames)

# def fit_trajectory(data, degree=3):
#     """
#     data: shape (num_landmarks, 3, num_frames)
#     """
#     num_landmarks, num_dims, num_frames = data.shape
#     time = np.arange(num_frames).reshape(-1, 1)
#
#     poly = PolynomialFeatures(degree)
#     X_time = poly.fit_transform(time)
#
#     predicted = np.zeros_like(data)
#
#     for l in range(num_landmarks):
#         for d in range(num_dims):
#             y = data[l, d, :]
#             model = LinearRegression().fit(X_time, y)
#             predicted[l, d, :] = model.predict(X_time)
#
#     return predicted
#
# # predicted = fit_trajectory(data_3d)
# predicted = fit_trajectory(reg_f_np)
#
# print(predicted.shape)  # Should be (4, 3, n_frames)
# animate_skeleton(predicted, name="Polynomial Regression")

# # -----------------------------
# # 10. Optimization of the landmarks:
# # -----------------------------
#
# import numpy as np
# from scipy.optimize import minimize
#
# def project_to_fixed_lengths(points, connections, lengths):
#     """
#     points: (N, 3) array of predicted landmark positions
#     connections: list of tuples [(i, j), ...] indicating fixed-length links
#     lengths: list of corresponding desired lengths
#     """
#     def loss(x):
#         x = x.reshape(-1, 3)
#         error = 0
#         for (i, j), d in zip(connections, lengths):
#             dist = np.linalg.norm(x[i] - x[j])
#             error += (dist - d) ** 2
#         return error
#
#     x0 = points.flatten()
#     result = minimize(loss, x0, method='L-BFGS-B')
#     return result.x.reshape(-1, 3)
#
# # Define connections and lengths once
# connections = [(0,1), (1,2), (2,3), (3,4),
#                (0,5), (5,6), (6,7), (7,8),
#                (0,9), (9,10), (10,11), (11,12),
#                (0,13), (13,14), (14,15), (15,16),
#                (0,17), (17,18), (18,19), (19,20)]  # index pairs
#
# lengths = [0.054, 0.05, 0.044, 0.044,
#            0.066, 0.058, 0.05, 0.05,
#            0.07, 0.062, 0.054, 0.054,
#            0.066, 0.058, 0.05, 0.05,
#            0.056, 0.046, 0.04, 0.04]  # measured from original data
#
# # Process all frames
# fixed_predicted = np.zeros_like(predicted)
# for t in range(predicted.shape[2]):
#     frame = predicted[:, :, t]
#     fixed_frame = project_to_fixed_lengths(frame, connections, lengths)
#     fixed_predicted[:, :, t] = fixed_frame
#
# # animate_skeleton(data_3d, name="Original landmarks")
# animate_skeleton(fixed_predicted, name="Length-Restrained Landmarks")

# # --- Another optimazation algorithm ---
# import numpy as np
# from scipy.optimize import minimize
#
# def length_constrained_alignment(predicted, reference, connections, lengths, anchor_indices=[0], max_iter=200):
#     """
#     Aligns predicted to reference using nonlinear optimization:
#     - Anchors specified indices exactly
#     - Preserves segment lengths given by 'connections' and 'lengths'
#     - Attempts to match reference pose as closely as possible
#
#     Parameters:
#     - predicted: np.ndarray of shape (21, 3)
#     - reference: np.ndarray of shape (21, 3)
#     - connections: list of (i,j) pairs (landmark indices)
#     - lengths: list of floats, desired segment lengths
#     - anchor_indices: indices to anchor exactly to reference
#     - max_iter: maximum optimization iterations (default 200)
#
#     Returns:
#     - aligned: np.ndarray of shape (21, 3)
#     """
#     n_landmarks = predicted.shape[0]
#
#     def loss(x):
#         # x is flattened (21 * 3)
#         x = x.reshape((n_landmarks, 3))
#         # 1. Anchors: penalize deviation from reference
#         anchor_loss = np.sum((x[anchor_indices] - reference[anchor_indices])**2)
#         # 2. Lengths: penalize deviation from desired lengths
#         length_loss = 0
#         for (idx, (i, j)) in enumerate(connections):
#             seg_length = np.linalg.norm(x[i] - x[j])
#             length_loss += (seg_length - lengths[idx])**2
#         # 3. Global RMSD: encourage closeness to reference
#         rmsd_loss = np.sum((x - reference)**2)
#         # Blend weights (adjust for your use-case)
#         total_loss = anchor_loss * 100 + length_loss * 100 + rmsd_loss * 1
#         return total_loss
#
#     x0 = predicted.flatten()
#     res = minimize(loss, x0, method='L-BFGS-B', options={'maxiter': max_iter})
#     aligned = res.x.reshape((n_landmarks, 3))
#     return aligned
#
# # Example frame-loop usage
# def batch_length_constrained_alignment(predicted_array, reference_array, connections, lengths, anchor_indices=[0], max_iter=200):
#     """
#     Aligns all frames in arrays of shape (21, 3, n_frames)
#     Returns aligned_array of same shape.
#     """
#     n_landmarks, n_coords, n_frames = predicted_array.shape
#     aligned_array = np.zeros_like(predicted_array)
#     for t in range(n_frames):
#         aligned = length_constrained_alignment(
#             predicted_array[:, :, t],
#             reference_array[:, :, t],
#             connections,
#             lengths,
#             anchor_indices=anchor_indices,
#             max_iter=max_iter
#         )
#         aligned_array[:, :, t] = aligned
#     return aligned_array
#
# connections = [(0,1), (1,2), (2,3), (3,4),
#                (0,5), (5,6), (6,7), (7,8),
#                (0,9), (9,10), (10,11), (11,12),
#                (0,13), (13,14), (14,15), (15,16),
#                (0,17), (17,18), (18,19), (19,20)]  # index pairs
#
# lengths = [0.054, 0.05, 0.044, 0.044,
#            0.066, 0.058, 0.05, 0.05,
#            0.07, 0.062, 0.054, 0.054,
#            0.066, 0.058, 0.05, 0.05,
#            0.056, 0.046, 0.04, 0.04]  # measured from original data
#
# # Usage example:
# aligned = batch_length_constrained_alignment(predicted, data_3d, connections, lengths, anchor_indices=[0, 1, 5, 9, 13, 17])
# animate_skeleton(aligned, name="length-constrained alignment")

# -----------------------------
# Re-align landmarks to reference
# -----------------------------
# import numpy as np
#
# def compute_hand_frame(landmarks):
#     """
#     Compute an anatomical hand frame from 21 hand landmarks:
#     - X axis: palm center to thumb base
#     - Y axis: palm center to middle finger base
#     - Z axis: cross(X, Y)
#     Returns a (3,3) matrix: columns are x, y, z axes.
#     """
#     palm = landmarks[0]
#     thumb_base = landmarks[1]
#     middle_base = landmarks[8]
#     x_axis = thumb_base - palm
#     y_axis = middle_base - palm
#     z_axis = np.cross(x_axis, y_axis)
#     # Normalize
#     x_axis /= np.linalg.norm(x_axis)
#     y_axis /= np.linalg.norm(y_axis)
#     z_axis /= np.linalg.norm(z_axis)
#     # Orthogonalize: Gram-Schmidt for y
#     y_axis = y_axis - np.dot(y_axis, x_axis) * x_axis
#     y_axis /= np.linalg.norm(y_axis)
#     # Recompute z
#     z_axis = np.cross(x_axis, y_axis)
#     z_axis /= np.linalg.norm(z_axis)
#     return np.stack([x_axis, y_axis, z_axis], axis=1)  # (3,3)
#
# def anatomical_align(source_landmarks, target_landmarks):
#     """
#     Aligns source_landmarks to target_landmarks using anatomical axes (hand frame) and Kabsch alignment.
#     Both inputs shape (21, 3).
#     Returns aligned_source, rotation_matrix, translation_vector
#     """
#     # 1. Compute anatomical frames
#     src_frame = compute_hand_frame(source_landmarks)
#     tgt_frame = compute_hand_frame(target_landmarks)
#     # 2. Compute rotation from src frame to tgt frame
#     frame_rot = tgt_frame @ src_frame.T
#     # 3. Rotate source landmarks to match target hand orientation
#     src_center = np.mean(source_landmarks, axis=0)
#     tgt_center = np.mean(target_landmarks, axis=0)
#     src_rotated = ((source_landmarks - src_center) @ frame_rot.T) + tgt_center
#
#     # 4. Kabsch alignment (with mirror fix)
#     P = target_landmarks - tgt_center
#     Q = src_rotated - tgt_center
#     H = Q.T @ P
#     U, S, Vt = np.linalg.svd(H)
#     R = Vt.T @ U.T
#     if np.linalg.det(R) < 0:
#         Vt[-1,:] *= -1
#         R = Vt.T @ U.T
#     Q_aligned = (Q @ R) + tgt_center
#     t = tgt_center - src_center @ frame_rot.T @ R
#     return Q_aligned, frame_rot @ R, t
#
# def anatomical_hand_alignment_frame_loop(source_landmarks_array, target_landmarks_array):
#     """
#     Frame-loop version for arrays of shape (21, 3, n_frames).
#     Returns aligned_source_array of shape (21, 3, n_frames).
#     """
#     n_frames = source_landmarks_array.shape[2]
#     aligned = np.empty_like(source_landmarks_array)
#     rotations = []
#     translations = []
#     for frame in range(n_frames):
#         source = source_landmarks_array[:, :, frame]
#         target = target_landmarks_array[:, :, frame]
#         aligned_frame, rot, trans = anatomical_align(source, target)
#         aligned[:, :, frame] = aligned_frame
#         rotations.append(rot)
#         translations.append(trans)
#     return aligned, rotations, translations

# --- wrong alignment method ---
# import numpy as np
#
#
# def align_predicted_to_reference(predicted, reference, allow_translation=True, anchor_indices=[0]):
#     """
#     Aligns predicted landmarks to reference landmarks using the Kabsch algorithm, frame by frame.
#     After alignment, anchors specified indices (e.g. palm and/or finger bases) to reference positions.
#
#     Parameters:
#     - predicted: np.ndarray of shape (n_landmarks, 3, n_frames)
#     - reference: np.ndarray of shape (n_landmarks, 3, n_frames)
#     - allow_translation: whether to include translation during alignment
#     - anchor_indices: list of indices to anchor (default=[0], just palm)
#
#     Returns:
#     - aligned_predicted: np.ndarray of same shape, aligned and anchored
#     """
#     n_landmarks, n_coords, n_frames = predicted.shape
#     aligned_predicted = np.zeros_like(predicted)
#
#     for t in range(n_frames):
#         P = predicted[:, :, t]  # shape (n_landmarks, 3)
#         Q = reference[:, :, t]  # shape (n_landmarks, 3)
#
#         # Center the data
#         P_mean = P.mean(axis=0)
#         Q_mean = Q.mean(axis=0)
#         P_centered = P - P_mean
#         Q_centered = Q - Q_mean
#
#         # Compute covariance matrix
#         H = P_centered.T @ Q_centered
#
#         # Singular Value Decomposition
#         U, S, Vt = np.linalg.svd(H)
#
#         # Compute optimal rotation matrix
#         R = Vt.T @ U.T
#
#         # Reflection correction (ensure det(R) == +1)
#         if np.linalg.det(R) < 0:
#             Vt[-1, :] *= -1
#             R = Vt.T @ U.T
#
#         # Apply rotation (and optionally translation)
#         P_aligned = (P_centered @ R)
#         if allow_translation:
#             P_aligned += Q_mean
#
#         # Blend in anchoring: overwrite palm and/or bases with reference
#         for idx in anchor_indices:
#             P_aligned[idx, :] = Q[idx, :]
#
#         aligned_predicted[:, :, t] = P_aligned
#
#     return aligned_predicted
#
#
# # USAGE EXAMPLE
# # To anchor palm and finger bases:
# anchor_indices = [0, 1, 5, 9, 13, 17]
# aligned = align_predicted_to_reference(fixed_predicted, data_3d, allow_translation=True, anchor_indices=anchor_indices)
#
# # Example usage:
# # aligned_array = align_predicted_to_reference(fixed_predicted, data_3d)
# # fixed_predicted should be shape (21, 3, n_frames), data_3d same shape
# animate_skeleton(aligned, name="Re-aligned Landmarks")

# -----------------------------
# 11. Visualize Plot in Matplotlib (plotVSplot)
# -----------------------------
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.animation import FuncAnimation
# from mpl_toolkits.mplot3d import Axes3D
#
# # === Your data ===
# # Make sure these variables exist before running:
# # data_3d: shape (4, 3, 50)
# # reg_f_np: shape (4, 3, 50)
# original_data = data_3d
# regressed_data = reg_f_np
#
# num_landmarks, _, num_frames = original_data.shape
#
# # === Set up figure ===
# fig = plt.figure(figsize=(12, 6))
# ax1 = fig.add_subplot(121, projection='3d')
# ax2 = fig.add_subplot(122, projection='3d')
# fig.suptitle("Original (Left) vs Regressed (Right)")
#
# colors = ['blue', 'orange', 'green', 'red']
# labels = ['L1', 'L2', 'L3', 'L4']
#
# # Configure both axes
# for ax in [ax1, ax2]:
#     ax.set_xlim(-1, 1)
#     ax.set_ylim(-1, 1)
#     ax.set_zlim(-1, 1)
#     ax.set_xlabel("X")
#     ax.set_ylabel("Y")
#     ax.set_zlabel("Z")
#
# # Create legend dots
# for ax in [ax1, ax2]:
#     for i in range(num_landmarks):
#         ax.scatter([], [], [], color=colors[i], label=labels[i])
#     ax.legend(loc='upper right')
#
# # Initialize scatter and lines
# scatters1 = [ax1.plot([], [], [], 'o', color=colors[i])[0] for i in range(num_landmarks)]
# scatters2 = [ax2.plot([], [], [], 'o', color=colors[i])[0] for i in range(num_landmarks)]
# lines1 = ax1.plot([], [], [], color='gray')[0]
# lines2 = ax2.plot([], [], [], color='gray')[0]
#
# # === Update function ===
# def update(frame):
#     for i in range(num_landmarks):
#         scatters1[i]._offsets3d = ([original_data[i, 0, frame]],
#                                    [original_data[i, 1, frame]],
#                                    [original_data[i, 2, frame]])
#         scatters2[i]._offsets3d = ([regressed_data[i, 0, frame]],
#                                    [regressed_data[i, 1, frame]],
#                                    [regressed_data[i, 2, frame]])
#     # Connect landmarks in order
#     lines1.set_data(original_data[:, 0, frame], original_data[:, 1, frame])
#     lines1.set_3d_properties(original_data[:, 2, frame])
#     lines2.set_data(regressed_data[:, 0, frame], regressed_data[:, 1, frame])
#     lines2.set_3d_properties(regressed_data[:, 2, frame])
#     return scatters1 + scatters2 + [lines1, lines2]
#
# # === Run animation ===
# ani = FuncAnimation(fig, update, frames=num_frames, interval=200, blit=False)
#
# plt.tight_layout()
# plt.show()

# #------------------------------
# # 12. Visualize in Pybullet (considering we are using a normal skeleton, using DataPath)
# #------------------------------
# import pybullet as p
# import pybullet_data
# import time
# import numpy as np
#
# # Connect to GUI
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.loadURDF("plane.urdf")
# p.setGravity(0, 0, -9.81)
#
# # --- Load your trajectory data ---
# # reg_f_np shape: (n_landmarks, 3, n_frames)
# reg_f_np = np.copy(fixed_predicted)  # replace with your variable if needed
#
# # --- Auto scale factor for better visualization ---
# max_range = np.linalg.norm(reg_f_np.reshape(-1, 3), axis=1).max()
# scale_factor = 10.0 / max_range if max_range > 0 else 10.0
# print(f"Auto scale factor: {scale_factor:.2f}")
#
# reg_f_np_scaled = reg_f_np * scale_factor
# n_landmarks, _, n_frames = reg_f_np_scaled.shape
#
# # --- Define skeleton edges (adjust as needed) ---
# skeleton_edges = [(i, i + 1) for i in range(n_landmarks - 1)]
#
# # --- Load landmark spheres ---
# landmark_colors = [
#     [1, 0, 0],  # red
#     [0, 1, 0],  # green
#     [0, 0, 1],  # blue
#     [1, 1, 0],  # yellow
#     [1, 0, 1],  # magenta
#     [0, 1, 1],  # cyan
#     [0.5, 0.5, 0.5],  # gray
# ]
# landmark_ids = []
# initial_positions = reg_f_np_scaled[:, :, 0]
# for i, pos in enumerate(initial_positions):
#     visual_shape_id = p.createVisualShape(
#         p.GEOM_SPHERE, radius=0.1,
#         rgbaColor=landmark_colors[i % len(landmark_colors)] + [1]
#     )
#     landmark_ids.append(
#         p.createMultiBody(
#             baseMass=0,
#             baseCollisionShapeIndex=-1,
#             baseVisualShapeIndex=visual_shape_id,
#             basePosition=pos.tolist(),
#             useMaximalCoordinates=True
#         )
#     )
#
# # --- Animation loop ---
# line_ids = [None] * len(skeleton_edges)
# trajectory = reg_f_np_scaled.transpose(2, 0, 1)  # (frames, landmarks, 3)
# frame_duration = 1.0 / 15  # 15 FPS
#
# try:
#     while True:  # Loop forever
#         for frame in trajectory:
#             # Move landmarks
#             for i, pos in enumerate(frame):
#                 p.resetBasePositionAndOrientation(
#                     landmark_ids[i], pos.tolist(), [0, 0, 0, 1]
#                 )
#             # Draw skeleton lines
#             for idx, (i, j) in enumerate(skeleton_edges):
#                 start = frame[i]
#                 end = frame[j]
#                 if line_ids[idx] is not None:
#                     p.removeUserDebugItem(line_ids[idx])
#                 line_ids[idx] = p.addUserDebugLine(
#                     start, end,
#                     lineColorRGB=[0.2, 0.3, 1],
#                     lineWidth=3,
#                     lifeTime=frame_duration * 2  # Lines fade out smoothly
#                 )
#             p.stepSimulation()
#             time.sleep(frame_duration)
# except KeyboardInterrupt:
#     print("Animation loop stopped.")
# finally:
#     p.disconnect()

# -------------------------------
# 12. Play trajectory with Inverse Kinematics in PyBullet
# -------------------------------
# import pybullet as p
# import pybullet_data
# import time
# import numpy as np
#
# # Make sure your fixed_predicted variable is (4, 3, num_frames)
# # Each frame should represent 4 landmark positions in 3D space
#
# def play_trajectory_with_ik(fixed_predicted, urdf_path="simple_3dof_robot.urdf", time_step=1./60., speed=1.0):
#     # Setup simulation
#     physicsClient = p.connect(p.GUI)
#     p.setAdditionalSearchPath(pybullet_data.getDataPath())
#     p.setGravity(0, 0, -9.81)
#     p.setTimeStep(time_step)
#     p.loadURDF("plane.urdf")
#
#     robot_id = p.loadURDF(urdf_path, basePosition=[0, 0, 0], useFixedBase=True)
#
#     # Identify tip link and movable joints
#     tip_link_name = "tip_link"
#     end_effector_link_index = -1
#     movable_joints = []
#
#     num_joints = p.getNumJoints(robot_id)
#     for i in range(num_joints):
#         info = p.getJointInfo(robot_id, i)
#         joint_name = info[1].decode('utf-8')
#         joint_type = info[2]
#         joint_link_name = info[12].decode('utf-8')
#
#         # Save index of the end-effector link
#         if joint_link_name == tip_link_name:
#             end_effector_link_index = i
#
#         # Save all revolute or prismatic joints
#         if joint_type in [p.JOINT_REVOLUTE, p.JOINT_PRISMATIC]:
#             movable_joints.append({
#                 'index': i,
#                 'lower': info[8],
#                 'upper': info[9]
#             })
#
#     if end_effector_link_index == -1:
#         raise RuntimeError("End-effector 'tip_link' not found.")
#
#     def clamp_joint_angles(angles):
#         """Clamp joint angles to their limits."""
#         clamped = []
#         for angle, joint in zip(angles, movable_joints):
#             clamped_angle = np.clip(angle, joint['lower'], joint['upper'])
#             clamped.append(clamped_angle)
#         return clamped
#
#     # Reset robot to initial position
#     start_pos = fixed_predicted[-1, :, 0]
#     if np.any(np.isnan(start_pos)):
#         raise ValueError("Initial target position contains NaN.")
#
#     init_angles = p.calculateInverseKinematics(robot_id, end_effector_link_index, start_pos)
#     init_angles = clamp_joint_angles(init_angles)
#
#     for joint, angle in zip(movable_joints, init_angles):
#         p.resetJointState(robot_id, joint['index'], angle)
#
#     # Play trajectory
#     num_frames = fixed_predicted.shape[2]
#     num_joints = p.getNumJoints(robot_id)
#
#     # Get end-effector link index (tip_link)
#     end_effector_index = \
#     [i for i in range(num_joints) if p.getJointInfo(robot_id, i)[12].decode("utf-8") == "tip_link"][0]
#
#     # Define controllable joints
#     controlled_joints = [i for i in range(num_joints) if p.getJointInfo(robot_id, i)[2] == p.JOINT_REVOLUTE]
#
#     # Joint limits
#     joint_limits = [p.getJointInfo(robot_id, i) for i in controlled_joints]
#     lower_limits = [info[8] for info in joint_limits]
#     upper_limits = [info[9] for info in joint_limits]
#     joint_ranges = [ul - ll for ll, ul in zip(lower_limits, upper_limits)]
#     rest_poses = [0.0 for _ in controlled_joints]
#     joint_damping = [0.1] * len(controlled_joints)
#
#     for frame in range(num_frames):
#         # Get the desired end-effector position from predicted landmarks
#         target_pos = fixed_predicted[-1, :, frame]  # tip_link is the last landmark
#         # Optional: add a fixed orientation (or use None to ignore it)
#         target_ori = None  # or use: p.getQuaternionFromEuler([0, 0, 0])
#
#         # Inverse Kinematics with full joint configuration
#         joint_angles = p.calculateInverseKinematics(
#             bodyUniqueId=robot_id,
#             endEffectorLinkIndex=end_effector_index,
#             targetPosition=target_pos,
#             lowerLimits=lower_limits,
#             upperLimits=upper_limits,
#             jointRanges=joint_ranges,
#             restPoses=rest_poses,
#             jointDamping=joint_damping
#         )
#
#         for i, joint_index in enumerate(controlled_joints):
#             p.setJointMotorControl2(
#                 robot_id,
#                 joint_index,
#                 p.POSITION_CONTROL,
#                 targetPosition=joint_angles[i],
#                 force=5
#             )
#
#         for _ in range(int(speed / time_step)):
#             p.stepSimulation()
#             time.sleep(time_step)
#
#     input("Press Enter to exit...")
#     p.disconnect()
#
# play_trajectory_with_ik(data_3d)

# # ---------------------------
# # 12. PyBullet animate with direct angles
# # ---------------------------
#
# import numpy as np
# import pybullet as p
# import pybullet_data
# import time
#
#
# def compute_joint_angles_from_landmarks(landmarks_frame):
#     proj = landmarks_frame[:, [0, 2]]  # project to XZ plane
#     v1 = proj[1] - proj[0]
#     v2 = proj[2] - proj[1]
#     v3 = proj[3] - proj[2]
#
#     theta1 = np.arctan2(v1[1], v1[0])
#
#     cos_theta2 = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
#     theta2 = np.arccos(np.clip(cos_theta2, -1.0, 1.0))
#     if np.cross(np.append(v1, 0), np.append(v2, 0))[2] < 0:
#         theta2 = -theta2
#
#     cos_theta3 = np.dot(v2, v3) / (np.linalg.norm(v2) * np.linalg.norm(v3))
#     theta3 = np.arccos(np.clip(cos_theta3, -1.0, 1.0))
#     if np.cross(np.append(v2, 0), np.append(v3, 0))[2] < 0:
#         theta3 = -theta3
#
#     return [theta1, theta2, theta3]
#
#
# def correct_landmarks_lengths(landmarks_frame, ref_lengths):
#     """
#     Adjusts landmarks to preserve constant limb lengths (XZ plane).
#     landmarks_frame: shape (4, 3)
#     ref_lengths: list of 3 segment lengths
#     Returns: corrected 4x3 array
#     """
#     proj = landmarks_frame[:, [0, 2]]
#     corrected = np.zeros_like(proj)
#
#     # Start from base
#     corrected[0] = proj[0]
#     v1_dir = (proj[1] - proj[0])
#     v1_dir /= np.linalg.norm(v1_dir)
#     corrected[1] = corrected[0] + ref_lengths[0] * v1_dir
#
#     v2_dir = (proj[2] - proj[1])
#     v2_dir /= np.linalg.norm(v2_dir)
#     corrected[2] = corrected[1] + ref_lengths[1] * v2_dir
#
#     v3_dir = (proj[3] - proj[2])
#     v3_dir /= np.linalg.norm(v3_dir)
#     corrected[3] = corrected[2] + ref_lengths[2] * v3_dir
#
#     # Re-insert into original Y position
#     result = np.zeros_like(landmarks_frame)
#     result[:, 0] = corrected[:, 0]
#     result[:, 1] = landmarks_frame[:, 1]  # retain Y
#     result[:, 2] = corrected[:, 1]
#     return result
#
#
# def play_trajectory_with_ik(fixed_predicted, urdf_path="simple_3dof_robot.urdf", time_step=1./60., speed=1.0):
#     physicsClient = p.connect(p.GUI)
#     p.setAdditionalSearchPath(pybullet_data.getDataPath())
#     p.setGravity(0, 0, -9.81)
#     p.setTimeStep(time_step)
#     p.loadURDF("plane.urdf")
#
#     robot_id = p.loadURDF(urdf_path, basePosition=[0, 0, 0], useFixedBase=True)
#
#     # Find revolute joints
#     num_joints = p.getNumJoints(robot_id)
#     controlled_joints = [i for i in range(num_joints) if p.getJointInfo(robot_id, i)[2] == p.JOINT_REVOLUTE]
#
#     if len(controlled_joints) < 3:
#         raise RuntimeError("Expected at least 3 revolute joints.")
#
#     # Precompute link lengths from the first frame
#     first_frame = fixed_predicted[:, :, 0]
#     ref_lengths = [
#         np.linalg.norm(first_frame[1, [0, 2]] - first_frame[0, [0, 2]]),
#         np.linalg.norm(first_frame[2, [0, 2]] - first_frame[1, [0, 2]]),
#         np.linalg.norm(first_frame[3, [0, 2]] - first_frame[2, [0, 2]])
#     ]
#
#     num_frames = fixed_predicted.shape[2]
#
#     for frame in range(num_frames):
#         landmarks_frame = fixed_predicted[:, :, frame]
#         if np.any(np.isnan(landmarks_frame)):
#             print(f"Skipping frame {frame} due to NaNs.")
#             continue
#
#         # Correct landmark lengths
#         landmarks_corrected = correct_landmarks_lengths(landmarks_frame, ref_lengths)
#
#         # Compute joint angles
#         try:
#             joint_angles = compute_joint_angles_from_landmarks(landmarks_corrected)
#         except Exception as e:
#             print(f"Frame {frame}: Failed to compute joint angles:", e)
#             continue
#
#         for i, joint_index in enumerate(controlled_joints[:3]):
#             p.setJointMotorControl2(
#                 robot_id,
#                 joint_index,
#                 controlMode=p.POSITION_CONTROL,
#                 targetPosition=joint_angles[i],
#                 force=10
#             )
#
#         for _ in range(int(speed / time_step)):
#             p.stepSimulation()
#             time.sleep(time_step)
#
#     input("Press Enter to exit...")
#     p.disconnect()
#
# play_trajectory_with_ik(fixed_predicted)



# # ----------------------
# # --- FINAL FUNCTION ---
# # ----------------------
#
# def size_shape_regression_length_constrained(data_3d, connections, lengths, anchor_indices, poly_gate=True):
#
#     # ------------------------------------------------
#     # SIZE AND SHAPE REGRESSIN WITH LENGTH CONSTRAINED
#     # ------------------------------------------------
#     from sklearn.preprocessing import PolynomialFeatures
#     from sklearn.linear_model import LinearRegression
#     # --- Regression model from R ---
#     import os
#     import numpy as np
#
#     # -----------------------------
#     # 1. Environment Setup
#     # -----------------------------
#     #                                               IMPORTANT
#     #                               THIS SETUP WILL VARY DEPENDING ON YOUR COMPUTER
#     #                               THIS PART OF THE CODE MUST BE CHANGE BEFORE USING ON YOUR SETUP
#     os.environ["R_HOME"] = "D:/inne/R-4.5.1"
#     os.environ["HOME"] = "D:/inne/RWork"
#     os.environ["R_USER"] = "D:/inne/RWork"
#     os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
#     os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
#     os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
#     # -----------------------------
#     # 2. rpy2 Imports and Conversions
#     # -----------------------------
#     from rpy2 import robjects
#     from rpy2.robjects import r, pandas2ri, default_converter
#     from rpy2.robjects.conversion import localconverter
#     from rpy2.rinterface import FloatSexpVector
#     from rpy2.robjects.vectors import IntVector
#
#     # Optional: suppress warnings
#     import warnings
#     warnings.filterwarnings("ignore", category=UserWarning) #Still triggers most of the errors
#
#     # -----------------------------
#     # 3. Set R Working Directory
#     # -----------------------------
#     #                                               IMPORTANT
#     #                               THIS SETUP WILL VARY DEPENDING ON YOUR COMPUTER
#     #                               THIS PART OF THE CODE MUST BE CHANGE BEFORE USING ON YOUR SETUP
#     r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  # R script directory
#     r('source("mainEM_3d_size_shape.r")')  # directory to the R script
#     print("✅ R working directory set to:", r('getwd()')[0])
#
#     # --------------------------------------
#     # 3. Load CSV and prepare 3D NumPy array
#     # --------------------------------------
#     # No need as data are loaded now with the def function
#     print("Plotting original landmarks...")
#     animate_skeleton(data_3d, name="Original Landmarks")
#
#     # -----------------------------
#     # 4. Convert NumPy array to R array
#     # -----------------------------
#     data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
#     data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
#     robjects.globalenv["data"] = data_r_array
#
#     # -----------------------------
#     # 5. Permute in R and run EM polynomial regression
#     # -----------------------------
#     print("Running Size & Shape Regression...")
#     r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
#     r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
#     # -----------------------------
#     # 6. Extract R outputs back to NumPy
#     # -----------------------------
#     with localconverter(default_converter + pandas2ri.converter):
#         reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
#         reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)
#
#     print("Raw shape of reg_f_np:", reg_f_np.shape)
#     print("Raw shape of reg_r_np:", reg_r_np.shape)
#
#     # -----------------------------
#     # 7. Transpose to standard Python shape: (21, 3, 10, N)
#     # -----------------------------
#     reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
#     print("reg_f_np reshaped to:", reg_f_np.shape)
#
#     if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
#         reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#         print("reg_r_np reshaped to:", reg_r_np.shape)
#     elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
#         reg_r_np = reg_r_np.transpose(1, 0, 2)
#         print("reg_r_np reshaped to:", reg_r_np.shape)
#     else:
#         print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
#     # -----------------------------
#     # 8. Optionally remove last dim if N == 1
#     # -----------------------------
#     if reg_f_np.shape[-1] == 1:
#         reg_f_np = reg_f_np[..., 0]
#     if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#         reg_r_np = reg_r_np[..., 0]
#
#     # -----------------------------
#     # 9. Final Output
#     # -----------------------------
#     print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
#     print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
#     print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1]) #Usually it is 0.0 and 0.0
#     reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
#     reg_r_np = reg_r_np[..., 0]
#     print("Size & Shape Regression Success")
#     print("Plotting Size & Shape Regression landmarks...")
#     animate_skeleton(reg_f_np, name="Size & Shape Regression")
#
#     # ---------------------------
#     # Polynomial regression model
#     # ---------------------------
#     def polynomial_regression(reg_f_np):
#         def fit_trajectory(data, degree=3):
#             """
#             data: shape (num_landmarks, 3, num_frames)
#             """
#             num_landmarks, num_dims, num_frames = data.shape
#             time = np.arange(num_frames).reshape(-1, 1)
#
#             poly = PolynomialFeatures(degree)
#             X_time = poly.fit_transform(time)
#
#             predicted = np.zeros_like(data)
#
#             for l in range(num_landmarks):
#                 for d in range(num_dims):
#                     y = data[l, d, :]
#                     model = LinearRegression().fit(X_time, y)
#                     predicted[l, d, :] = model.predict(X_time)
#
#             return predicted
#
#         # predicted = fit_trajectory(data_3d)
#         predicted = fit_trajectory(reg_f_np)
#         return predicted
#
#     if poly_gate == True:
#         print("Running Polynomial Regression...")
#         predicted = polynomial_regression(reg_f_np)
#         print("Polynomial Regression Success")
#         print("Plotting Polynomial Regression landmarks...")  # Should be (4, 3, n_frames)
#         animate_skeleton(predicted, name="Polynomial Regression")
#     else:
#         print("Polynomial Regression omitted due function config.")
#         predicted = reg_f_np
#
#
#     # ----------------------------
#     # Length constrained alignment
#     # ----------------------------
#     import numpy as np
#     from scipy.optimize import minimize
#
#     def length_constrained_alignment(predicted, reference, connections, lengths, anchor_indices=[0], max_iter=200):
#         """
#         Aligns predicted to reference using nonlinear optimization:
#         - Anchors specified indices exactly
#         - Preserves segment lengths given by 'connections' and 'lengths'
#         - Attempts to match reference pose as closely as possible
#
#         Parameters:
#         - predicted: np.ndarray of shape (21, 3)
#         - reference: np.ndarray of shape (21, 3)
#         - connections: list of (i,j) pairs (landmark indices)
#         - lengths: list of floats, desired segment lengths
#         - anchor_indices: indices to anchor exactly to reference
#         - max_iter: maximum optimization iterations (default 200)
#
#         Returns:
#         - aligned: np.ndarray of shape (21, 3)
#         """
#         n_landmarks = predicted.shape[0]
#
#         def loss(x):
#             # x is flattened (21 * 3)
#             x = x.reshape((n_landmarks, 3))
#             # 1. Anchors: penalize deviation from reference
#             anchor_loss = np.sum((x[anchor_indices] - reference[anchor_indices]) ** 2)
#             # 2. Lengths: penalize deviation from desired lengths
#             length_loss = 0
#             for (idx, (i, j)) in enumerate(connections):
#                 seg_length = np.linalg.norm(x[i] - x[j])
#                 length_loss += (seg_length - lengths[idx]) ** 2
#             # 3. Global RMSD: encourage closeness to reference
#             rmsd_loss = np.sum((x - reference) ** 2)
#             # Blend weights (adjust for your use-case)
#             total_loss = anchor_loss * 100 + length_loss * 100 + rmsd_loss * 1
#             return total_loss
#
#         x0 = predicted.flatten()
#         res = minimize(loss, x0, method='L-BFGS-B', options={'maxiter': max_iter})
#         aligned = res.x.reshape((n_landmarks, 3))
#         return aligned
#
#     # Example frame-loop usage
#     def batch_length_constrained_alignment(predicted_array, reference_array, connections, lengths, anchor_indices=[0],
#                                            max_iter=200):
#         """
#         Aligns all frames in arrays of shape (21, 3, n_frames)
#         Returns aligned_array of same shape.
#         """
#         n_landmarks, n_coords, n_frames = predicted_array.shape
#         aligned_array = np.zeros_like(predicted_array)
#         for t in range(n_frames):
#             aligned = length_constrained_alignment(
#                 predicted_array[:, :, t],
#                 reference_array[:, :, t],
#                 connections,
#                 lengths,
#                 anchor_indices=anchor_indices,
#                 max_iter=max_iter
#             )
#             aligned_array[:, :, t] = aligned
#         return aligned_array
#
#     # Usage example:
#     print("Running Length Constrained Alignment...")
#     aligned = batch_length_constrained_alignment(predicted, data_3d, connections, lengths, anchor_indices)
#     print("Length Constrained Alignment Success")
#     print("Plotting Length Constrained Alignment...")
#     animate_skeleton(aligned, name="Length-Constrained Alignment")
#
#     return aligned
#
#
# # --------------------------
# # Running simulation with landmarks (simple hand)
# # --------------------------
# # expected shape: (landmarks, coords, frames)
# def Pybullet_simulation(data, URDF_PATH="D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/twenty_one_landmark_hand.urdf", SLEEP_TIME=0.05):
#     import pybullet as p
#     import pybullet_data
#     import numpy as np
#     import pandas as pd
#     import time
#     from scipy.optimize import minimize
#
#     # --- CONFIGURATION ---
#     VISUALIZE_ERROR = True  # Show error in GUI
#     ERROR_SPHERE_RADIUS = 0.01  # Spheres for error visualization
#
#     # --- LOAD LANDMARKS ---
#     print("Simulation landmarks shape: ", data.shape) #expected shape: (landmarks, coords, frames)
#     landmarks = data.transpose(2, 0, 1)  # Transpose to (frames, landmarks, 3)
#     n_frames = landmarks.shape[0]
#     print("After tanspose: ", landmarks.shape, "Frames: ", n_frames)
#
#     # --- PYBULLET SETUP ---
#     p.connect(p.GUI)
#     p.setAdditionalSearchPath(pybullet_data.getDataPath())
#     hand = p.loadURDF(URDF_PATH, [0, 0, 0], useFixedBase=True)
#
#     # --- GET LINK AND JOINT INDICES AUTOMATICALLY ---
#     def get_all_joint_info(body_id):
#         n_joints = p.getNumJoints(body_id)
#         joints = []
#         links = []
#         for i in range(n_joints):
#             info = p.getJointInfo(body_id, i)
#             joints.append(info[1].decode("utf-8"))
#             links.append(info[12].decode("utf-8"))
#         return joints, links
#
#     joint_names, link_names = get_all_joint_info(hand)
#
#     # Map landmark names to link indices (palm is -1 in PyBullet)
#     landmark_link_names = [
#         "palm",
#         "thumb_link1", "thumb_link2", "thumb_link3", "thumb_tip",
#         "index_link1", "index_link2", "index_link3", "index_tip",
#         "middle_link1", "middle_link2", "middle_link3", "middle_tip",
#         "ring_link1", "ring_link2", "ring_link3", "ring_tip",
#         "little_link1", "little_link2", "little_link3", "little_tip"
#     ]
#     landmark_link_indices = []
#     for name in landmark_link_names:
#         if name == "palm":
#             landmark_link_indices.append(-1)
#         else:
#             try:
#                 idx = link_names.index(name)
#                 landmark_link_indices.append(idx)
#             except ValueError:
#                 print(f"WARNING: Link name {name} not found!")
#                 landmark_link_indices.append(None)
#
#     # Get all joint indices (15 joints: 3 x 5 fingers)
#     finger_joint_names = [
#         "thumb_joint1", "thumb_joint2", "thumb_joint3",
#         "index_joint1", "index_joint2", "index_joint3",
#         "middle_joint1", "middle_joint2", "middle_joint3",
#         "ring_joint1", "ring_joint2", "ring_joint3",
#         "little_joint1", "little_joint2", "little_joint3"
#     ]
#     joint_indices = []
#     for name in finger_joint_names:
#         try:
#             joint_indices.append(joint_names.index(name))
#         except ValueError:
#             print(f"WARNING: Joint name {name} not found!")
#
#     # --- FK UTILITY: GET ALL LANDMARK POSITIONS FOR GIVEN JOINT ANGLES ---
#     def get_hand_landmark_positions(hand, joint_angles):
#         # Set joint angles
#         for ji, angle in zip(joint_indices, joint_angles):
#             p.resetJointState(hand, ji, angle)
#         p.stepSimulation()
#         # Get all landmark positions
#         positions = []
#         for idx in landmark_link_indices:
#             if idx == -1:
#                 pos, _ = p.getBasePositionAndOrientation(hand)
#             elif idx is None:
#                 pos = (np.nan, np.nan, np.nan)
#             else:
#                 state = p.getLinkState(hand, idx)
#                 pos = state[0] if state else (np.nan, np.nan, np.nan)
#             positions.append(np.array(pos))
#         return np.array(positions)
#
#     # --- LOSS FUNCTION: SUM SQUARED DISTANCES ---
#     def pose_loss(joint_angles, hand, target_landmarks):
#         predicted = get_hand_landmark_positions(hand, joint_angles)
#         return np.sum((predicted - target_landmarks) ** 2)
#
#     # --- JOINT LIMITS ---
#     lower = [0.0] * len(joint_indices)
#     upper = [1.5] * len(joint_indices)
#     joint_bounds = [(l, u) for l, u in zip(lower, upper)]
#
#     # --- ERROR VISUALIZATION ---
#     def draw_error_spheres(targets, actuals, color=[1, 0, 0, 0.6], radius=ERROR_SPHERE_RADIUS):
#         sphere_ids = []
#         for t, a in zip(targets, actuals):
#             err = np.linalg.norm(t - a)
#             # Color: green if error < 0.01, red otherwise
#             c = [0, 1, 0, 0.6] if err < 0.01 else color
#             s_id = p.createVisualShape(p.GEOM_SPHERE, rgbaColor=c, radius=radius)
#             sphere_ids.append(p.createMultiBody(baseMass=0, baseVisualShapeIndex=s_id, basePosition=t))
#         return sphere_ids
#
#     def remove_error_spheres(sphere_ids):
#         for sid in sphere_ids:
#             p.removeBody(sid)
#
#     # --- OPTIMIZATION AND ANIMATION LOOP ---
#     prev_angles = np.zeros(len(joint_indices))
#     time.sleep(SLEEP_TIME * 5)
#     for frame in range(n_frames):
#         print(f"Frame {frame + 1}/{n_frames}")
#         target_landmarks = landmarks[frame]
#         # Optimize joint angles to minimize loss
#         result = minimize(
#             pose_loss, prev_angles,
#             args=(hand, target_landmarks),
#             method="L-BFGS-B",
#             bounds=joint_bounds,
#             options={'maxiter': 200}
#         )
#         optimal_angles = result.x
#         # Apply angles to hand
#         for ji, angle in zip(joint_indices, optimal_angles):
#             p.resetJointState(hand, ji, angle)
#         p.stepSimulation()
#         # Get achieved positions
#         achieved_landmarks = get_hand_landmark_positions(hand, optimal_angles)
#         # Visualize error
#         sphere_ids = []
#         if VISUALIZE_ERROR:
#             sphere_ids = draw_error_spheres(target_landmarks, achieved_landmarks)
#         # Print mean error for the frame
#         mean_error = np.mean(np.linalg.norm(achieved_landmarks - target_landmarks, axis=1))
#         print(f"Mean landmark error: {mean_error:.4f} meters")
#         time.sleep(SLEEP_TIME)
#         if VISUALIZE_ERROR:
#             remove_error_spheres(sphere_ids)
#         prev_angles = optimal_angles.copy()
#
#     p.disconnect()
#
#
#
# # ------------------------
# # --- Loading the data ---
# # ------------------------
#
# import pandas as pd
#
# # --- landmarks of dummy hand ---
# n_landmarks = 21
# n_coords = 3
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/realistic_hand_landmarks.csv',  header=None) #Directory to the CSV file
# data_flat = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
# n_frames = data_flat.shape[0]
# data_3d = data_flat.reshape(n_frames, n_landmarks, n_coords)  # (15 frmaes, 21 landmarks, 3D)
# print(data_3d.shape)
# data_3d = data_3d.transpose(1, 2, 0)  # Transpose to (landmarks, 3, frames)
#
# # # --- landmarks of professor's hand ---
# # df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv')  # Directory to the CSV file
# # data_flat = df.to_numpy()
# # # print("First row:", data_flat[0])
# # # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# # data_3d = data_flat.T.reshape((21, 3, 10), order='F')  # (21 landmarks, 3D, 10 samples)
#
# connections = [(0, 1), (1, 2), (2, 3), (3, 4),  # Thumb
#                (0, 5), (5, 6), (6, 7), (7, 8),  # Index
#                (0, 9), (9, 10), (10, 11), (11, 12),  # Middle
#                (0, 13), (13, 14), (14, 15), (15, 16),  # Ring
#                (0, 17), (17, 18), (18, 19), (19, 20)]  # Little        # index pairs
#
# # lengths = [0.040, 0.033, 0.028, 0.024,
# #            0.075, 0.047, 0.02, 0.015,
# #            0.075, 0.047, 0.02, 0.015,
# #            0.075, 0.047, 0.02, 0.015,
# #            0.075, 0.047, 0.02, 0.015]  # measured from professor's hand
#
# lengths = [0.054, 0.05, 0.044, 0.044,
#            0.066, 0.058, 0.05, 0.05,
#            0.07, 0.062, 0.054, 0.054,
#            0.066, 0.058, 0.05, 0.05,
#            0.056, 0.046, 0.04, 0.04] #measured from dummy hand
#
# # --------------------------
# # --- RUN THE SIMULATION ---
# # --------------------------
#
# # Expected input:
# #   - 'data_3d' (set of landmarks, which follows pattern: [landmarks, coords, frames]),
# #   - 'connections' (list of paired connections in robot)
# #   - 'lengths' (list in size of connections' length determining length of each connection)
# #   - 'anchor_indices' (optional argument which anchor chosen point/s in the location of the original robot. Real expectation in robot regression/simulation)
# #   - 'poly_gate' (optional argument that runs polynomial regression model, smoothens out the data, sometimes improving the Pybullet simulation)
# # Expected output:
# #   - 'regressed_landmarks' (set of size&shape regressed landmarks fitting for Pybullet simulation, plotting or other purposes)
# result = size_shape_regression_length_constrained(data_3d=data_3d, connections=connections, lengths=lengths, anchor_indices=[0, 1, 5, 9, 13, 17], poly_gate=True)
# #Expected input:
# #   - 'data' (set of landmarks, which follows pattern: [landmarks, coords, frames])
# #   - 'URDF_PATH' (path to your robot, that simulation will be run by, use robot that you used for capturing the landmarks)
# #   - 'SLEEP_TIME' (Defines speed between the frames in the simulation)
# #Expected output:
# #   - Pybullet simulation (NOT THE ACTUAL PARAMETER)
# Pybullet_simulation(result)






# # ------------------------------------------------
# # SIZE AND SHAPE REGRESSION WITH LENGTH CONSTRAINED
# # ------------------------------------------------
# from sklearn.preprocessing import PolynomialFeatures
# from sklearn.linear_model import LinearRegression
#
# # --- Regression model from R ---
#
# import os
# import numpy as np
# import pandas as pd
#
# # -----------------------------
# # 1. Environment Setup
# # -----------------------------
# os.environ["R_HOME"] = "D:/inne/R-4.5.1"
# os.environ["HOME"] = "D:/inne/RWork"
# os.environ["R_USER"] = "D:/inne/RWork"
# os.environ["TEMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["TMP"] = "C:/Users/andur/AppData/Local/Temp"
# os.environ["RPY2_CFFI_MODE"] = "ABI"  # For better compatibility
#
# # -----------------------------
# # 2. rpy2 Imports and Conversions
# # -----------------------------
# from rpy2 import robjects
# from rpy2.robjects import r, pandas2ri, default_converter
# from rpy2.robjects.conversion import localconverter
# from rpy2.rinterface import FloatSexpVector
# from rpy2.robjects.vectors import IntVector
#
# # Optional: suppress warnings
# import warnings
# warnings.filterwarnings("ignore", category=UserWarning)
#
# # -----------------------------
# # 3. Set R Working Directory
# # -----------------------------
# r('setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")')  #R script directory
# r('source("mainEM_3d_size_shape.r")')   #directory to the R script
# print("✅ R working directory set to:", r('getwd()')[0])
#
# # -----------------------------
# # 3. Load CSV and prepare 3D NumPy array
# # -----------------------------
#
# # # --- landmarks of dummy hand ---
# # n_landmarks = 21
# # n_coords = 3
# # df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/realistic_hand_landmarks.csv',  header=None) #Directory to the CSV file
# # data_flat = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
# # n_frames = data_flat.shape[0]
# # data_3d = data_flat.reshape(n_frames, n_landmarks, n_coords)  # (15 frmaes, 21 landmarks, 3D)
# # print(data_3d.shape)
# # data_3d = data_3d.transpose(1, 2, 0)  # Transpose to (landmarks, 3, frames)
# #
# # --- landmarks of professor's hand ---
# df = pd.read_csv('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv') #Directory to the CSV file
# data_flat = df.to_numpy()
# # print("First row:", data_flat[0])
# # print("Expected format: [x1 y1 z1 x2 y2 z2 ...]")
# data_3d = data_flat.T.reshape((21, 3, 10), order='F')  # (21 landmarks, 3D, 10 samples)
#
# animate_skeleton(data_3d, name="Original landmarks")
# # -----------------------------
# # 4. Convert NumPy array to R array
# # -----------------------------
# data_r_vector = FloatSexpVector(data_3d.flatten(order='F'))
# data_r_array = r["array"](data_r_vector, dim=IntVector(data_3d.shape))
# robjects.globalenv["data"] = data_r_array
#
# # -----------------------------
# # 5. Permute in R and run EM polynomial regression
# # -----------------------------
# r('data_perm <- aperm(data, c(2, 1, 3))')  # → (3, 21, 10)
# r('reg1 <- EM.poly.fit.cov.3d(data_perm, deg=1, niter=300)')
#
# # -----------------------------
# # 6. Extract R outputs back to NumPy
# # -----------------------------
# with localconverter(default_converter + pandas2ri.converter):
#     reg_f_np = np.array(r('reg1$f'))  # Expected: (3, 21, 10, N)
#     reg_r_np = np.array(r('reg1$r'))  # Could be (3, 21, 10) or (3, 21, 10, N)
#
# print("Raw shape of reg_f_np:", reg_f_np.shape)
# print("Raw shape of reg_r_np:", reg_r_np.shape)
#
# # -----------------------------
# # 7. Transpose to standard Python shape: (21, 3, 10, N)
# # -----------------------------
# reg_f_np = reg_f_np.transpose(1, 0, 2, 3)  # → (21, 3, 10, N)
# print("reg_f_np reshaped to:", reg_f_np.shape)
#
# if reg_r_np.ndim == 4 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2, 3)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# elif reg_r_np.ndim == 3 and reg_r_np.shape[0] == 3:
#     reg_r_np = reg_r_np.transpose(1, 0, 2)
#     print("reg_r_np reshaped to:", reg_r_np.shape)
# else:
#     print("⚠️ Unexpected reg_r_np shape — no transpose applied.")
#
# # -----------------------------
# # 8. Optionally remove last dim if N == 1
# # -----------------------------
# if reg_f_np.shape[-1] == 1:
#     reg_f_np = reg_f_np[..., 0]
# if reg_r_np.ndim == 4 and reg_r_np.shape[-1] == 1:
#     reg_r_np = reg_r_np[..., 0]
#
#
# # -----------------------------
# # 9. Final Output
# # -----------------------------
# print("✅ Predicted trajectory (f) shape:", reg_f_np.shape)
# print("✅ Reconstructed samples (r) shape:", reg_r_np.shape)
# print("point 1:", reg_f_np[2][2][2][0], "point 2:", reg_f_np[2][2][2][1])
# reg_f_np = reg_f_np[..., 0]  # shape becomes (21, 3, 10)
# reg_r_np = reg_r_np[..., 0]
#
# animate_skeleton(reg_f_np, name="Size & Shape Regression")
#
#
#
#
# # ---------------------------
# # Polynomial regression model
# # ---------------------------
# def fit_trajectory(data, degree=3):
#     """
#     data: shape (num_landmarks, 3, num_frames)
#     """
#     num_landmarks, num_dims, num_frames = data.shape
#     time = np.arange(num_frames).reshape(-1, 1)
#
#     poly = PolynomialFeatures(degree)
#     X_time = poly.fit_transform(time)
#
#     predicted = np.zeros_like(data)
#
#     for l in range(num_landmarks):
#         for d in range(num_dims):
#             y = data[l, d, :]
#             model = LinearRegression().fit(X_time, y)
#             predicted[l, d, :] = model.predict(X_time)
#
#     return predicted
#
# # predicted = fit_trajectory(data_3d)
# predicted = fit_trajectory(reg_f_np)
#
# print(predicted.shape)  # Should be (4, 3, n_frames)
# animate_skeleton(predicted, name="Polynomial Regression")
#
#
# # ----------------------------
# # Length constrained alignment
# # ----------------------------
# import numpy as np
# from scipy.optimize import minimize
#
# def length_constrained_alignment(predicted, reference, connections, lengths, anchor_indices=[0], max_iter=200):
#     """
#     Aligns predicted to reference using nonlinear optimization:
#     - Anchors specified indices exactly
#     - Preserves segment lengths given by 'connections' and 'lengths'
#     - Attempts to match reference pose as closely as possible
#
#     Parameters:
#     - predicted: np.ndarray of shape (21, 3)
#     - reference: np.ndarray of shape (21, 3)
#     - connections: list of (i,j) pairs (landmark indices)
#     - lengths: list of floats, desired segment lengths
#     - anchor_indices: indices to anchor exactly to reference
#     - max_iter: maximum optimization iterations (default 200)
#
#     Returns:
#     - aligned: np.ndarray of shape (21, 3)
#     """
#     n_landmarks = predicted.shape[0]
#
#     def loss(x):
#         # x is flattened (21 * 3)
#         x = x.reshape((n_landmarks, 3))
#         # 1. Anchors: penalize deviation from reference
#         anchor_loss = np.sum((x[anchor_indices] - reference[anchor_indices])**2)
#         # 2. Lengths: penalize deviation from desired lengths
#         length_loss = 0
#         for (idx, (i, j)) in enumerate(connections):
#             seg_length = np.linalg.norm(x[i] - x[j])
#             length_loss += (seg_length - lengths[idx])**2
#         # 3. Global RMSD: encourage closeness to reference
#         rmsd_loss = np.sum((x - reference)**2)
#         # Blend weights (adjust for your use-case)
#         total_loss = anchor_loss * 100 + length_loss * 100 + rmsd_loss * 1
#         return total_loss
#
#     x0 = predicted.flatten()
#     res = minimize(loss, x0, method='L-BFGS-B', options={'maxiter': max_iter})
#     aligned = res.x.reshape((n_landmarks, 3))
#     return aligned
#
# # Example frame-loop usage
# def batch_length_constrained_alignment(predicted_array, reference_array, connections, lengths, anchor_indices=[0], max_iter=200):
#     """
#     Aligns all frames in arrays of shape (21, 3, n_frames)
#     Returns aligned_array of same shape.
#     """
#     n_landmarks, n_coords, n_frames = predicted_array.shape
#     aligned_array = np.zeros_like(predicted_array)
#     for t in range(n_frames):
#         aligned = length_constrained_alignment(
#             predicted_array[:, :, t],
#             reference_array[:, :, t],
#             connections,
#             lengths,
#             anchor_indices=anchor_indices,
#             max_iter=max_iter
#         )
#         aligned_array[:, :, t] = aligned
#     return aligned_array
#
# connections = [(0,1), (1,2), (2,3), (3,4),          #Thumb
#                (0,5), (5,6), (6,7), (7,8),          #Index
#                (0,9), (9,10), (10,11), (11,12),     #Middle
#                (0,13), (13,14), (14,15), (15,16),   #Ring
#                (0,17), (17,18), (18,19), (19,20)]   #Little        # index pairs
#
# lengths = [0.040, 0.033, 0.028, 0.024,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015,
#            0.075, 0.047, 0.02, 0.015]  # measured from professor's hand
#
# # lengths = [0.054, 0.05, 0.044, 0.044,
# #            0.066, 0.058, 0.05, 0.05,
# #            0.07, 0.062, 0.054, 0.054,
# #            0.066, 0.058, 0.05, 0.05,
# #            0.056, 0.046, 0.04, 0.04] #measured from dummy hand
#
# # Usage example:
# aligned = batch_length_constrained_alignment(predicted, data_3d, connections, lengths, anchor_indices=[0, 1, 5, 9, 13, 17])
# animate_skeleton(aligned, name="Length-Constrained Alignment")



# # --------------------------
# # Running simulation with landmarks (simple hand)
# # --------------------------
# import pybullet as p
# import pybullet_data
# import numpy as np
# import pandas as pd
# import time
# from scipy.optimize import minimize
#
# # --- CONFIGURATION ---
# # CSV_PATH = "realistic_hand_landmarks.csv"   # <-- Your landmark CSV path
# URDF_PATH = "D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/PyBullet/twenty_one_landmark_hand.urdf" # <-- Your URDF file path
# VISUALIZE_ERROR = True                      # Show error in GUI
# ERROR_SPHERE_RADIUS = 0.01                  # Spheres for error visualization
# SLEEP_TIME = 0.04                           # Pause between frames
#
# # --- LOAD LANDMARKS ---
# n_landmarks = 21
# n_coords = 3
# # df = pd.read_csv(CSV_PATH, header=None)
# # data = df.to_numpy()  # (n_frames, n_landmarks * n_coords)
# n_frames = 15
# # landmarks = data.reshape(n_frames, n_landmarks, n_coords)
# print("Final landmarks: ", aligned.shape)
# landmarks = aligned.transpose(2, 0, 1) # Transpose to (frames, landmarks, 3)
# print("After tanspose: ", landmarks.shape)
#
# # --- PYBULLET SETUP ---
# p.connect(p.GUI)
# p.setAdditionalSearchPath(pybullet_data.getDataPath())
# hand = p.loadURDF(URDF_PATH, [0,0,0], useFixedBase=True)
#
# # --- GET LINK AND JOINT INDICES AUTOMATICALLY ---
# def get_all_joint_info(body_id):
#     n_joints = p.getNumJoints(body_id)
#     joints = []
#     links = []
#     for i in range(n_joints):
#         info = p.getJointInfo(body_id, i)
#         joints.append(info[1].decode("utf-8"))
#         links.append(info[12].decode("utf-8"))
#     return joints, links
#
# joint_names, link_names = get_all_joint_info(hand)
#
# # Map landmark names to link indices (palm is -1 in PyBullet)
# landmark_link_names = [
#     "palm",
#     "thumb_link1", "thumb_link2", "thumb_link3", "thumb_tip",
#     "index_link1", "index_link2", "index_link3", "index_tip",
#     "middle_link1", "middle_link2", "middle_link3", "middle_tip",
#     "ring_link1", "ring_link2", "ring_link3", "ring_tip",
#     "little_link1", "little_link2", "little_link3", "little_tip"
# ]
# landmark_link_indices = []
# for name in landmark_link_names:
#     if name == "palm":
#         landmark_link_indices.append(-1)
#     else:
#         try:
#             idx = link_names.index(name)
#             landmark_link_indices.append(idx)
#         except ValueError:
#             print(f"WARNING: Link name {name} not found!")
#             landmark_link_indices.append(None)
#
# # Get all joint indices (15 joints: 3 x 5 fingers)
# finger_joint_names = [
#     "thumb_joint1", "thumb_joint2", "thumb_joint3",
#     "index_joint1", "index_joint2", "index_joint3",
#     "middle_joint1", "middle_joint2", "middle_joint3",
#     "ring_joint1", "ring_joint2", "ring_joint3",
#     "little_joint1", "little_joint2", "little_joint3"
# ]
# joint_indices = []
# for name in finger_joint_names:
#     try:
#         joint_indices.append(joint_names.index(name))
#     except ValueError:
#         print(f"WARNING: Joint name {name} not found!")
#
# # --- FK UTILITY: GET ALL LANDMARK POSITIONS FOR GIVEN JOINT ANGLES ---
# def get_hand_landmark_positions(hand, joint_angles):
#     # Set joint angles
#     for ji, angle in zip(joint_indices, joint_angles):
#         p.resetJointState(hand, ji, angle)
#     p.stepSimulation()
#     # Get all landmark positions
#     positions = []
#     for idx in landmark_link_indices:
#         if idx == -1:
#             pos, _ = p.getBasePositionAndOrientation(hand)
#         elif idx is None:
#             pos = (np.nan, np.nan, np.nan)
#         else:
#             state = p.getLinkState(hand, idx)
#             pos = state[0] if state else (np.nan, np.nan, np.nan)
#         positions.append(np.array(pos))
#     return np.array(positions)
#
# # --- LOSS FUNCTION: SUM SQUARED DISTANCES ---
# def pose_loss(joint_angles, hand, target_landmarks):
#     predicted = get_hand_landmark_positions(hand, joint_angles)
#     return np.sum((predicted - target_landmarks)**2)
#
# # --- JOINT LIMITS ---
# lower = [0.0] * len(joint_indices)
# upper = [1.5] * len(joint_indices)
# joint_bounds = [(l, u) for l, u in zip(lower, upper)]
#
# # --- ERROR VISUALIZATION ---
# def draw_error_spheres(targets, actuals, color=[1,0,0,0.6], radius=ERROR_SPHERE_RADIUS):
#     sphere_ids = []
#     for t, a in zip(targets, actuals):
#         err = np.linalg.norm(t - a)
#         # Color: green if error < 0.01, red otherwise
#         c = [0,1,0,0.6] if err < 0.01 else color
#         s_id = p.createVisualShape(p.GEOM_SPHERE, rgbaColor=c, radius=radius)
#         sphere_ids.append(p.createMultiBody(baseMass=0, baseVisualShapeIndex=s_id, basePosition=t))
#     return sphere_ids
#
# def remove_error_spheres(sphere_ids):
#     for sid in sphere_ids:
#         p.removeBody(sid)
#
# # --- OPTIMIZATION AND ANIMATION LOOP ---
# prev_angles = np.zeros(len(joint_indices))
# time.sleep(SLEEP_TIME*5)
# for frame in range(n_frames):
#     print(f"Frame {frame+1}/{n_frames}")
#     target_landmarks = landmarks[frame]
#     # Optimize joint angles to minimize loss
#     result = minimize(
#         pose_loss, prev_angles,
#         args=(hand, target_landmarks),
#         method="L-BFGS-B",
#         bounds=joint_bounds,
#         options={'maxiter': 200}
#     )
#     optimal_angles = result.x
#     # Apply angles to hand
#     for ji, angle in zip(joint_indices, optimal_angles):
#         p.resetJointState(hand, ji, angle)
#     p.stepSimulation()
#     # Get achieved positions
#     achieved_landmarks = get_hand_landmark_positions(hand, optimal_angles)
#     # Visualize error
#     sphere_ids = []
#     if VISUALIZE_ERROR:
#         sphere_ids = draw_error_spheres(target_landmarks, achieved_landmarks)
#     # Print mean error for the frame
#     mean_error = np.mean(np.linalg.norm(achieved_landmarks - target_landmarks, axis=1))
#     print(f"Mean landmark error: {mean_error:.4f} meters")
#     time.sleep(SLEEP_TIME)
#     if VISUALIZE_ERROR:
#         remove_error_spheres(sphere_ids)
#     prev_angles = optimal_angles.copy()
#
# p.disconnect()