# # # simplified_size_shape_regression.R

# # library(shapes)

# # # Enforce fixed limb lengths in predicted data
# # enforce_limb_lengths <- function(pred, lengths) {
# #   n_landmarks <- dim(pred)[2]
# #   n_frames <- dim(pred)[3]
  
# #   for (f in 1:n_frames) {
# #     pred_frame <- pred[,,f]
    
# #     # Fix L1
# #     current <- pred_frame[,1]
# #     result <- matrix(0, nrow=3, ncol=n_landmarks)
# #     result[,1] <- current
    
# #     for (j in 2:n_landmarks) {
# #       target <- pred_frame[,j]
# #       direction <- target - current
# #       norm <- sqrt(sum(direction^2))
# #       if (norm == 0) {
# #         direction <- c(1,0,0)  # fallback if no movement
# #         norm <- 1
# #       }
# #       direction <- direction / norm
# #       current <- current + direction * lengths[j - 1]
# #       result[,j] <- current
# #     }
    
# #     pred[,,f] <- result
# #   }
# #   return(pred)
# # }

# # simplified_regression <- function(data, deg = 1) {
# #   # data: [3, landmarks, frames]
# #   dims <- dim(data)
# #   k <- dims[1]        # 3D
# #   m <- dims[2]        # landmarks
# #   n <- dims[3]        # frames

# #   # Center each configuration
# #   data_centered <- array(0, dim = c(k, m, n))
# #   for (i in 1:n) {
# #     config <- data[,,i]
# #     centroid <- rowMeans(config)
# #     data_centered[,,i] <- config - centroid
# #   }

# #   # Optional: Procrustes alignment to mean shape
# #   mean_shape <- procGPA(data_centered)$mshape
# #   aligned <- array(0, dim = c(k, m, n))
# #   for (i in 1:n) {
# #     result <- procOPA(mean_shape, data_centered[,,i])
# #     aligned[,,i] <- result$Bhat
# #     # aligned[,,i] <- data_centered[,,i]
# #   }

# #   # Reshape for regression: each landmark coordinate over time
# #   reg_fitted <- array(0, dim = c(k, m, n))
# #   for (dim_index in 1:k) {
# #     for (lm in 1:m) {
# #       y <- aligned[dim_index, lm, ]
# #       fit <- lm(y ~ poly(1:n, deg = deg, raw = TRUE))
# #       reg_fitted[dim_index, lm, ] <- predict(fit)
# #     }
# #   }

# #   return(reg_fitted)
# # }

# # # # Example usage (for use from Python or interactive R):
# # # # Assuming `data_input` is your [3, landmarks, frames] array
# # # reg_result <- simplified_regression(data_input, deg = 2)  # or deg=1

# # # # Enforce limb lengths (e.g., for 3-DOF robot with equal links)
# # # limb_lengths <- c(0.2, 0.2, 0.2)
# # # reg_result_corrected <- enforce_limb_lengths(reg_result, limb_lengths)

# library(shapes)
# library(splines)  # for optional spline regression

# # Enforce fixed limb lengths in predicted data using connectivity
# enforce_limb_lengths_with_connectivity <- function(pred, connections, lengths) {
#   n_frames <- dim(pred)[3]
#   for (f in 1:n_frames) {
#     frame <- pred[,,f]
#     corrected <- frame
#     for (i in seq_along(connections)) {
#       conn <- connections[[i]]
#       parent <- conn[1] + 1  # R is 1-based
#       child <- conn[2] + 1
#       direction <- frame[,child] - frame[,parent]
#       norm <- sqrt(sum(direction^2))
#       if (norm == 0) {
#         direction <- c(1,0,0)
#         norm <- 1
#       }
#       direction <- direction / norm
#       corrected[,child] <- corrected[,parent] + direction * lengths[i]
#     }
#     pred[,,f] <- corrected
#   }
#   return(pred)
# }

# enhanced_regression <- function(D0,
#                                 joint.connections,
#                                 poly.order = 3,
#                                 use.procrustes = TRUE,
#                                 enforce.limb.lengths = FALSE,
#                                 lengths = NULL) {
#   n.landmarks <- dim(D0)[1]
#   n.dim <- dim(D0)[2]
#   n.frames <- dim(D0)[3]

#   # Reshape for regression
#   X <- matrix(rep(1:n.frames, each = poly.order + 1), nrow = n.frames)
#   for (i in 1:poly.order) {
#     X <- cbind(X, (1:n.frames)^i)
#   }

#   fitted.array <- array(0, dim = c(n.dim, n.landmarks, n.frames))
#   original.limb.lengths <- list()

#   for (d in 1:n.dim) {
#     for (l in 1:n.landmarks) {
#       y <- D0[l, d, ]
#       fit <- lm(y ~ poly(1:n.frames, degree = poly.order, raw = TRUE))
#       fitted.values <- predict(fit, data.frame('n.frames' = 1:n.frames))
#       fitted.array[d, l, ] <- fitted.values
#     }
#   }

#   # Apply Procrustes alignment if enabled
#   if (use.procrustes) {
#     ref <- fitted.array[, , 1]
#     for (t in 2:n.frames) {
#       X <- fitted.array[, , t]
#       s <- svd(X %*% t(ref))
#       R <- s$v %*% t(s$u)
#       fitted.array[, , t] <- R %*% X
#     }
#   }

#   # Enforce limb lengths if enabled
#   if (enforce.limb.lengths) {
#     # Compute reference limb lengths from D0
#     limb_lengths <- c()
#     for (conn in joint.connections) {
#       i <- conn[1]
#       j <- conn[2]
#       d <- sqrt(sum((D0[i, , 1] - D0[j, , 1])^2))
#       limb_lengths[paste(i, j, sep = "-")] <- d
#     }

#     # Adjust limbs frame by frame
#     for (k in 1:dim(fitted.array)[3]) {
#       for (conn in joint.connections) {
#         i <- conn[1]
#         j <- conn[2]
#         d <- limb_lengths[paste(i, j, sep = "-")]
#         v <- fitted.array[, j, k] - fitted.array[, i, k]
#         v <- v / sqrt(sum(v^2)) * d
#         fitted.array[, j, k] <- fitted.array[, i, k] + v
#       }
#     }
#   }

#   return(fitted.array)
# }

# enhanced_regression <- function(D0,
#                                 joint.connections,
#                                 poly.order = 3,
#                                 use.procrustes = TRUE,
#                                 use.spline = FALSE,
#                                 enforce.limb.lengths = FALSE,
#                                 lengths = NULL) {

#   library(shapes)
#   library(splines)

#   # Validate dimensions
#   if (length(dim(D0)) != 3) stop("D0 must be a 3D array: [3, landmarks, frames]")
#   k <- dim(D0)[1]   # should be 3
#   m <- dim(D0)[2]   # landmarks
#   n <- dim(D0)[3]   # frames

#   # Convert joint.connections from list to matrix
#   conns <- do.call(rbind, lapply(joint.connections, function(x) as.integer(x)))

#   # Procrustes alignment
#   if (use.procrustes) {
#     mean_shape <- apply(D0, c(1, 2), mean)
#     for (i in 1:n) {
#       D0[, , i] <- procOPA(mean_shape, D0[, , i])$Bhat
#     }
#   }

#   # Create time vector
#   t <- seq(0, 1, length.out = n)

#   # Regression (per coordinate and landmark)
#   D1 <- array(NA, dim = c(3, m, n))
#   for (i in 1:m) {
#     for (j in 1:3) {
#       y <- D0[j, i, ]
#       if (use.spline) {
#         fit <- smooth.spline(t, y, df = poly.order + 1)
#         D1[j, i, ] <- predict(fit, x = t)$y
#       } else {
#         X <- outer(t, 0:poly.order, `^`)
#         coef <- solve(t(X) %*% X) %*% t(X) %*% y
#         D1[j, i, ] <- X %*% coef
#       }
#     }
#   }

#   # Enforce limb lengths if specified
#   if (enforce.limb.lengths && !is.null(lengths)) {
#     for (f in 1:n) {
#       for (idx in 1:nrow(conns)) {
#         a <- conns[idx, 1]
#         b <- conns[idx, 2]
#         if (a > m || b > m) next

#         # Get points
#         p1 <- D1[, a, f]
#         p2 <- D1[, b, f]
#         current_dist <- sqrt(sum((p1 - p2)^2))
#         target_dist <- lengths[[paste0(a, "-", b)]]

#         # Adjust b toward a to match target distance
#         if (!is.null(target_dist) && current_dist > 1e-8) {
#           direction <- (p2 - p1) / current_dist
#           p2_new <- p1 + direction * target_dist
#           D1[, b, f] <- p2_new
#         }
#       }
#     }
#   }

#   return(D1)
# }

#-----------------------
# library(shapes)
# library(splines)

# # Helmert matrix generator
# helmert <- function(n) {
#   H <- matrix(0, nrow = n - 1, ncol = n)
#   for (i in 1:(n - 1)) {
#     H[i, 1:i] <- 1 / sqrt(i * (i + 1))
#     H[i, i + 1] <- -i / sqrt(i * (i + 1))
#   }
#   return(H)
# }

# # Pseudo-inverse of Helmert matrix
# pseudo_inverse_helmert <- function(H) {
#   # Moore–Penrose pseudo-inverse
#   t(H) %*% solve(H %*% t(H))
# }

# enhanced_regression <- function(
#   D0,
#   To = NULL,
#   degree = 3,
#   use_spline = FALSE,
#   procrustes = TRUE,
#   enforce_lengths = FALSE,
#   joint_connections = NULL,
#   apply_helmert = FALSE,
#   lengths = NULL
# ) {
#   k <- dim(D0)[1]
#   T_len <- dim(D0)[3]
#   if (is.null(To)) To <- 1:T_len

#   if (apply_helmert) {
#     H <- helmert(k)                      # (k-1) x k
#     H_inv <- pseudo_inverse_helmert(H)   # k x (k-1)
#     D_proj <- array(0, dim = c(k - 1, 3, T_len))
#     for (t in 1:T_len) {
#       for (coord in 1:3) {
#         D_proj[, coord, t] <- H %*% D0[, , t][, coord]
#       }
#     }
#   } else {
#     D_proj <- D0
#   }

#   if (procrustes) {
#     for (t in 2:T_len) {
#       D_proj[, , t] <- procOPA(D_proj[, , 1], D_proj[, , t])$Bhat
#     }
#   }

#   if (enforce_lengths && !is.null(joint_connections)) {
#     get_lengths <- function(D) {
#       sapply(joint_connections, function(pair) {
#         i <- pair[1]; j <- pair[2]
#         sqrt(sum((D[i, ] - D[j, ])^2))
#       })
#     }
#     ref_lengths <- if (!is.null(lengths)) lengths else get_lengths(D_proj[, , 1])
#     for (t in 1:T_len) {
#       for (idx in seq_along(joint_connections)) {
#         i <- joint_connections[[idx]][1]
#         j <- joint_connections[[idx]][2]
#         vec <- D_proj[j, , t] - D_proj[i, , t]
#         current_length <- sqrt(sum(vec^2))
#         if (current_length != 0) {
#           scale_factor <- ref_lengths[idx] / current_length
#           D_proj[j, , t] <- D_proj[i, , t] + vec * scale_factor
#         }
#       }
#     }
#   }

#   coords <- list()
#   for (dim_idx in 1:3) {
#     coords[[dim_idx]] <- matrix(0, nrow = dim(D_proj)[1], ncol = T_len)
#     for (pt in 1:dim(D_proj)[1]) {
#       coords[[dim_idx]][pt, ] <- D_proj[pt, dim_idx, ]
#     }
#   }

#   regressed <- array(0, dim = dim(D_proj))
#   for (dim_idx in 1:3) {
#     for (pt in 1:dim(D_proj)[1]) {
#       y <- coords[[dim_idx]][pt, ]
#       if (use_spline) {
#         model <- smooth.spline(To, y)
#         regressed[pt, dim_idx, ] <- predict(model, To)$y
#       } else {
#         model <- lm(y ~ poly(To, degree, raw = TRUE))
#         regressed[pt, dim_idx, ] <- predict(model, data.frame(To = To))
#       }
#     }
#   }

#   # Recover full (k x 3 x T_len) using pseudo-inverse of Helmert
#   if (apply_helmert) {
#     recovered <- array(0, dim = c(k, 3, T_len))
#     for (t in 1:T_len) {
#       for (coord in 1:3) {
#         recovered[, coord, t] <- H_inv %*% regressed[, coord, t]
#       }
#     }
#     regressed <- recovered
#   }

#   result <- aperm(regressed, c(2, 1, 3))  # [3, landmarks, frames]
#   return(result)
# }

# #-----------------------
# # Helmert implemented
# library(shapes)
# library(MASS)    # for ginv()
# library(splines) # for smooth.spline()

# # Custom Helmert matrix generator (k x k)
# helmert_matrix <- function(k) {
#   H <- matrix(0, nrow = k, ncol = k)
#   for (i in 1:(k - 1)) {
#     H[i, 1:i] <- 1 / sqrt(i * (i + 1))
#     H[i, i + 1] <- -i / sqrt(i * (i + 1))
#   }
#   H[k, ] <- rep(1 / sqrt(k), k)  # Add row of means for invertibility
#   return(H)
# }

# # Enhanced regression function
# enhanced_regression <- function(
#   D0,
#   To = NULL,
#   degree = 3,
#   use_spline = FALSE,
#   procrustes = TRUE,
#   enforce_lengths = FALSE,
#   joint_connections = NULL,
#   apply_helmert = FALSE,
#   lengths = NULL
# ) {
#   # Input D0 shape: [landmarks, 3, frames]
#   k <- dim(D0)[1]
#   T_len <- dim(D0)[3]

#   if (is.null(To)) {
#     To <- 1:T_len
#   }

#   # --- Apply Helmert projection with pseudo-inverse ---
#   if (apply_helmert) {
#     H <- helmert_matrix(k)          # k x k
#     H_inv <- ginv(H)                # Moore-Penrose pseudo-inverse (k x k)

#     D_proj <- array(0, dim = c(k, 3, T_len))
#     for (t in 1:T_len) {
#       X <- D0[, , t]                # shape [k, 3]
#       X_H <- H %*% X                # Helmert project
#       D_proj[, , t] <- H_inv %*% X_H
#     }
#   } else {
#     D_proj <- D0
#   }

#   # --- Optional: Procrustes alignment ---
#   if (procrustes) {
#     for (t in 2:T_len) {
#       D_proj[, , t] <- procOPA(D_proj[, , 1], D_proj[, , t])$Bhat
#     }
#   }

#   # --- Optional: Enforce limb lengths ---
#   if (enforce_lengths && !is.null(joint_connections)) {
#     get_lengths <- function(D) {
#       sapply(joint_connections, function(pair) {
#         i <- pair[1]; j <- pair[2]
#         sqrt(sum((D[i, ] - D[j, ])^2))
#       })
#     }
#     ref_lengths <- if (!is.null(lengths)) lengths else get_lengths(D_proj[, , 1])

#     for (t in 1:T_len) {
#       for (idx in seq_along(joint_connections)) {
#         i <- joint_connections[[idx]][1]
#         j <- joint_connections[[idx]][2]
#         vec <- D_proj[j, , t] - D_proj[i, , t]
#         current_length <- sqrt(sum(vec^2))
#         if (current_length > 1e-8) {
#           scale <- ref_lengths[idx] / current_length
#           D_proj[j, , t] <- D_proj[i, , t] + vec * scale
#         }
#       }
#     }
#   }

#   # --- Regression step ---
#   coords <- list()
#   for (dim_idx in 1:3) {
#     coords[[dim_idx]] <- matrix(0, nrow = k, ncol = T_len)
#     for (pt in 1:k) {
#       coords[[dim_idx]][pt, ] <- D_proj[pt, dim_idx, ]
#     }
#   }

#   regressed <- array(0, dim = c(k, 3, T_len))
#   for (dim_idx in 1:3) {
#     for (pt in 1:k) {
#       y <- coords[[dim_idx]][pt, ]
#       if (use_spline) {
#         model <- smooth.spline(To, y)
#         regressed[pt, dim_idx, ] <- predict(model, To)$y
#       } else {
#         model <- lm(y ~ poly(To, degree, raw = TRUE))
#         regressed[pt, dim_idx, ] <- predict(model, data.frame(To = To))
#       }
#     }
#   }

#   # --- Return shape: [3, landmarks, frames] ---
#   return(aperm(regressed, c(2, 1, 3)))
# }


# -----------------
# EM implemented
helmert_projection <- function(X) {
  n <- dim(X)[1]
  I <- diag(n)
  ones <- matrix(1, n, n)
  H <- I - (1 / n) * ones
  Xc <- H %*% X
  return(Xc)
}

em_gaussian_estimation <- function(D, max_iter = 100, tol = 1e-6) {
  n <- dim(D)[3]
  p <- prod(dim(D)[1:2])
  D_mat <- matrix(D, nrow = p, ncol = n)

  mu <- rowMeans(D_mat)
  Sigma <- cov(t(D_mat))
  loglik_old <- -Inf

  for (i in 1:max_iter) {
    inv_Sigma <- solve(Sigma)
    diff <- sweep(D_mat, 1, mu)
    loglik <- sum(dnorm(diff, mean = 0, sd = sqrt(diag(Sigma)), log = TRUE))

    # M-step
    mu <- rowMeans(D_mat)
    Sigma <- cov(t(D_mat))

    if (abs(loglik - loglik_old) < tol) break
    loglik_old <- loglik
  }

  list(mu = mu, Sigma = Sigma, loglik = loglik)
}

enhanced_regression <- function(
    D0, 
    To = NULL, 
    degree = 2, 
    use_spline = FALSE, 
    use_procrustes = FALSE, 
    enforce_limb_lengths = FALSE, 
    joint_connections = list(), 
    lengths = NULL, 
    apply_helmert = FALSE
) {
  library(splines)
  dims <- dim(D0)
  k <- dims[1]  # dimensions (usually 3)
  m <- dims[2]  # landmarks
  n <- dims[3]  # frames

  # Flatten for processing
  D_mat <- matrix(aperm(D0, c(2, 1, 3)), nrow = m * k, ncol = n)

  # Apply Helmert if enabled
  if (apply_helmert) {
    for (i in 1:n) {
      D0[,,i] <- helmert_projection(t(D0[,,i]))
    }
  }

  # Apply Procrustes alignment (optional)
  if (use_procrustes) {
    ref <- D0[,,1]
    for (i in 2:n) {
      X <- D0[,,i]
      svd_res <- svd(t(X) %*% ref)
      R <- svd_res$u %*% t(svd_res$v)
      D0[,,i] <- X %*% R
    }
  }

  # Regression
  fitt <- array(0, dim = dim(D0))
  times <- if (is.null(To)) 1:n else To

  for (i in 1:m) {
    for (j in 1:k) {
      y <- D0[j, i, ]
      if (use_spline) {
        fit <- smooth.spline(times, y)
        fitt[j, i, ] <- predict(fit, times)$y
      } else {
        mod <- lm(y ~ poly(times, degree, raw = TRUE))
        fitt[j, i, ] <- predict(mod)
      }
    }
  }
  cat("Shape of fitt:", dim(fitt), "\n")
  # Enforce limb lengths
  if (enforce_limb_lengths && length(joint_connections) > 0) {
    for (t in 1:n) {
      for (j in 1:length(joint_connections)) {
        joint <- joint_connections[[j]]
        i1 <- joint[1] + 1  # 0-based to 1-based
        i2 <- joint[2] + 1
        v <- fitt[, i2, t] - fitt[, i1, t]
        len <- sqrt(sum(v^2))
        target_len <- lengths[j]
        if (len > 1e-6) {
          scale <- target_len / len
          fitt[, i2, t] <- fitt[, i1, t] + scale * v
        }
      }
    }
  }


  return(fitt)
}

#----------------------------------
# Well integrated EM, helmert, more

# library(shapes)
# library(MASS)    # for ginv()
# library(splines) # for smooth.spline()
# library(mvtnorm)
# helmert_projection <- function(X) {
#   n <- dim(X)[1]
#   I <- diag(n)
#   ones <- matrix(1, n, n)
#   H <- I - (1 / n) * ones
#   Xc <- H %*% X
#   return(Xc)
# }

# em_gaussian_estimation <- function(D, max_iter = 100, tol = 1e-6) {
#   n <- dim(D)[3]
#   p <- prod(dim(D)[1:2])
#   D_mat <- matrix(D, nrow = p, ncol = n)

#   mu <- rowMeans(D_mat)
#   Sigma <- cov(t(D_mat))
#   loglik_old <- -Inf

#   for (i in 1:max_iter) {
#     inv_Sigma <- solve(Sigma)
#     diff <- sweep(D_mat, 1, mu)
#     loglik <- sum(dnorm(diff, mean = 0, sd = sqrt(diag(Sigma)), log = TRUE))

#     # M-step
#     mu <- rowMeans(D_mat)
#     Sigma <- cov(t(D_mat))

#     if (abs(loglik - loglik_old) < tol) break
#     loglik_old <- loglik
#   }

#   list(mu = mu, Sigma = Sigma, loglik = loglik)
# }

# enhanced_regression <- function(
#     D0, 
#     To = NULL, 
#     degree = 2, 
#     use_spline = FALSE, 
#     use_procrustes = FALSE, 
#     enforce_limb_lengths = FALSE, 
#     joint_connections = list(), 
#     lengths = NULL, 
#     apply_helmert = FALSE, 
#     apply_em = FALSE
# ) {
#   library(splines)
#   if (is.null(dim(D0))) {
#     stop("D0 has no dimensions. Please ensure it is a 3D array of shape [3, landmarks, frames].")
#   }

#   dims <- dim(D0)
#   k <- dims[1]  # dimensions (usually 3)
#   m <- dims[2]  # landmarks
#   n <- dims[3]  # frames

#   # Apply Helmert if enabled
#   if (apply_helmert) {
#     for (i in 1:n) {
#       D0[,,i] <- helmert_projection(t(D0[,,i]))
#     }
#   }

#   # Apply Procrustes alignment (optional)
#   if (use_procrustes) {
#     ref <- D0[,,1]
#     for (i in 2:n) {
#       X <- D0[,,i]
#       svd_res <- svd(t(X) %*% ref)
#       R <- svd_res$u %*% t(svd_res$v)
#       D0[,,i] <- X %*% R
#     }
#   }

#   # Apply EM estimation (optional)
#   if (apply_em) {
#     em_res <- tryCatch({
#       em_gaussian_estimation(D0)
#     }, error = function(e) {
#       stop("EM algorithm failed: ", e$message)
#     })
#   }

#   # Regression
#   fitt <- array(0, dim = dim(D0))
#   times <- if (is.null(To)) 1:n else To

#   for (i in 1:m) {
#     for (j in 1:k) {
#       y <- D0[j, i, ]
#       if (use_spline) {
#         fit <- smooth.spline(times, y)
#         fitt[j, i, ] <- predict(fit, times)$y
#       } else {
#         mod <- lm(y ~ poly(times, degree, raw = TRUE))
#         fitt[j, i, ] <- predict(mod)
#       }
#     }
#   }

#   # Enforce limb lengths
#   if (enforce_limb_lengths && length(joint_connections) > 0 && !is.null(lengths)) {
#     for (t in 1:n) {
#       for (j in 1:length(joint_connections)) {
#         joint <- joint_connections[[j]]
#         i1 <- joint[1] + 1  # Convert 0-based to 1-based
#         i2 <- joint[2] + 1
#         v <- fitt[, i2, t] - fitt[, i1, t]
#         len <- sqrt(sum(v^2))
#         target_len <- lengths[j]
#         if (len > 1e-6) {
#           scale <- target_len / len
#           fitt[, i2, t] <- fitt[, i1, t] + scale * v
#         }
#       }
#     }
#   }

#   return(fitt)
# }

