#library(MCMCpack)
library(shapes)
#library(Rmpfr)
#source("/home/ak96/kent/research/programms/EM/hyper_geom/recent.r")
#source("/home/fred/kent/research/programms/EM/hyper_geom/recent.r")
#source("/home/ak96/kent/research/programms/EM/hyper_geom/mainEM_3d_size_shape.r")
#source('~/kent/research/programms/EM/hyper_geom/mainEM_3d_size_shape.r')
#source("/Users/alfredkume/kent/research/programms/EM/hyper_geom/recent.r")
#source("/Users/alfredkume/kent/research/programms/EM/hyper_geom/mainEM_3d_size_shape.r")
#round=1;ii=4;jj=1;rr=2;nn=2
qrdecom<-function(X)
{
l<-qr(X)
z<-list()
z$T<-qr.R(l)
#print(det(qr.Q(l)))
z$R<-qr.Q(l)%*%diag(sign(diag(z$T)))
z$T<-diag(sign(diag(z$T)))%*%z$T
z
}

svdecom<-function(X)
{
l<-svd(X)
#l<-svd.m(X)
z<-list()
z$R<-l$u
z$d=l$d
if(det(z$R)<0)
z$d[3]=-l$d[3]
z$T<-diag(z$d)%*%t(l$v)
z
}

ref.rotationfit<-function(X,M)
#reflection here
{
#X=t(svd(X)$u)%*%X
SS<-svd(X%*%t(M))
l<-hg(SS$d^2/4)
#l<-hg(SS$d^2/4)
#z<-SS$v%*% diag(l[ 2:4])%*% t(SS$u)%*%X
z<-SS$v%*% diag(l[2:4]*SS$d/2)%*% t(SS$u)%*%X
out<-list()
out$z<-z
out$c<-1
out
}

#library(compositions)

myhg0f1rotsim.dir=function(l,n=100000)
{
#D=rDirichlet.acomp(n,alpha=c(x1=1/2,x2=1/2,x3=1/2,x4=1/4))
D=t(rdirichlet(n,c(1/2,1/2,1/2,1/2)))
R1=D[,1]+D[,4]-D[,2]-D[,3]
R2=D[,2]+D[,4]-D[,1]-D[,3] 
R3=D[,3]+D[,4]-D[,2]-D[,1] 
etr=exp(R1*l[1]+R2*l[2]+R3*l[3])
a=c(mean(etr),mean(R1*etr), mean(R2*etr),mean(R3*etr))
a=a*2/pi
#note that the haar measure here is rescaled by 2/pi
a
}
#myhg0f1rotsim.dir(1:3,3)

myhg0f1rotsim.dir.vec=function(l,n=100000,cc=sum(l))
{
#D=rDirichlet.acomp(n,alpha=c(x1=1/2,x2=1/2,x3=1/2,x4=1/4))
D=t(rdirichlet(n,c(1/2,1/2,1/2,1/2)))
M=array(-1,c(4,3))
diag(M)=abs(diag(M))
M[4,]=abs(M[4,])

ll=M%*%l
cc=max(ll)*0
ll=ll-cc
etr1=exp(D[,1]*ll[1]+D[,2]*ll[2]+D[,3]*ll[3]+D[,4]*ll[4])
etr=etr1[!is.infinite(etr1)]
D=D[!is.infinite(etr1),]
a=c(mean(etr),mean(D[,1]*etr), mean(D[,2]*etr),mean(D[,3]*etr),mean(D[,4]*etr))
a=a*2/pi
tt=ifelse(is.infinite(exp(cc)),1,exp(cc))
a=a*tt
#note that the haar measure here is rescaled by 2/pi
b=a[-5]
b[2:4]=t(M)%*%a[-1]
b
}
#source("recent.r")
#myhg0f1rotsim.dir.vec(1:3,3)

rhaarSO3=function(n=1000)
{
a<-runif(n,0,2*pi);ca<-cos(a); sa<-sin(a)
b<-runif(n,0,pi);cb<-cos(b); sb<-sin(b)
g<-runif(n,0,2*pi);cg<-cos(g); sg<-sin(g)

D<-array(0,c(3,3,n))

D[1,1,]<-ca*cb*cg-sa*sg
D[1,2,]<-ca*cb*sg-sa*cg
D[1,3,]<-ca*sb

D[2,1,]<-sa*cb*cg-ca*sg
D[2,2,]<-  sa*cb*sg- ca*cg 
D[2,3,]<-sa*sb


D[3,1,]<- sb *cg
D[3,2,]<- sb*sg
D[3,3,]<-cb

z<-list();
z$D<-D
z$sbeta<-sb
z
}

myhg0f1rotsim=function(l0,n=100000)
{
l=-l0
#d=rhaarSO3(n)
etr=1;2
prop=1
while(length(etr)<0.9*n)
{
d=rhaarSO3(round(n/prop))
etr1= exp(d$D[1,1,]*l[1]+d$D[2,2,]*l[2]+d$D[3,3,]*l[3])*d$sbeta
etr=etr1[!is.infinite(etr1)]
a=c(mean(etr),mean(d$D[1,1,!is.infinite(etr1)]*etr), mean(d$D[2,2,!is.infinite(etr1)]*etr),mean(d$D[3,3,!is.infinite(etr1)]*etr))
#note that the haar measure here is rescaled by 2/pi=exp(sin(b),b=0..pi)
prop=length(etr)/n
#print(prop)
}
a[-1]=-a[-1]
a
}
##############################
myhg0f1rotsim.gmp=function(l0,n=100000)
{
l=mpfr(-l0,30)
#d=rhaarSO3(n)
etr=1;2
prop=1
while(length(etr)<0.9*n)
{
d=rhaarSO3(round(n/prop))
etr1= exp(d$D[1,1,]*l[1]+d$D[2,2,]*l[2]+d$D[3,3,]*l[3])*d$sbeta
etr=etr1[!is.infinite(etr1)]
a=c(mean(etr),mean(d$D[1,1,!is.infinite(etr1)]*etr), mean(d$D[2,2,!is.infinite(etr1)]*etr),mean(d$D[3,3,!is.infinite(etr1)]*etr))
#note that the haar measure here is rescaled by 2/pi=exp(sin(b),b=0..pi)
prop=length(etr)/n
#print(prop)
}
rm(l,etr)
a=toNum(a)
a[-1]=-a[-1]
a
}


#myhg0f1rotsim=myhg0f1rotsim.dir.vec

svd.m=function(X)
{
SS=svd(X)

SS$d=SS$d*sign(det(SS$v%*% t(SS$u)))

SS$u=SS$u%*%diag(rep(sign(det(t(SS$u))),3))

SS$v=SS$v%*%diag(rep(sign(det(t(SS$v))),3))

#SS$u=SS$u%*%diag(rep(sign(det(SS$v%*% t(SS$u))),3))
#I am not sure about this line
SS
}

svd.m_new=function(X)
{
SS=svd(X)

SS$d=SS$d*c(1,1,sign(det(SS$v%*% t(SS$u))))

SS$u=SS$u%*%diag(c(1,1,sign(det(t(SS$u))))) 

SS$v=SS$v%*%diag(c(1,1,sign(det(t(SS$v)))))

#SS$u=SS$u%*%diag(rep(sign(det(SS$v%*% t(SS$u))),3))
#I am not sure about this line
SS
}

simple.rotationfit<-function(X,M)
#no reflection here does the simple rotation fit: z will b eteh rotated X
{
SS<-svd.m_new(X%*%t(M))
z<-SS$v%*%t(SS$u)%*%X
return(z)
}

rotationfit_old<-function(X,M,sig=1,kk=1)
#no reflection here
{
#myrotsim=myhg0f1rotsim
#myrotsim=myhg0f1rotsim.ex;kk=1
#myrotsim=myhg0f1rotsim.ex.loglik;kk=1#note if tis i sused the loglik is given in l[1]!
myrotsim=myrotsim.laplace
myrotsim=myrotsim.sadd.app
#myrotsim=myhg0f1rotsim.gmp
#myrotsim=rot.gibs.simul
#X=t(svd(X)$u)%*%X
SS<-svd.m_new(X%*%t(M)/sig^2)
#l<--(myhg0f1rot(-sign(det(SS$v%*% t(SS$u)))*SS$d))
#print(max(SS$d))
l=rep(0,4)

for (i in 1:kk)
l=l+myrotsim(c(1,1,sign(det(SS$v%*% t(SS$u))))*SS$d)

#l=l+myhg0f1rotsim(sign(det(SS$v%*% t(SS$u)))*SS$d,2000000)

#l=l+myhg0f1rotsim(SS$d,100000)
#l<-hg(SS$d^2/4)
#z<-SS$v%*% diag(l[ 2:4])%*% t(SS$u)%*%X
#l=rep(1,4)
l=l/kk;
#z<-SS$v%*%diag(l[2:4]/l[1])%*% t(SS$u)%*%X
z<-SS$v%*%diag(l[2:4])%*% t(SS$u)%*%X
#this is used only for myrotsim=myhg0f1rotsim.ex.loglik

#z<-SS$v%*%diag(l[2:4]/l[1])%*% t(SS$u)%*%X
#cat("obs",i,l,c(1,1,sign(det(SS$v%*% t(SS$u))))*SS$d,"\n")
#print(sign(det(SS$v%*% t(SS$u))))
out<-list()
out$z<-z
out$c<-1
#out$l<-l[1]/2*pi
out$l<-l[1]-log(2/pi)
# #this is used only for myrotsim=myhg0f1rotsim.ex.loglik
out
}

rotationfit<-function(X,M,sig=1,kk=0)
#updated 22/04/2015 to fit saddle point approx with  values of kk=0 and if kk=2 use the holonomic gradient function. by default use the laaplace_inversion.
{
SS<-svd.m_new(X%*%t(M)/sig^2)
l=rep(0,4)
if(kk!=0&&kk!=2)
myrotsim=myrotsim.laplace#exact laplace inversion
if (kk==2)
myrotsim=myhg0f1rotsim.ex.loglik#exact holonomic
if (kk==0)
myrotsim=myrotsim.sadd.app

#print(c(c(1,1,sign(det(SS$v%*% t(SS$u))))*SS$d,l))
l=myrotsim(c(1,1,sign(det(SS$v%*% t(SS$u))))*SS$d)
#print(c(c(1,1,sign(det(SS$v%*% t(SS$u))))*SS$d,l))
#print(l)
z<-SS$v%*%diag(l[2:4])%*% t(SS$u)%*%X
out<-list()
out$z<-z
out$c<-1
out$l<-l[1]-log(2/pi)
out
}

svd.m=svd.m_new

EMstep.size.shape<-function(DATA,Minit,sig=1,kk=1)
#DATA matrix is in preform space 
#Minit the initial mean 
#sig is the sigma parameter
#kk is the method implemented: 
#kk=2 if we use holonomic apporach very slow;kk=0 if SPA is used and otherwise the laplace #inversion
#the output is Z the mean and logl the value l=l+myhg0f1rotsim(sign(det(SS$v%*% t(SS$u)))*SS$d)
{
logl=0
D1<-DATA
ind<-1:dim(DATA)[3]
for (i in 1:dim(DATA)[3])
{
ou<-rotationfit(DATA[,,i],Minit,sig,kk)
D1[,,i]<-ou$z
#ind[i]<-norm(DATA[,,i])^2*ou$c
#cat("obs",i,log(ou$l),"\n")
#logl=logl+log(ou$l)-norm(DATA[,,i])^2/sig^2/2-norm(Minit)^2/sig^2/2-log(sig)*prod(dim(Minit))
logl=logl+ou$l-norm(DATA[,,i])^2/sig^2/2-norm(Minit)^2/sig^2/2-log(sig)*prod(dim(Minit))#used for 
#this is used only for myrotsim=myhg0f1rotsim.ex.loglik
}

Z<-apply(D1,c(1,2),mean)
#sigma2<-mean(ind)-norm(Z)^2
#cat(sigma2,mean(ind),norm(Z)^2,"\n")
#Z<-Z/sqrt(sigma2)
out=list()
out$z=Z
out$l=logl
out$rotdata=D1
out
}

#########################
###
gibs.simul.s3=function(n,l)
#l is the parameter vector of positive numbers
{
D=t(rdirichlet(1,c(1/2,1/2,1/2,1/2)))
M=array(0,c(4,n))
s=D[1:3]
for (i in 1:n)
{
w=runif(1,0,1/sqrt(1-sum(s)))
v=runif(1,0,exp(sum(-l*s)))
#cat(w,v,"\n")
av=0
bv=-log(v)
for (j in 1:3)
{
#c=max((av-sum(s[-j]*l[-j]))/l[j], 1-1/v^2-sum(s[-j]))
d=(bv-sum(s[-j]*l[-j]))/l[j]
c=max(0,1-1/w^2-sum(s[-j]))
d=min(1,(bv-sum(s[-j]*l[-j]))/l[j], 1-sum(s[-j]))
#d=min((bv-sum(s[-j]*l[-j]))/l[j],1-1/w^2-sum(s[-j]))
#cat(c,d,d-c,"\n")
s[j]=runif(1,sqrt(c),sqrt(d))^2
}
M[,i]=c(s,1-sum(s))
}
M
}


rot.gibs.simul=function(l1,n=100000)
#I am trying to perform the gibs sampling for Bingham distribution in order to calculate myhg0f1rotsim
{
l=sort(-l1,decreasing=TRUE)
psi=1:4
psi[4]=sum(l)
psi[1:3]=2*l-psi[4]
r=which(psi==min(psi))
ind=seq(1,n,by=10)
R=apply(gibs.simul.s3(n,psi[-r]-min(psi)),1,mean)
ratio=c(1-sum(R),R)
#ratio=c(R,1-sum(R))
Y=c(R[1]+R[4]-R[2]-R[3],R[2]+R[4]-R[1]-R[3],R[3]+R[4]-R[2]-R[1])
Y=c(1,Y)
Y
}

triemdist=function(X,Y)
{
Y=riemdist(t(X),t(Y))
Y
}

#############################################

EMstep.size.shape.cov2<-function(DATA,Minit,Lcov,sigc=1,kkc=3)
# Runs as in EMstep.size.shape.cov function with added covariance Lcov among the #landmarks
{
logl=0
S=invsqrtmat(Lcov)
D1<-DATA
SS=0*t(DATA[,,1])%*%DATA[,,1]
for (i in 1:dim(DATA)[3])
{
D1[,,i]=DATA[,,i]%*%S$sqrtinv
SS=t(DATA[,,i])%*%DATA[,,i]+SS
}
zz=EMstep.size.shape(D1,Minit%*%S$sqrtinv,sig=sigc,kk=kkc)

#Z<-apply(zz$rotdata,c(1,2),mean)%*%S$sqrt
Z=zz$z%*%S$sqrt

#Z=Z/norm(Z)
Lcov2<-SS/dim(DATA)[3]-t(Z)%*%Z
cat(norm(Z)^2,"\n")
#Z<-Z/sqrt(sigma2)
out=list()
out$z=Z
out$Lcov=Lcov2
out$l=zz$l-log(det(Lcov))*prod(dim(DATA))/2*0#zero here seems to work!!
out
}

#################################

EMstep.size.shape.cov1<-function(DATA,Minit,Lcov,sig=1,kk=3)
# Runs as in EMstep.size.shape.cov function with added covariance Lcov among the #landmarks
{
logl=0
D1<-DATA
ind<-1:dim(DATA)[3]
S=invsqrtmat(Lcov)
#print(S$sqrt%*%S$sqrtinv)
SS=0*t(DATA[,,1])%*%DATA[,,1]
for (i in 1:dim(DATA)[3])
{
ou<-rotationfit(DATA[,,i]%*%S$sqrtinv,Minit%*%S$sqrtinv,sig,kk)
D1[,,i]<-ou$z
#ind[i]<-norm(DATA[,,i])^2*ou$c
#cat(ind[i],ou$c,"\n")
SS=t(DATA[,,i])%*%DATA[,,i]+SS
logl=logl+log(ou$l)-norm(DATA[,,i])^2/sig^2/2-norm(Minit)^2/sig^2/2-log(sig)*m*k/2
}

Z<-apply(D1,c(1,2),mean)%*%S$sqrt
Lcov2<-SS/dim(DATA)[3]-t(Z)%*%Z
#cat(sigma2,mean(ind),norm(Z)^2,"\n")
#Z<-Z/sqrt(sigma2)
out=list()
out$z=Z
out$Lcov=S$sqrt%*%Lcov2%*%S$sqrt
out$l=logl
out
}

############
invsqrtmat=function(Sigma)
{
Y=svd(Sigma)
Z=Y$u%*%diag(sqrt(Y$d))%*%t(Y$v)
W=Y$u%*%diag(1/sqrt(Y$d))%*%t(Y$v)
list(sqrt=Z,sqrtinv=W)
}


###############################
norm=function(X)
{
Y=sqrt(sum(diag(X%*%t(X))))
Y
}

####
preformb=function(M)
#canclulates the preform of configuration M by taking the first column (landmark) to teh origin.
{
k=dim(M)[2]-1

L=diag(rep(1,k+1))
L[1,]=rep(-1,k+1)
P=M%*%L[,-1]
P
}

preshape.dist<-function(X,M, trans=0)
#no reflection here
#the function optimally rotates X configuration and then calculates the eucidean distance between preforms rotated X and M. 
{
u=X
v=M
if (trans!=0)
{
u=t(X)
v=t(M)
}

SS<-svd.m(u%*%t(v))
#l<--(myhg0f1rot(-sign(det(SS$v%*% t(SS$u)))*SS$d))
#print(max(SS$d))
#l=l+myhg0f1rotsim(sign(det(SS$v%*% t(SS$u)))*SS$d,2000000)

#l=l+myhg0f1rotsim(SS$d,100000)
#l<-hg(SS$d^2/4)
#z<-SS$v%*% diag(l[ 2:4])%*% t(SS$u)%*%X
#l=rep(1,4)
z<-SS$v%*% t(SS$u)%*%u
#print(l/l[1])
#print(sign(det(SS$v%*% t(SS$u))))
out=norm(z-v)
out
}
#source("~/kent/research/programms/Tomonari/hgd-Bingham/hgd.R")
#source("~/kent/research/programms/Tomonari/hgd-Bingham/hg.R")
#source("~/kent/research/programms/Tomonari/hgd-Bingham/pfaffian-Bingham120917.R")
#source("~/kent/research/programms/Tomonari/hgd-Bingham/hg120917.R")
#source("~/kent/research/programms/Tomonari/hgd-Bingham/hg2.R")
#source("~/kent/research/programms/Tomonari/hgd-Bingham/pfaffian-Bingham.R")
# source("HG_part.r")

myhg0f1rotsim.ex.1=function(l,n=1)
{
i=4
ss=c(2*l-sum(l),sum(l))
G=hg.Bingham(ss[-i]-ss[i],N=1e8)$G*2/pi
G1=G[1]*exp(ss[i])
#now G1=myhg0f1rotsim(l)[1]
dd=c(1-2*(G[3]+G[4])/G[1], 1-2*(G[2]+G[4])/G[1], 1-2*(G[3]+G[2])/G[1])
#the last term was originally 1-2*(G[3]+G[2])/G[1]!correct
Y=c(G1,dd*G1)
Y
}

myhg0f1rotsim.ex=function(l,n=1,log=1)
{
i=4
ss=c(2*l-sum(l),sum(l))

if(log==1)
{
b=hg.Bingham(ss[-i]-ss[i],N=1e6,logarithm=T)$G
G=c(exp(b[1]),exp(b[1])*b[-1])*2/pi
}
else
{
G=hg.Bingham(ss[-i]-ss[i],N=1e8)$G*2/pi
}
G1=ifelse(is.infinite(exp(ss[i])),1,G[1]*exp(ss[i]))
#G1=1
#now G1=myhg0f1rotsim(l)[1]
dd=c(1-2*(G[3]+G[4])/G[1], 1-2*(G[2]+G[4])/G[1], 1-2*(G[3]+G[2])/G[1])
#the last term was originally 1-2*(G[3]+G[2])/G[1]!correct
#print(paste(ss))
Y=c(G1,dd*G1)
Y
}


myhg0f1rotsim.ex.loglik=function(l,n=1,log=1)
{
i=4
ss=c(2*l-sum(l),sum(l))

if(log==1)
{
b=hg.Bingham(ss[-i]-ss[i],N=1e11,logarithm=T)$G
G=c(exp(b[1]),exp(b[1])*b[-1])*2/pi
}
else
{
G=hg.Bingham(ss[-i]-ss[i],N=1e8)$G*2/pi
}
#G1=ifelse(is.infinite(exp(ss[i])),1,G[1]*exp(ss[i]))
#this is the original line in myhg0f1rotsim.ex.loglik but I had to remove it to avoid the log function

#G1=1
#now G1=myhg0f1rotsim(l)[1]
dd=c(1-2*(G[3]+G[4])/G[1], 1-2*(G[2]+G[4])/G[1], 1-2*(G[3]+G[2])/G[1])
#the last term was originally 1-2*(G[3]+G[2])/G[1]!correct
#print(paste(ss))
Y=c(log(G[1])+ss[i],dd)
Y
}

hg.mine=function(th0, G0, th1, dG.fun, times=seq(0,1,length=101), fn.params=NULL){
  params = list(th = th0, dG.fun = dG.fun, v = th1-th0, fn.params = fn.params)
  rk.res = rk(G0, times, my.ode.hg, params,atol=1e-09, rtol=1e-09)
  list(G = rk.res[nrow(rk.res), 1+(1:length(G0))], trace = rk.res)
}

###########################
EMfunc.3d.size.shape=function(Dt=Data,preshape=FALSE,land=1,Cov="Isot",tol=1e-05,ltol=1e-05,reflection=FALSE,out="pshape",spa=0,itermax=300,Mstart="no")
#D is the data in dimension 3xkxn; if preshape is true we do not need to standartise for location;otherwise we need to remove location either applying helmertisized landmarks 
  #or taking the first landmark to 0
  #tol is the absolute tolerance of the mean convergence
  #reflection is not implemented yet
  #if preshape is false the user need to show which landmark number needs sending to zero default is land=1;if helmertrized landmarks are needed then land=""  
  #if sap=0 true the saddle poin approx (faster!!) is used otherwise sp=1 means the inverse laplace transform is used and if spa=2 the hg is used. 
#output is the list of the estimated parameters like mean, covariance as well as the optimally rotated/scaled configurations using the MLE estiations  and if out is not "pshape"the output will generated these quantities in the configuation space (excluding the covariance)also the loglikelihood value for alt meth sadpoint approx or not is also included
{

m=dim(Dt)[1]
k=dim(Dt)[2]
n=dim(Dt)[3]
D=Dt

if (preshape==TRUE)
{
Dconf=array(0,c(m,k+1,n))
for (i in 1:n)
  Dconf[,,i]=t(preshapetoicon(t(D[,,i])))
gp=procGPA(aperm(Dconf,c(2,1,3)),scale=FALSE,distances=FALSE)
rm(Dconf)
gp=list(msh=gp$msh)
#initial values are from the procrustes estimates
  M0=t(preshape(gp$msh))*sqrt(sum(as.vector(gp$msh)^2))
  Mproc=M0#assuming helmert coordinates for preshapes here  
    if (is.numeric(land)==TRUE)
   {
      x=t(gp$msh)-t(gp$msh)[,land]
   M0=x[,-land]
   Mproc=M0
    }
}
if (preshape==FALSE)
{
  Dconf=Dt
  D=array(0,c(m,k-1,n))
  gp=procGPA(aperm(Dconf,c(2,1,3)),scale=FALSE,distances=FALSE) 
  if (is.numeric(land)==TRUE)
  {
    r=land
    for (i in 1:n)
    {
      x=(Dconf[,,i])-(Dconf[,r,i])
      D[,,i]=x[,-r]
      #D[,,i]<-t(preshape(t(Dconf[,,i]))*norm(t(Dconf[,,i])))          
    }
        #initial values are from the procrustes estimates
    #gp=procGPA(aperm(Dconf,c(2,1,3)),scale=FALSE,distances=FALSE) 
    x=t(gp$msh)-t(gp$msh)[,r]
    M0=x[,-r]
        Mproc=M0
  }   
  else
  {
    print(k)
    for (i in 1:n)
    D[,,i]<-t(preshape(t(Dconf[,,i]))*centroid.size(t(Dconf[,,i])))    
  }
  #initial values are from the procrustes estimates
  M0=t(preshape(gp$msh))*centroid.size(gp$msh)
  Mproc=M0 
k=k-1#check this..
}
if (is.numeric(Mstart)==TRUE)
M0=Mstart
#this is an option to start the algorithm from a prespecified mean entry in preform space
if (Cov=="Isot")
{
SS=mean(apply(D[,,],c(3),norm)^2)
sdev=abs(SS-norm(M0)^2)/k/m
#print(sdev)
#sdev=1
#M1=M0+2
#M0=D[,,n]
#M0=M
#sdev=1;
logk0=-1e+25
times=1
d=1
loopnumber=0
#M0=D[,,1]
print(norm(M0))
while (d>tol&&loopnumber<itermax)
{
  loopnumber=loopnumber+1
  times=1
  st=EMstep.size.shape(D[,,],M0,sdev,spa)
  M1<-st$z
  #print(SS)
  M1=simple.rotationfit(M1,Mproc)
  d<-norm(M1-M0)
  logk=st$l
 # print(st)
  sigma2<-(SS-norm(M1)^2)/k/m
  
  cat("dmean",d,"sig=",sigma2, "ll=",logk, "difl=",logk-logk0,".","iter=",loopnumber,svd(M0)$d,"\n")
  #cat(d, riemdist(-(preshapetoicon(t(Mproc))),(preshapetoicon(t(M0)))),riemdist((preshapetoicon(t(M1))),(preshapetoicon(t(M0)))),"sig=",sigma2, "ll=",logk, "difl=",logk-logk0,".",svd(M0)$d,"\n")
 sdev=sqrt(sigma2)
  if(abs(logk-logk0)>0)
  {
    logk0=logk
    M0<-M1
    times=1
  }
  else
  {
    M0<-M1
    print(paste("no improvement",logk-logk0, times,loopnumber))
    loopnumber=itermax
    }
 }
 altloglik=logk+EMstep.size.shape(D[,,],M0,sdev,spa+1*0)$l-EMstep.size.shape(D[,,],M0,sdev,spa)$l
z=list(mean.mle=M1, sdev.mle=sdev,rot.data=st$rotdata, numb=loopnumber, liklog=logk,liklogalt=altloglik)
}

if (Cov=="Diag")
{
  SS=0*t(D[,,1])%*%D[,,1]
  for (i in 1:n)
    SS=t(D[,,i])%*%D[,,i]+SS
  
  SS=SS/n
logk0=-1e+5
times=1
C0=diag(rep(1,dim(M0)[2]))
  #C0<-diag(diag(SS-t(M0)%*%M0))
C1=C0
d=1
d1=1
  difl=1
  loopnumber=1
while ((d+d1)/2>tol|difl>ltol&&loopnumber<itermax)   
#while ((d+d1)>tol)
{
  times=1
  loopnumber=loopnumber+1
#  st=EMstep.size.shape.cov2(D[,,],M0,C0,1,times) # if we apply this note that the last correction likelihood term is zero see function there
  st=EMstep.size.shape(D[,,],M0%*%solve(C0),1,kk=spa)
  M1<-st$z
  M1=simple.rotationfit(M1,Mproc)
  C1<-diag(diag(SS-t(M1)%*%M1))
  logk=st$l
  print(det(C0))
    Correction=(sum(diag(M0%*%solve(C0)%*%t(M0)))-norm(M0%*%solve(C0))^2) 
  logk=st$l-n/2*Correction
  #above we need to correct for the norm of mu*solve(C0)
  for (i in 1:n)
    logk=logk+norm(D[,,i])^2/2-sum(diag(D[,,i]%*%solve(C0)%*%t(D[,,i])))/2

  d<-norm(M1-M0)
  d1=norm(C1-C0)
  difl=logk-logk0
  sigma2=norm(C1)
  cat("dmean=",d,"dCov=",d1,"ll=",logk, "difl=",difl,".","iter=",loopnumber,svd(M0)$d,"\n")
#  cat(d,riemdist(t(cbind(rep(0,3),M)),t(cbind(rep(0,3),M0))),riemdist(t(cbind(rep(0,3),M)),t(cbind(rep(0,3),M1))),"sig=",sigma2, "ll=",logk, "difl=",logk-logk0,".",svd(M0)$d,range(svd(C1)$d),"\n")
  
  if(abs(logk-logk0)>ltol)
  {
    logk0=logk
    M0<-M1
    C0=C1
    sdev=sqrt(sigma2)
    times=1
  }
  else
  {
    M0<-M1
    C0=C1
    sdev=sqrt(sigma2)
    print(paste("no improvement",(logk-logk0), times))
    logk0=logk
  }
}
altloglik=logk+EMstep.size.shape(D[,,],M0,sdev,spa-1)$l-EMstep.size.shape(D[,,],M0,sdev,spa)$l
  z=list(mean.mle=M1, cov.mle=C1,rot.data=st$rotdata,numb=loopnumber, liklog=logk,liklogalt=altloglik)
}
if (Cov=="Gen")
{  
  SS=0*t(D[,,1])%*%D[,,1]
  for (i in 1:n)
    SS=t(D[,,i])%*%D[,,i]+SS
  SS=SS/n 
  logk0=-1e+15
  times=1
 C0=diag(rep(1,,dim(M0)[2]))
  #C0<-SS-t(M0)%*%M0
  C1=C0
  d=1
  d1=1
  difl=1
  loopnumber=1
  while ((d+d1)/2>tol|difl>ltol&&loopnumber<itermax)
  {
    times=1
    loopnumber=loopnumber+1
#   st=EMstep.size.shape.cov2(D[,,],M0,C0,1,times)
#     invcov=invsqrtmat(C0)
#     M1<-st$z
#     C1<-SS-t(M1)%*%M1
#     
#     logk=st$l
#     
    print(det(C0))
    st=EMstep.size.shape(D[,,],M0%*%solve(C0),1,kk=spa)
    M1<-st$z
    M1=simple.rotationfit(M1,Mproc)
    C1<-SS-t(M1)%*%M1
    logk=st$l
    
    Correction= (sum(diag(M0%*%solve(C0)%*%t(M0)))-norm(M0%*%solve(C0))^2)
    #logk=st$l-log(det(C0))*prod(dim(D))/2-n/2*Correction
    logk=st$l-n/2*Correction
    #above we need to correct for the norm of mu*solve(C0)
    #   
    for (i in 1:n)
      logk=logk+norm(D[,,i])^2/2-sum(diag(D[,,i]%*%solve(C0)%*%t(D[,,i])))/2

    d<-norm(M1-M0)
    d1=norm(C1-C0)
    difl=logk-logk0
#       st=EMstep.size.shape(D[,,],M0%*%solve(C0),1,times) #this is correct for general covariance mean but does not give the correct likelihood
    d<-norm(M1-M0)
    d1=norm(C1-C0)

    sigma2=norm(C1)
    cat("dmean=",d,"dCov=",d1,"ll=",logk, "difl=",difl,".","iter=",loopnumber,svd(M0)$d,"\n")   
    #  cat(d,riemdist(t(cbind(rep(0,3),M)),t(cbind(rep(0,3),M0))),riemdist(t(cbind(rep(0,3),M)),t(cbind(rep(0,3),M1))),"sig=",sigma2, "ll=",logk, "difl=",logk-logk0,".",svd(M0)$d,range(svd(C1)$d),"\n")   
    if((logk-logk0)>ltol)
    {
      logk0=logk
      M0<-M1
      C0=C1
      sdev=sqrt(sigma2)
      times=1
      #M00=M1
    }
    else
    {
      M0<-M1
      C0=C1
      sdev=sqrt(sigma2)
      print(paste("no improvement, hitting the predefined numerical error",logk-logk0, times))
      logk0=logk
      break;
    }
  }
altloglik=logk+EMstep.size.shape(D[,,],M0,sdev,spa-1)$l-EMstep.size.shape(D[,,],M0,sdev,spa)$l
  z=list(mean.mle=M1, cov.mle=C1,rot.data=st$rotdata,numb=loopnumber, liklog=logk,liklogalt=altloglik)
}

if (out!="pshape")
   {
   Dconf=array(0,c(dim(z$rot)[1],dim(z$rot)[2]+1,dim(z$rot)[3]))
   MLE.Mean.conf=Dconf[,,1]
if (is.numeric(land)==TRUE)
{
  Dconf[,-land,]=z$rot
  MLE.Mean.conf[,-land]=z$mean.mle
}  
   else
  {
   for (i in 1:n)
     Dconf[,,i]=t(preshapetoicon(t(z$rot[,,i])))
   MLE.Mean.conf=t(preshapetoicon(t(z$mean.mle)))
  } 
      z$mconf=MLE.Mean.conf
   z$confs=Dconf
   }

return(z)
}


show=0
if(show==1)
{
  #Example
  library(shapes)
  data(macm.dat)
  gMale=EMfunc.3d.size.shape(aperm(macm.dat,c(2,1,3)),spa=0,preshape = F,land="",out="conf")
  shapes3d(t(gMale$mconf),color = 3)
  shapes3d(aperm(gMale$confs,c(2,1,3)),rglopen=F)
  out<-procGPA(macm.dat,scale=F)
  shapes3d(out$rotated,rglopen=F)
  shapes3d(aperm(gMale$confs,c(2,1,3)),color = 3,rglopen = F)
  
}
#a=EMfunc.isot.cov(D=D[,,1:30],Cov="Gen")

#a=EMfunc.isot.cov(D=D[,,1:3])

sdandard.errors=function(z)
  #calculates the empirical standard erorrs of the mle estimates. The input is the list as output from EMfunc.3d.size.shape.
  #for isotropic variance first
{
 A=z$rot 
 M=z$msh
 sig=z$sig
D=array(0,c(length(as.vector(M))+1,dim(A)[3]))  
for (i in 1:dim(A)[3])
{
x=as.vector(A[,,i]-M)/sig^2
x=c(x,norm(x)/2-prod(dim(M))/2/sig^2)
D=D+x%*%t(x)
}
sderr=diag(solve(D))
sderr
}

##############
#####Linear Regression in R^3#####
##############
EM.poly.fit.cov.3d=function(Draw,To=1:dim(Draw)[3],A="",sigmainit="",tol=1e-5,niter=200,deg=1,spa=0)
  #Draw data in  matrix of dimension mxkxnxl (preforms!) where k-landmarks in m-space, n-knots and l-paths
  #spa=0 is the SPA inversion by default, laplace if 1 and hg if 2
  #the original data are in the configuration space
  #A is the initial matrix of the linear predictor in the form of cbind-ed A_i #if A="" then the first obs is chosen as intercept and the others 0
  #C is the initial landmark-covariance structure assumed TOCHANGE
  # To- is the vector of time observations of length n
  #deg is degrees of the polynomial
  #out is the output the standard one is just the converged/updated value of A and C
  #TOCHANGE?
  #if out is 2 the output is the likelihood valueTOCHANGE
{  
 d=dim(Draw)
 D=Draw
  if(length(d)==3)
{ 
D=array(0,c(d,2)) 
D[,,,1]=Draw
D[,,,2]=Draw
  }
  d<-dim(D);d[2]<-d[2]-1; 
  #C=diag(rep(1,d[2]))
  #A=array(1,c(d[1],d[2]*(1+deg)))  
  D0<-array(0,d)
  for(i in 1:d[3])
    for(j in 1:d[4])
      D0[,,i,j]<-D[,,i,j]%*%t(defh(d[2]))
 #working with Helmertized landmarks 
  TM=rep(1,length(To))
  Ik=diag(rep(1,d[2]));
  Im=diag(rep(1,d[1]));
  for (i in 1:deg)
    TM<-cbind(TM,To^i)
  if(is.numeric(A)==FALSE)
{ 
  A<-array(0,c(d[1],d[2]*(deg+1)))
  A[,1:d[2]]=D0[,,1,1]
  }
  
  B1<-kronecker(solve(t(TM)%*%TM),Ik)
  Aorig<-A   
  SS=norm(as.vector(D0))^2
  sig=1
signew=1.1
if(is.numeric(sigmainit)==TRUE)
signew=sigmainit
  A0<-array(0,c(d[1],d[2]*(deg+1)))
   loglnew=0
  l=0
  while(norm(A-Aorig)+norm(sig-signew)>tol &l<niter)
  {
    l=l+1
    sig=signew;
    Aorig=A; 
    A0=A*0;
    logl=loglnew
    loglnew=0
    for (i in 1:d[3])
      for(j in 1:d[4])
      {
        Minit=Aorig%*%kronecker(TM[i,],Ik)
        IT=rotationfit(D0[,,i,j], Minit, sig,spa)
        #to replace the conditional expectaion here 26/05/15
        A0<-A0+IT$z%*%t(kronecker(TM[i,],Ik))
        #C=C+IT$C+IT$M%*%st(IT$M)
        loglnew=loglnew+IT$l-norm(D0[,,i,j])^2/sig^2/2-norm(Minit)^2/sig^2/2-log(sig)*prod(dim(Minit))
        #used for #this is used only for myrotsim=myhg0f1rotsim.ex.loglik 
      }
    A<-A0%*%B1/d[4]      
     signew=SS-d[4]*sum(diag(A%*%kronecker(t(TM)%*%TM,Ik)%*%t(A)))
    #signew=signew/d[1]/d[2]
    signew=sqrt(signew/prod(d))
    #signew=1
    print(c(logl,round(c(norm(A-Aorig),loglnew-logl,signew),5),"iter=",l))
  }
Imrot=Im
Imrot[d[1],d[1]]=Im[d[1],d[1]]*det(qr.Q(qr(A)));
A=Imrot%*%qr.R(qr(A))
ans=list(A=A,sigma=signew, loglik=logl) 

d[2]=d[2]+1
Dout=array(0,d)
Drot=D
for (i in 1:d[3])
  for (j in 1:d[4])
  {
  Dout[,,i,j]=(A%*%kronecker(TM[i,],Ik))%*%(defh(d[2]-1)) 
  Dout[,,i,j]=Dout[,,i,j]-Dout[,1,i,j]
  Imrot=Im
  Imrot[d[1],d[1]]=Im[d[1],d[1]]*det(qr.Q(qr(Dout[,-1,i,j])));
  rr=diag(qr.R(qr(Dout[,-1,i,j]))[1:d[1],1:d[1]])
  Dout[,-1,i,j]=Imrot%*%diag(sign(rr))%*%qr.R(qr(Dout[,-1,i,j])) 
  Drot[,,i,j]=D[,,i,j]
  Drot[,,i,j]=Drot[,,i,j]-Drot[,1,i,j]
  Imrot=Im
  Imrot[d[1],d[1]]=Im[d[1],d[1]]*det(qr.Q(qr(Drot[,-1,i,j])));
  rr=diag(qr.R(qr(Drot[,-1,i,j]))[1:d[1],1:d[1]])
  Drot[,-1,i,j]=Imrot%*%diag(sign(rr)) %*%qr.R(qr(Drot[,-1,i,j]))   
  }
ans$fitt=Dout
ans$rot=Drot
return(ans)
} 

show=0#example in shape regression
if(show==1)
{
  #Using regression in 3D
  M=diag(1:3)
  n=30
  l=5
  A1=diag(c(5,3,1))+2#Slope
  D=array(0,c(4,3,n,l))#Simulated data
  for (i in 1:n)
    for (j in 1:l)
  {
    temp=M+A1*i+array(rnorm(9,sd=1),c(3,3))
    D[,,i,j]=preshapetoicon(t(temp))+1
  }
  tD=aperm(D,c(2,1,3,4))
  S1=EM.poly.fit.cov.3d(tD,To=(1:n))#fitting simple regression
  shapes3d(aperm(S1$f[,,,1],c(2,1,3)),col=2)#plot the fitted data
  for (i in 1:l)
 shapes3d(aperm(S1$r[,,,i],c(2,1,3)),color=1,rglopen=FALSE)#plot the QR coordinates data with: landmark 1 at 0 and 2 and 3 moving on a plane 
  
}


EM_polyreg_plot3d=function(D,T,A, type=2,l1=1,l2=2,l3=3,lp=1:(dim(D)[1]), tit="",colo="red",typ="new",obs=1,linetype=2)
  #This generates the plots of observed shapes and fitted ones in terms of 
 #the helmertized (type=1) or (type=2) 3d-Bookstein(Bartlet) coordinates
  # D, T, A is the data as in EM.poly.fit
  #l1,l2,l3, are the landmarks which need to be normalized 
  #via QR transformation
  #lp the landmarks to show
  #typ="over" plot the current plot onto the previos one 
  #colo is the colour of the fitted path
  #obs =1 plots the observations else not
{
  d<-dim(D);d[2]<-d[2]-1
  deg=dim(A)[2]/(dim(D)[2]-1)-1
  TM=rep(1,length(T))
  for (i in 1:deg)
    TM<-cbind(TM,T^i)
  
  Ik=diag(rep(1,d[2]));
  Im=diag(rep(1,d[1]));
  
  D0<-array(0,d)
  for(j in 1:d[4])
  for(i in 1:d[3])
  {
    D0[,,i,j]<-D[,,i,j]%*%t(defh(d[2]))
  }  
  DP<-D0#will be the fitted values
  Dfit<-D#will be the fitted values
  Dobs=D
  for (i in 1:d[3])
    for (j in 1:d[4])
    {
      DP[,,i,j]<-A%*%kronecker(TM[i,],Ik)
      Dfit[,,i,j]=DP[,,i,j]%*%(defh(d[2]))
      Imrot=Im
      Imrot[d[1],d[1]]=Im[d[1],d[1]]*det(qr.Q(qr(Dfit[,,i,j])));
      Dfit[,,i,j]=Imrot%*%qr.R(qr(Dfit[,,i,j]))            
      Imrot=Im
      Imrot[d[1],d[1]]=Im[d[1],d[1]]*det(qr.Q(qr(Dobs[,,i,j])));
      Dobs[,,i,j]=Imrot%*%qr.R(qr(Dobs[,,i,j]))            
    }  
  z=list()
  if(type==1)
  {
    par(mfrow=c(1,2))
    plot(t(DP[1:2,1,1]),pch=".",xlab="",ylab="",main=tit)
    lines(t(DP[2:3,,1,1]),col="blue",lwd=3)

    for (j in 1:d[4])
      for (i in 1:d[3])
      {
        lines(t(DP[,,i,j]),col="red",lwd=3)
        lines(t(Dobs[,,i,j]),lt=3)
      }
    
    for (tm in 1:d[1])
    {
      #plot(DP[,ind,], type="b")
      for (j in 1:d[3])
        points(D0[,tm,j],pch=".")
    }
    z$data=D0
    z$fitted=DP
    
  }
  
  
  #dev.print(file="rats_plot.ps",horizontal=FALSE)
  #pdf(file="rats_plot.pdf",horizontal=FALSE)
  #############################################################
  #########Bookstein coordinates########
  if(type==2)
  { 
    DPB<-DP
    D0B<-D0
    L=cbind(rep(-1,d[1]), diag(rep(1,d[1])))
    for (j in 1:d[3])
      for (i in 1:d[2])
      {
        v=realtocomplex(preshapetoicon(complextoreal(DP[,i,j])))
        v=v-v[l2]
        v=v/v[l1]
        DPB[,i,j]=v[-l2]
        
        #DPB[,i,j]<-L%*%realtocomplex(preshapetoicon(complextoreal(DP[,i,j])))
        #DPB[,i,j]<-DPB[,i,j]/DPB[1,i,j]
        
        v=realtocomplex(preshapetoicon(complextoreal(D0[,i,j])))
        v=v-v[l2]
        v=v/v[l1]
        D0B[,i,j]=v[-l2]
        
        #D0B[,i,j]<-L%*%realtocomplex(preshapetoicon(complextoreal(D0[,i,j])))
        #D0B[,i,j]<-D0B[,i,j]/D0B[1,i,j]
      }
    if(typ!="over")
    {
      plot(DPB[,,1],pch=".",xlab="",ylab="",main=tit)
    }
    #plot(DPB[,,1],pch=".",xlab="",ylab="",xlim=c(-.5,.5),ylim=c(.5,1.5))
    
    
    for (ind in 1:d[3])
    {
      for (i in 1:d[1])
      {
        lines(DPB[i,,1],col=colo,lwd=1,lty=linetype)
        #a=c(Re(DPB[i,d[2]-1,1]),Im(DPB[i,d[2]-1,1]))
        #b=c(Re(DPB[i,d[2],1]),Im(DPB[i,d[2],1]))
        #arrows(a[1],a[2],b[1],b[2])
        points(DPB[i,1,1],col=colo,lwd=1,cex=.6)
        if(obs==1)
        {
          lines(D0B[i,,ind])
          lines(D0B[i,,ind],lt=1,col=terrain.colors(d[1])[i])
          points(D0B[i,,ind],pch=ind,cex=.2)
        }
      }
      points(c(0,1),c(0,0),col=colo,cex=.4,pch=19)
      
      #readline()
    }
    z$data=DPB
    z$fitted=D0B    
  }
  z
}


################################
###Some lines to implement the saddle point approximation here###
###################################
SPAline=1
if (SPAline==1)
{  
myrotsim.sadd.app=function(l)
  #this function approximates myrotsim.laplace
{
  i=4
  ss=c(2*l-sum(l),sum(l))
  Lhg=ss[-i]-ss[i]
  L=c(0,-Lhg)
  nn=length(L)
  v=(2*pi^(nn/2)/gamma(nn/2))
  #Deriv.lap.inv(L)
  #hg.Bingham(Lhg,N=1e11,logarithm=F)$G*v*2/pi
  nc=saddleaprox.FB.revised(sort(L)+1,dub=1,order=3)*exp(1)
  a=rep(0,length(L))
  for (i in 2:length(L))
  {
    l1=c(L,L[i],L[i]);
    a[i]=saddleaprox.FB.revised(sort(l1)+1,dub=1,order=3)*exp(1)/2/pi 
  }
  G=c(nc,a[-1])/v*2/pi
  #G=c(integlpinv(L), -Deriv.lap.inv(L)[-1])/v*2/pi
  
  dd=c(1-2*(G[3]+G[4])/G[1], 1-2*(G[2]+G[4])/G[1], 1-2*(G[3]+G[2])/G[1])
  #the last term was originally 1-2*(G[3]+G[2])/G[1]!correct
  #print(paste(ss))
  Y=c(log(G[1])+ss[i],dd)
  Y
}
#######
saddleaprox.FB.revised<-function(L,M=L*0,dub=3, order=3)
  #calculates the normalising constant of Bingham distribution in pre-shape space there are three methods as described by Andy
  #L is the vector of positive values
  #M is the vecor of mu<-i's
  #dub is the number at which each entry of L is doubled
{
  #L<-sort(rep(t(L),dub))
  L<-rep(t(L),dub)
  a<-prod(L/pi)^(-1/2)
  Y<-0
  
  KM<-function(t)
  {
    #Y<-sum(-1/2*log(1-t/L)+L*M^2/(1-t/L)-1*L*M^2)
    Y<-sum(-1/2*log(1-t/L)+M^2/(1-t/L)/L)
    Y
  }
  KM1<-function(t)
  {
    Y<-sum(1/2*1/(L-t)+M^2/(L-t)^2)
    Y
  }
  KM2<-function(t)
  {
    Y<-sum(1/2*1/(L-t)^2+2*M^2/(L-t)^3)
    Y
  }
  KM3<-function(t)
  {
    Y<-sum(1/(L-t)^3+6*M^2/(L-t)^4)
    Y
  }
  KM4<-function(t)
  {
    Y<-sum(3/(L-t)^4+24*M^2/(L-t)^5)
    Y
  }
  sol<-function(KM1,y)
  {
    #Y<-optimize(loc<-function(t) {abs(KM1(t)-1)},c(min(L)-length(L)/(2*y)-.Machine$double.eps^1,min(L)), tol = .Machine$double.eps^2)$min
    Y<-optimize(loc<-function(t) {abs(KM1(t)-1)},c(min(L)-length(L)/(4*y)-sqrt(length(L)^2/4+length(L)*max(L)^2*max(M)^2),min(L)), tol = .Machine$double.eps^2)$min
    Y
  }
  ##
  that<-sol(KM1,1)
  #cat("that=",that,exp(KM(that))*a,KM2(that));
  Y<-2*a/sqrt(2*pi*KM2(that))*exp(KM(that)-that)
  #Y<-2*a/sqrt(2*pi*KM2(that))*exp(KM(that)-that)*exp(sum(L*M))
  #Y<-1/sqrt(2*pi*KM2(that))*exp(KM(that)-that)
  if (order==3)
  {
    rho3sq<-KM3(that)^2/KM2(that)^3
    rho4<-KM4(that)/KM2(that)^(4/2)
    Rhat<-3/24 *rho4-5/24*rho3sq
    Y<-Y*exp(Rhat)
  }
  if (order==2)
  {
    rho3sq<-KM3(that)^2/KM2(that)^3
    rho4<-KM4(that)/KM2(that)^(4/2)
    Rhat<-3/24 *rho4-5/24*rho3sq
    Y<-Y*(1+Rhat)
  }
  Y
}

}
###############################
###End of lines to implement the saddle point approximation here###
###################################
###################Laplace inversion#######
##################################################
LAPinv=1
if (LAPinv==1)
{
  Part=function(L,i,t)
  #the function which needs integrating in the segment -l_2i,-l_(2i-1)
{
  ind1=2*(i-1)+1
  ind2=2*(i-1)+2	
  l1=L[ind1]	
  l2=L[ind2]
  u=l2-l1
  beta=L[-c(ind1,ind2)]-l2
  bb=beta+t*u
  Y=exp(-l2+t*u)/prod(bb)^.5/(t*(1-t))^.5
  Y
}

Partinf=function(L,t)
{
  ind1=L[length(L)]
  #Y=exp(t)/prod(abs(L+t))^0.5		
  Y=2*exp(-ind1)*exp(-t^2)/prod(ind1-L[-length(L)]+t^2)^.5
  Y
}

# f=function(x) {return(Partinf(L,x))}
# f=Vectorize(f)
# integrate(f,0,Inf)$v

Part1=function(L,i,t)
  #the function which needs integrating in the segment -l_2i,-l_(2i-1)
  #after a square transfomation
{
  ind1=2*(i-1)+1
  ind2=2*(i-1)+2	
  l1=L[ind1]	
  l2=L[ind2]
  u=l2-l1
  beta=L[-c(ind1,ind2)]-l2
  bb=beta+t*u
  Y=exp(-l2+t*u)/prod(bb)^.5
  #stab=-l2+t*u-0.5*sum(log(abs(bb)));Y=exp(stab)
  Y
}

Partlast=function(L,i,v)
{
  Y=Part1(L,i,v^2)+Part1(L,i,1-v^2)
  Y=2*Y*1/sqrt(1-v^2)
  Y	
}

integlpinv=function(L)
  #for even p
{
  Y=0
  p1=floor(length(L)/2)
  for (i in 1:p1)
  {
    f=function(x) {return(Partlast(L,i,x))}
    f=Vectorize(f)
    #integrate(f,0,1/sqrt(2))$v
    Y=(-1)^(i+1)*integrate(f,0,1/sqrt(2))$v+Y
  }
  #f=function(x) {return(Part(L,1,x))}
  
  if((length(L)-2*p1)>0)
  {
    f1=function(x) {return(Partinf(L,x))}
    f1=Vectorize(f1)
    Y=Y+(-1)^p1*integrate(f1,0,Inf)$v	
  }
  Y=Y*2*pi^(length(L)/2-1)
  Y
}
# r=.2
# L=c(0,0,r,r,2*r,2*r); (1-exp(-r))/r*pi
# integmine(L)

# kentnormcons(-c(0,r,2*r))

# AL=c(1,3,5)

# kentnormcons(-AL)

# L=sort(c(AL,AL))

# integmine(L)# the same as kentnormscons

#Another test
# L=0:3; L[4]=L[4]+1
# L=c(0,100,200,300)
# L=(0:5)/10

# nn=length(L)
# v=(2*pi^(nn/2)/gamma(nn/2))

# hg.Bingham(-L[-1])$G[1]*v

# integlpinv(L)
#########Multiplicities######
###########I will deal with only derivatives here i.e mltiplicities are in triples.
############
integ01=function(fun,mi=0,ma=1)
  #function integrates int f /sqrt(x(1-x)) in 0--1
{
  ff=function(x)
  {
    Y=fun(x^2)+fun(1-x^2)	
    Y=2*Y/sqrt(1-x^2)	
    Y
  }	
  fvec=Vectorize(ff)
  Y=integrate(fvec,0,1/sqrt(2))$v
  Y	
}

integ02=function(fun,mi=0,ma=1)
  #function integrates int f *sqrt(x/(1-x)) in 0--1
{
  ff=function(x)
  {
    Y=fun(x^2)
    Y=2*Y*sqrt(1-x^2)	
    Y
  }	
  fvec=Vectorize(ff)
  Y=integrate(fvec,0,1)$v
  Y	
}
########
Partial=function(L,i,j)
  #finds the partial derivative partial/partial lj for the C_i integral component
{
  ind1=2*(i-1)+1
  ind2=2*(i-1)+2	
  l1=L[ind1]	
  l2=L[ind2]
  u=l2-l1
  
  A=function(t)
  {
    beta=L[-c(ind1,ind2)]-l2
    bb=beta+t*u
    Y=exp(-l2+t*u)/prod(bb)^.5	
    Y
  }
  
  Ai=function(t,r)
  {
    Y=A(t)/(L[r]-L[ind2]+t*u)
    Y
  }
  
  Bi=function(t)	
  {
    ind=1:length(L)
    ll=ind[-c(ind1,ind2)]
    Y=0
    for (k in ll)	
      Y=Y+Ai(t,k)
    Y=Y/2-A(t)
    Y
  }
  
  Ci=function(t)
  {
    Y=Bi(1-t)	
    Y	
  }	
  if(j!=ind2 &&j!=ind1)
  {
    ff=function(x) Ai(x,j)
    Y=-1/2*integ01(ff,0,1)
    
  }
  if(j==ind1)
    Y=integ02(Ci,0,1)
  if(j==ind2)
    Y=integ02(Bi,0,1)	
  
  Y	
}


Deriv.lap.inv=function(L)
{
  Y=1:length(L)
  for (j in 1:length(L))
  {
    S=0
    for (i in 1:floor(length(L)/2))
      S=S+(-1)^(i+1)*Partial(L,i,j)
    
    Y[j]=S
  }
  Y=Y*2*pi^(length(L)/2-1)
  Y
}
#h=1e-5;(integlpinv2(L)-integlpinv2(L+c(0,0,0,h)))/-h

#Deriv.lap.inv(L)*2*pi^(length(L)/2-1)

#Partial(L,1,2)

#############
Part01=function(L,i,t)
  #the function which needs integrating in the segment -l_2i,-l_(2i-1)
{
  ind1=2*(i-1)+1
  ind2=2*(i-1)+2	
  l1=L[ind1]	
  l2=L[ind2]
  u=l2-l1
  beta=L[-c(ind1,ind2)]-l2
  bb=beta+t*u
  Y=exp(-l2+t*u)/prod(bb)^.5
  Y
}

integlpinv2=function(L)
{
  p1=floor(length(L)/2)	
  S=0
  for (i in 1:(length(L)/2))
  {
    ff=function(x) Part01(L,i,x)
    S=S+(-1)^(i+1)*integ01(ff)
  }
  Y=S
  if((length(L)-2*p1)>0)
  {
    f1=function(x) {return(Partinf(L,x))}
    f1=Vectorize(f1)
    Y=Y+(-1)^p1*integrate(f1,0,Inf)$v	
  }
  Y=Y*2*pi^(length(L)/2-1)
  Y
}

###The function which corresponds to that of the myhg0f1rotsim.ex.loglik for the EM in 3-d###
# l=c(201601.35, 78864.63, 19104.05)

# l=3:1


myrotsim.laplace=function(l)
{
  #likelihood here is log(integlpinv(sort(-c(2*l,2*sum(l))))-sum(l)-log(pi^3)=myrotsim.laplace(l)[1]
  i=4
  ss=c(2*l-sum(l),sum(l))
  Lhg=ss[-i]-ss[i]
  L=c(0,-Lhg)
  nn=length(L)
  v=(2*pi^(nn/2)/gamma(nn/2))
  
  #Deriv.lap.inv(L)
  
  #hg.Bingham(Lhg,N=1e11,logarithm=F)$G*v*2/pi
  
  G=c(integlpinv(L), -Deriv.lap.inv(L)[-1])/v*2/pi
  
  #hg.Bingham(Lhg)$G*v
  
  dd=c(1-2*(G[3]+G[4])/G[1], 1-2*(G[2]+G[4])/G[1], 1-2*(G[3]+G[2])/G[1])
  #the last term was originally 1-2*(G[3]+G[2])/G[1]!correct
  #print(paste(ss))
  Y=c(log(G[1])+ss[i],dd)
  Y
}

# l=3:1
# myrotsim.laplace(l)

# myhg0f1rotsim.ex.loglik(l)

}
#end op lpinv lines here
####################################################################
###############################
#############################################################################################################################################################################adding hgm code here####################################################################
addhgm=1
if(addhgm==1)
{

library(deSolve)

### ODE
my.ode.hg = function(tau, G, params){
  th = params$th
  dG.fun = params$dG.fun
  v = params$v
  fn.params = params$fn.params
  th = th + tau * v
  if(is.null(fn.params))  dG = dG.fun(th, G)
  else dG = dG.fun(th, G, fn.params)
  G.rhs = v %*% dG
  list(G.rhs)
}

### hg main
hg = function(th0, G0, th1, dG.fun, times=seq(0,1,length=101), fn.params=NULL){
  params = list(th = th0, dG.fun = dG.fun, v = th1-th0, fn.params = fn.params)
  #rk.res = rk(G0, times, my.ode.hg, params)
  #rk.res = rk(G0, times, my.ode.hg, params,rtol=1e-9,atol=1e-09,method="ode45")# ammended by AK
  rk.res = rk(G0, times, my.ode.hg, params,rtol=1e-9,atol=1e-09)# ammended by AK
  list(G = rk.res[nrow(rk.res), 1+(1:length(G0))], trace = rk.res)
}

# EOF

### Pfaffian for Bingham distribution
dG.fun.Bingham = function(th, G, fn.params=list(d=rep(1,length(th)+1), logarithm=FALSE)){
  d = fn.params$d
  logarithm = fn.params$logarithm
  thn = length(th)  # length(G) should be equal to (thn + 1) = p
  Gn = length(G)
  G.res = G[1] - sum(G[1+(1:thn)])
  if(logarithm) G.res = 1 - sum(G[1+(1:thn)])
  dG = array(0,c(thn, Gn))
  dG[1:thn,1] = G[1+(1:thn)]
  for(i in 1:thn){
    dG[i, 1+i] = G[1+i]
    for(j in 1:thn){
      if(j != i){
        dG[i,1+j] = (d[j] * G[1+i] - d[i] * G[1+j]) / 2 / (th[i] - th[j])
        dG[i,1+i] = dG[i,1+i] - dG[i,1+j]
      }
    }
    dG[i,1+i] = dG[i,1+i] - (d[thn+1] * G[1+i] - d[i] * G.res) / 2 / th[i]
  }
  if(logarithm){
    arg = 1:thn
    dG[arg, 1+arg] = dG[arg, 1+arg] - outer(G[1+arg], G[1+arg])
  }
  dG
}

### A vector representing multiplicity
Expand.matrix = function(d){
  dn = length(d)
  A = matrix(0, dn, sum(d))
  dd = c(0, cumsum(d))
  for(i in 1:dn){
    A[i, (dd[i]+1):dd[i+1]] = 1
  }
  A
}

### Normalising constant and its derivatives (by power series expansion)
C.Bingham.power = function(th.all, v=rep(0,length(th.all)), d=rep(1,length(th.all)), Ctol=1e-9, thtol=1e-10){
  th = th.all
  A = Expand.matrix(d)
  p = length(th)  # not (p-1)
  dsum = sum(d)  # at least p
  maxth = max(abs(th))
  if(maxth >= 10) stop("too large value th.")
  N = ceiling( (lfactorial(10) - 10*log(10) + log(Ctol)) / (log(maxth)-log(10)) )  # e.g. N=10 if maxth=1
  N = max(N, 5)
  f = function(N, th, k, v, A, dsum){
    kn = length(k)
    if(kn == dsum){
      e = A %*% k
      if(any(e-v < 0)) return( 0 )
      w = which(e-v > 0)
      a = prod( th[w]^(e[w]-v[w]) )
      b1 = sum( - lfactorial(k) + lgamma(k+1/2) )
      b2 = sum( lfactorial(e) - lfactorial(e - v) )
      b3 = - lgamma(sum(k)+dsum/2) + lgamma(dsum/2) - lgamma(1/2)*dsum
      return( a * exp(b1+b2+b3) )
    }else{ # recursive part
      knxt = kn + 1
      if(abs(th[which(A[,knxt]>0)]) < thtol){  # speed-up
        return( f(N, th, c(k,0), v, A, dsum) )
      }else{
        a = 0
        for(i in 0:N){
          a = a + f(N, th, c(k,i), v, A, dsum)
        }
        return(a)
      }
    }
  }
  f(N, th, c(), v, A, dsum)
}

### Normalising constant and its derivatives (by Monte Carlo)
rsphere = function(N, p){
  x = matrix(rnorm(N*p), N, p)
  r = sqrt(apply(x^2, 1, sum))
  x * outer(1/r, rep(1,p))
}

C.Bingham.MC = function(th.all, v=rep(0,length(th.all)), d=rep(1,length(th.all)), N=1e6, t=NULL){
  A = Expand.matrix(d)
  th = t(A) %*% th.all
  p = length(d)
  dsum = sum(d)
  if(is.null(t)) t = rsphere(N, dsum)
  itrd = exp(t^2 %*% th)  # integrand
  a = rep(1,N)
  #  for(i in 1:p) a = a * (t[,i]^(2*v[i]))
  for(i in 1:p) a = a * apply(t[,which(A[i,]>0),drop=FALSE]^2, 1, sum)^v[i]
  return( mean( a * itrd ) )
}

### Normalising constant and its derivatives (wrapper)
C.Bingham = function(th.all, v=rep(0,length(th.all)), d=rep(1,length(th.all)), method="power", N=1e6){
  if(method == "power"){
    return( C.Bingham.power(th.all, v=v, d=d) )
  }
  if(method == "MC"){
    return( C.Bingham.MC(th.all, v=v, d=d, N=N) )
  }
  stop("method not found")
}

### Initical value for Pfaffian system (by power series expansion)
G.Bingham.power = function(th, d=rep(1,length(th)+1)){
  p = length(th) + 1
  th.all = c(th,0)
  C= C.Bingham.power(th.all, d=d)
  dC = numeric(p-1)
  for(i in 1:(p-1)){
    e = rep(0,p); e[i] = 1
    dC[i] = C.Bingham.power(th.all, v=e, d=d)
  }
  c(C,dC)
}

### Initial value for Pfaffian system (by Monte Carlo)
G.Bingham.MC = function(th, d=rep(1,length(th)+1), N=1e6){
  p = length(th) + 1
  th.all = c(th,0)
  #  t = rsphere(N, p)
  t = rsphere(N, sum(d))
  C = C.Bingham.MC(th.all, t=t, d=d, N=N)
  dC = numeric(p-1)
  for(i in 1:(p-1)){
    e = rep(0,p); e[i] = 1
    dC[i] = C.Bingham.MC(th.all, v=e, t=t, d=d, N=N)
  }
  c(C, dC)
}

### Initial value (wrapper)
G.Bingham = function(th, d=rep(1,length(th)+1), method="power", N=1e6){
  if(method == "power"){
    return( G.Bingham.power(th, d=d) )
  }
  if(method == "MC"){
    return( G.Bingham.MC(th, d=d, N=N) )
  }
  stop("method not found")
}

### hg method for computing G(th)
hg.Bingham = function(th, d=rep(1,length(th)+1), logarithm=FALSE, ini.method="power", N=1e6){
  th0 = th / max(abs(th)) / 10
  G0 = G.Bingham(th0, d=d, method=ini.method, N=N)
  p = length(th) + 1
  if(logarithm){
    G0[2:p] = G0[2:p] / G0[1]
    G0[1] = log(G0[1])
  }
  hg(th0, G0, th, dG.fun.Bingham, fn.params=list(d=d, logarithm=logarithm))
}

### hgd method for computing MLE of Bingham distribution
hgd.Bingham = function(s, eps=1e-5, method="continuous", ini.method="power", N=1e5, times=seq(0,1,length=101)){
  s.all = c(s,1-sum(s))
  p = length(s.all)
  th.all = rank(s.all) / p  # the rank of th.all should coincide with the rank of s.all
  th0 = th.all[1:(length(th.all)-1)] - th.all[length(th.all)]  # p-th parameter is zero
  G0 = G.Bingham(th0, method=ini.method, N=N)
  dG.fun = dG.fun.Bingham
  hgd(th0, G0, dG.fun, s, method=method, times=times)
}
}
####################################################################################################################################################################################################################################################################################################################################################
