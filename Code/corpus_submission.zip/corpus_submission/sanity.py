import os
import re

user_home = os.path.expanduser("~")
files_to_check = [".Rprofile", ".Renviron"]

for filename in files_to_check:
    path = os.path.join(user_home, filename)
    if os.path.exists(path):
        print(f"Checking {path}...")
        with open(path, encoding="utf-8") as f:
            for i, line in enumerate(f, 1):
                if re.search(r'\\[A-Z]', line):
                    print(f"⚠️  Suspicious path in line {i}: {line.strip()}")
    else:
        print(f"{filename} not found.")