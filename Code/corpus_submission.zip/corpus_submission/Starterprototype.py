# shape_analysis_3d.py

import numpy as np
import pandas as pd
from scipy.spatial import procrustes
from vedo import Points, Line, Plane, Plotter
import os

# --- Load and Reshape Data ---

csv_path = "D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/my_3d_array.csv"
flat = pd.read_csv(csv_path).values

# Assuming the shape is (21 landmarks, 3 dimensions, 10 shapes)
recovered_array = np.transpose(flat, (1, 0)).reshape(21, 3, 10)
data = recovered_array

# --- Generalized Procrustes Analysis (Basic) ---
def generalized_procrustes_analysis(shapes):
    aligned_shapes = []
    ref = shapes[:, :, 0]
    for i in range(shapes.shape[2]):
        mtx1, mtx2, _ = procrustes(ref, shapes[:, :, i])
        aligned_shapes.append(mtx2)
    return np.stack(aligned_shapes, axis=2)

aligned_data = generalized_procrustes_analysis(data)

# --- 3D Plot Function (Hand-Like Shape Structure) ---
def plothand(point_array, color='blue'):
    connections = [
        list(range(4, -1, -1)),        # 5:1
        list(range(8, 4, -1)) + [0],   # 9:6,1
        list(range(9, 13)),            # 10:13
        list(range(13, 17)),           # 14:17
        [5, 9, 13, 17],                # 6,10,14,18
        [0] + list(range(17, 21))      # 1,18:21
    ]

    pts = Points(point_array, r=10, c=color)
    lines = [Line(point_array[conn], c=color) for conn in connections]
    return [pts] + lines


# --- Plot Aligned Shape Example ---
plotter = Plotter()
hand = plothand(aligned_data[:, :, 0], color='red')
for actor in hand:
    plotter += actor

# --- Add Reference Plane ---
plotter += Plane(pos=(0, 0, 0), normal=(0, 0, 1), c='lightgray', alpha=0.3)

# --- Show Scene ---
plotter.show(viewup='z', zoom=1.2, interactive=True)
