source('D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code/mainEM_3d_size_shape.r')

library(shapes)
library(ggplot2)
library(rgl)


#setwd("~/kent/research/Data/BimedicHD/Landmarks")
setwd("D:/inne/dokumenty uni/Kent/COMP8805 Dissertation/R code")
getwd()

#DD<-data[,,1:10]

#my_array<-DD
#flattened <- apply(my_array, 3, as.vector)

# Optionally transpose to get desired orientation
#flattened <- t(flattened)

# Save to CSV
#write.csv(flattened, file = "my_3d_array.csv", row.names = FALSE)

# Read the flattened matrix
#flat <- as.matrix(read.csv("my_3d_array.csv"))
flat <- as.matrix(read.csv("physically_plausible_trajectory_urdf_axes.csv"))

# Convert back to 3D array
# Suppose original dim was c(3, 4, 2)
recovered_array <- array(t(flat), dim = c(4,3,50))

data<-recovered_array


mm=procGPA(data[,,])
plot(mm$rho)
mx=which.max(mm$rho)
riemdist(data[,,mx],data[,,mx+1])
plothand=function(DD,rgl=TRUE,col=1)
{
  shapes3d(DD,type = "dots",joinline=c(5:1),rglopen=rgl,color=col)
  shapes3d(DD,rglopen=FALSE,col=1,type = "dots",joinline=c(9:6,1))
  shapes3d(DD,rglopen=FALSE,type = "dots",joinline=c(10:13))
  shapes3d(DD,rglopen=FALSE,type = "dots",joinline=c(14:17))
  shapes3d(DD,rglopen=FALSE,type = "dots",joinline=c(6,10,14,18))
  shapes3d(DD,rglopen=FALSE,type = "dots",joinline=c(1,18:21))
}

mm$rot=data
st=1

plothand(mm$rot[,,st],rgl=TRUE)


reg1=EM.poly.fit.cov.3d(aperm(data,c(2,1,3)),deg=1,niter=300); 
#polinomial degree 1(linear)

reg2=EM.poly.fit.cov.3d(aperm(data,c(2,1,3)),deg=2,niter=300); 
#polinomial degree deg=2(cuadratic)

reg3=EM.poly.fit.cov.3d(aperm(data,c(2,1,3)),deg=3,niter=700); 
#polinomial degree deg=3(cubic)

shapes3d(aperm(reg1$f[,,1,1],c(2,1)),type = "dots")
for (i in 1:dim(data)[3])
{
  shapes3d(aperm(reg1$r[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg1$r[,,i,1],c(2,1)),rgl=FALSE,col=1)
  shapes3d(aperm(reg1$f[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg1$f[,,i,1],c(2,1)),col=i+1,rgl=FALSE)
  #readline()
}

# #-------------------------------------
# # Example: If not already loaded, simulate dummy data
# # artificial_hand <- array(runif(4 * 3 * 50), dim = c(4, 3, 50))
# 
# artificial_hand <- reg1$f[,,,1]
# n_frames <- dim(artificial_hand)[3]
# 
# # Open RGL window
# open3d()
# bg3d("white")
# 
# # Number of frames
# n_frames <- dim(artificial_hand)[3]
# 
# # Plot every 5th frame, in reverse (to show progression in color)
# frame_indices <- seq(n_frames, 1, by = -5)
# 
# # Loop through selected frames
# for (i in frame_indices) {
#   pts <- artificial_hand[,,i]
# 
#   # Use relative color gradient based on index in the sequence
#   color_factor <- which(frame_indices == i) / length(frame_indices)
#   color <- rgb(0, 0, color_factor)
# 
#   # Plot landmarks
#   spheres3d(pts, radius = 0.01, color = color)
# 
#   # Plot links: 1->2->3->4
#   for (j in 1:(nrow(pts)-1)) {
#     lines3d(rbind(pts[j,], pts[j+1,]), color = color, lwd = 2)
#   }
# }
# 
# #-------------------------------------

shapes3d(aperm(reg2$f[,,1,1],c(2,1)),type = "dots")
for (i in 1:dim(data)[3])
{
  shapes3d(aperm(reg2$r[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg2$r[,,i,1],c(2,1)),rgl=FALSE,col=1)
  shapes3d(aperm(reg2$f[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg2$f[,,i,1],c(2,1)),col=i+1,rgl=FALSE)
  spheres3d(aperm(reg2$f[,,i,1],c(2,1)),radius = .002,col=2)
  #readline()
}

shapes3d(aperm(reg3$f[,,1,1],c(2,1)),type = "dots")
for (i in 1:dim(data)[3])
{
  shapes3d(aperm(reg3$r[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg3$r[,,i,1],c(2,1)),rgl=FALSE,col=1)
  shapes3d(aperm(reg3$f[,,i,1],c(2,1)),color=i+1,rglopen=FALSE,type = "dots")
  plothand(aperm(reg3$f[,,i,1],c(2,1)),col=i+1,rgl=FALSE)
  spheres3d(aperm(reg3$f[,,i,1],c(2,1)),radius = .002,col=2)
  #readline()
}

# #-------------------------------------
# # Example: If not already loaded, simulate dummy data
# # artificial_hand <- array(runif(4 * 3 * 50), dim = c(4, 3, 50))
# 
# artificial_hand <- reg3$f[,,,1]
# n_frames <- dim(artificial_hand)[3]
# 
# # Open RGL window
# open3d()
# bg3d("white")
# 
# # Number of frames
# n_frames <- dim(artificial_hand)[3]
# 
# # Plot every 5th frame, in reverse (to show progression in color)
# frame_indices <- seq(n_frames, 1, by = -5)
# 
# # Loop through selected frames
# for (i in frame_indices) {
#   pts <- artificial_hand[,,i]
#   
#   # Use relative color gradient based on index in the sequence
#   color_factor <- which(frame_indices == i) / length(frame_indices)
#   color <- rgb(0, 0, color_factor)
#   
#   # Plot landmarks
#   spheres3d(pts, radius = 0.01, color = color)
#   
#   # Plot links: 1->2->3->4
#   for (j in 1:(nrow(pts)-1)) {
#     lines3d(rbind(pts[j,], pts[j+1,]), color = color, lwd = 2)
#   }
# }
# 
# #-------------------------------------


planes3d(a=0,b=0,c=1,d=c(0,0,0),color = "lightgrey")
play3d(spin3d(axis = c(0, 0, 1), rpm = 10), duration = 12)
