# git clone http://github.com/ros-industrial/kuka_experimental.git

import pybullet as p
import time
import pybullet_data
physicsClient = p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
# p.setGravity(0,0,-10)
planeID = p.loadURDF("plane.urdf")
robot = p.loadURDF("kuka_experimental/kuka_lbr_iiwa_support/urdf/lbr_iiwa_14_r820.urdf")
print(p.getNumJoints(robot))
position, orientation = p.getBasePositionAndOrientation(robot) #get info about position and orientation of the robot
print("position:", position, orientation) #print info
p.getJointInfo(robot, 7) #get info about 7th joint
joint_positions = [j[0] for j in p.getJointStates(robot,range(7))] #get joint position of single position
joint_positions #print joint position
world_position, world_orientation = p.getLinkState(robot,2)[:2] #get info about global position and orientation of the robot
print(world_position, world_orientation) #print world info
p.setGravity(0,0, -9.81) #define gravity

p.setJointMotorControlArray(robot, range(7), p.POSITION_CONTROL, targetPositions=[0.2]*7) #define movement
for _ in range(10000): #perform simulation
    p.stepSimulation()
    time.sleep(1./240.)

#set up new simulation
p.resetSimulation() #reset simulation
planeID = p.loadURDF("plane.urdf")
robot = p.loadURDF("kuka_experimental/kuka_lbr_iiwa_support/urdf/lbr_iiwa_14_r820.urdf", [0,0,0], useFixedBase=1)
p.setGravity(0,0, -9.81)
p.setRealTimeSimulation(0)
p.setJointMotorControlArray(robot, range(7), p.POSITION_CONTROL, targetPositions=[1.5]*7) #define movement
for _ in range(300):
    p.stepSimulation()
    time.sleep(1./10.)

#Another simulatiom
p.resetSimulation() #reset simulation
planeID = p.loadURDF("plane.urdf") #create plane (platform)
robot = p.loadURDF("kuka_experimental/kuka_lbr_iiwa_support/urdf/lbr_iiwa_14_r820.urdf", [0,0,0], useFixedBase=1) #create robot
p.setGravity(0,0, -9.81) #set gravity
p.setRealTimeSimulation(0) #Debugging, set time to 0
Orientation = p.getQuaternionFromEuler([3.14,0,0]) #create initial orientation
TargetPositionsJoints = p.calculateInverseKinematics(robot, 7, [0.1,0.1,0.4], targetOrientation=Orientation) #target of the position of the joints with inverse kinematics
p.setJointMotorControlArray(robot, range(7), p.POSITION_CONTROL, targetPositions=TargetPositionsJoints) #move joints
for _ in range(300): #move time forward
    p.stepSimulation()
    time.sleep(1./10.)

p.disconnect()

# cubeStartPos = [0,0,1]
# cubeStartOrientation = p.getQuaternionFromEuler([0,0,0])
# boxId = p.loadURDF("r2d2.urdf",cubeStartPos,cubeStartOrientation)
# for i in range(10000):
#     p.stepSimulation()
#     time.sleep(1./240.)
# cubePos, cubeOrn = p.getBasePositionAndOrientation(boxId)
# print(cubePos, cubeOrn)
# p.disconnect()